(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\nth { padding: 2%}\n#table-title{\n  align-content: center;\n  text-align: center;\n   font-weight: bold;\n}\n#div-center{\n  text-align: center;\n}\nnav a {\n  padding: 5px 10px;\n  text-decoration: none;\n  margin-top: 10px;\n  display: inline-block;\n  background-color: #eee;\n  border-radius: 4px;\n}\nnav a:visited, a:link {\n  color: #607d8b;\n}\nnav a:hover {\n  color: #039be5;\n  background-color: #cfd8dc;\n}\nnav a.active {\n  color: #039be5;\n}\n.menuFloat{\n  float: left;\n  background-color:silver;\n  width:16.66%\n}\n.appmenu{\n  width: 100%;\n\n  background-color:silver;\n}\n.submenu{\n  background-color:silver;\n}\n.header{\n  background-color: cadetblue;\n  padding: 5%;\n}\n.dashedborder{\nborder-style: dashed;\n}"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=header>\n        <img src=\"assets/img/logo.png\">\n\n</div>\n\n<div id=\"page-wrapper\">\n<div class=\"appmenu\">\n<mat-menu #menu=\"matMenu\"></mat-menu>\n<div class=\"menuFloat\">\n<button mat-menu-item routerLink = \"/home\" routerlink =\"active\">Dashboard</button>\n</div> \n<div class=\"menuFloat\">\n<button mat-menu-item  routerLink = \"/summary\" routerlink =\"active\">Summary</button>\n</div>\n<div class=\"menuFloat\">\n<button mat-menu-item  routerLink = \"/entryExit\" routerlink =\"active\">Exit Entry</button>\n</div>\n<div class=\"menuFloat\">\n<button mat-menu-item routerLink = \"/unbillableData\" routerlink =\"active\">Unbillable Data</button>\n</div>\n<div class=\"menuFloat\">\n    <button mat-menu-item [matMenuTriggerFor]=\"trends\">Trends</button>\n</div>\n<div class=\"menuFloat\">\n    <button mat-menu-item [matMenuTriggerFor]=\"other\">Other</button>\n</div>\n\n<mat-menu #trends=\"matMenu\">\n    <div class=\"submenu\">\n    <button mat-menu-item routerLink = \"/trends\" routerlink =\"active\">IBU TRENDS</button>\n    <button mat-menu-item routerLink = \"/deliveryUtilization\" routerlink =\"active\">BILLING PERCENTAGE</button>\n    </div>  \n</mat-menu>\n\n    <mat-menu #other=\"matMenu\">\n        <div class=\"submenu\">\n        <button mat-menu-item routerLink = \"/projects\" routerlink =\"active\">Project List</button>\n        <button mat-menu-item routerLink = \"/fileupload\" routerlink =\"active\">Upload File</button>\n    </div>\n</mat-menu>\n\n\n</div>\n\n</div>\n<div id=\"page-wrapper\">\n<router-outlet></router-outlet>\n</div>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'angular-poc';
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: DemoMaterialModule, AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoMaterialModule", function() { return DemoMaterialModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/cdk/table */ "./node_modules/@angular/cdk/esm5/table.es5.js");
/* harmony import */ var _angular_cdk_tree__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/cdk/tree */ "./node_modules/@angular/cdk/esm5/tree.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _app_emp_summary_dashboard_emp_summary_dashboard_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../app/emp-summary-dashboard/emp-summary-dashboard.component */ "./src/app/emp-summary-dashboard/emp-summary-dashboard.component.ts");
/* harmony import */ var _app_emp_summary_dashboard_summary_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../app/emp-summary-dashboard/summary.service */ "./src/app/emp-summary-dashboard/summary.service.ts");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _app_routing__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./app.routing */ "./src/app/app.routing.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _app_entry_exit_component_entry_exit_component_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../app/entry-exit-component/entry-exit-component.component */ "./src/app/entry-exit-component/entry-exit-component.component.ts");
/* harmony import */ var _app_entry_exit_component_entry_exit_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../app/entry-exit-component/entry-exit.service */ "./src/app/entry-exit-component/entry-exit.service.ts");
/* harmony import */ var _summary_charts_summary_charts_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./summary-charts/summary-charts.component */ "./src/app/summary-charts/summary-charts.component.ts");
/* harmony import */ var _data_sharing_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./data.sharing.service */ "./src/app/data.sharing.service.ts");
/* harmony import */ var _unbillable_data_unbillable_data_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./unbillable-data/unbillable-data.component */ "./src/app/unbillable-data/unbillable-data.component.ts");
/* harmony import */ var _unbillable_data_unbilled_data_service_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./unbillable-data/unbilled.data.service.service */ "./src/app/unbillable-data/unbilled.data.service.service.ts");
/* harmony import */ var _edit_unbillable_data_edit_unbillable_data_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./edit-unbillable-data/edit-unbillable-data.component */ "./src/app/edit-unbillable-data/edit-unbillable-data.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _trends_trends_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./trends/trends.component */ "./src/app/trends/trends.component.ts");
/* harmony import */ var _trends_chart_trends_chart_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./trends-chart/trends-chart.component */ "./src/app/trends-chart/trends-chart.component.ts");
/* harmony import */ var _delivery_utilization_delivery_utilization_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./delivery-utilization/delivery-utilization.component */ "./src/app/delivery-utilization/delivery-utilization.component.ts");
/* harmony import */ var _delivery_utilization_chart_delivery_utilization_chart_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./delivery-utilization-chart/delivery-utilization-chart.component */ "./src/app/delivery-utilization-chart/delivery-utilization-chart.component.ts");
/* harmony import */ var _project_reference_data_project_reference_data_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./project-reference-data/project-reference-data.component */ "./src/app/project-reference-data/project-reference-data.component.ts");
/* harmony import */ var _project_reference_data_update_project_reference_data_update_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./project-reference-data-update/project-reference-data-update.component */ "./src/app/project-reference-data-update/project-reference-data-update.component.ts");
/* harmony import */ var _project_reference_data_project_data_service_service__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./project-reference-data/project-data-service.service */ "./src/app/project-reference-data/project-data-service.service.ts");
/* harmony import */ var _file_upload_file_upload_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./file-upload/file-upload.component */ "./src/app/file-upload/file-upload.component.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var angular_material_fileupload__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! angular-material-fileupload */ "./node_modules/angular-material-fileupload/matFileUpload.esm.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
































var DemoMaterialModule = /** @class */ (function () {
    function DemoMaterialModule() {
    }
    DemoMaterialModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            exports: [
                _angular_cdk_table__WEBPACK_IMPORTED_MODULE_4__["CdkTableModule"],
                _angular_cdk_tree__WEBPACK_IMPORTED_MODULE_5__["CdkTreeModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatAutocompleteModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatBadgeModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatBottomSheetModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatButtonToggleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatCardModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatCheckboxModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatChipsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatStepperModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatDatepickerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatDialogModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatDividerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatExpansionModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatGridListModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatInputModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatListModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatMenuModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatNativeDateModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatPaginatorModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatProgressBarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatProgressSpinnerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatRadioModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatRippleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatSelectModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatSidenavModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatSliderModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatSlideToggleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatSnackBarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatSortModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatTableModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatTabsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatToolbarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatTooltipModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatTreeModule"],
            ],
            declarations: []
        })
    ], DemoMaterialModule);
    return DemoMaterialModule;
}());

var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_2__["AppComponent"],
                _app_emp_summary_dashboard_emp_summary_dashboard_component__WEBPACK_IMPORTED_MODULE_7__["EmpSummaryDashboardComponent"],
                _app_entry_exit_component_entry_exit_component_component__WEBPACK_IMPORTED_MODULE_13__["EntryExitComponentComponent"],
                _summary_charts_summary_charts_component__WEBPACK_IMPORTED_MODULE_15__["SummaryChartsComponent"],
                _unbillable_data_unbillable_data_component__WEBPACK_IMPORTED_MODULE_17__["UnbillableDataComponent"],
                _edit_unbillable_data_edit_unbillable_data_component__WEBPACK_IMPORTED_MODULE_19__["EditUnbillableDataComponent"],
                _home_home_component__WEBPACK_IMPORTED_MODULE_20__["HomeComponent"],
                _trends_trends_component__WEBPACK_IMPORTED_MODULE_21__["TrendsComponent"], _trends_chart_trends_chart_component__WEBPACK_IMPORTED_MODULE_22__["TrendsChartComponent"],
                _delivery_utilization_delivery_utilization_component__WEBPACK_IMPORTED_MODULE_23__["DeliveryUtilizationComponent"], _delivery_utilization_chart_delivery_utilization_chart_component__WEBPACK_IMPORTED_MODULE_24__["DeliveryUtilizationChartComponent"],
                _project_reference_data_project_reference_data_component__WEBPACK_IMPORTED_MODULE_25__["ProjectReferenceDataComponent"],
                _project_reference_data_update_project_reference_data_update_component__WEBPACK_IMPORTED_MODULE_26__["ProjectReferenceDataUpdateComponent"],
                _file_upload_file_upload_component__WEBPACK_IMPORTED_MODULE_28__["FileUploadComponent"],
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"],
                DemoMaterialModule,
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatNativeDateModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_9__["HttpModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_9__["JsonpModule"],
                _app_routing__WEBPACK_IMPORTED_MODULE_10__["routing"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_11__["BrowserAnimationsModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_11__["NoopAnimationsModule"],
                angular_material_fileupload__WEBPACK_IMPORTED_MODULE_30__["MatFileUploadModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatIconModule"]
            ],
            providers: [
                _app_emp_summary_dashboard_summary_service__WEBPACK_IMPORTED_MODULE_8__["SummaryService"],
                _app_entry_exit_component_entry_exit_service__WEBPACK_IMPORTED_MODULE_14__["EntryExitService"],
                _data_sharing_service__WEBPACK_IMPORTED_MODULE_16__["DataService"],
                _unbillable_data_unbilled_data_service_service__WEBPACK_IMPORTED_MODULE_18__["UnbilledDataServiceService"],
                _project_reference_data_project_data_service_service__WEBPACK_IMPORTED_MODULE_27__["ProjectDataServiceService"],
                _angular_common__WEBPACK_IMPORTED_MODULE_29__["DatePipe"]
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_2__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/app.routing.ts":
/*!********************************!*\
  !*** ./src/app/app.routing.ts ***!
  \********************************/
/*! exports provided: routing */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routing", function() { return routing; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _edit_unbillable_data_edit_unbillable_data_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-unbillable-data/edit-unbillable-data.component */ "./src/app/edit-unbillable-data/edit-unbillable-data.component.ts");
/* harmony import */ var _app_home_home_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app/home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _emp_summary_dashboard_emp_summary_dashboard_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./emp-summary-dashboard/emp-summary-dashboard.component */ "./src/app/emp-summary-dashboard/emp-summary-dashboard.component.ts");
/* harmony import */ var _entry_exit_component_entry_exit_component_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./entry-exit-component/entry-exit-component.component */ "./src/app/entry-exit-component/entry-exit-component.component.ts");
/* harmony import */ var _app_unbillable_data_unbillable_data_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../app/unbillable-data/unbillable-data.component */ "./src/app/unbillable-data/unbillable-data.component.ts");
/* harmony import */ var _trends_trends_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./trends/trends.component */ "./src/app/trends/trends.component.ts");
/* harmony import */ var _delivery_utilization_delivery_utilization_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./delivery-utilization/delivery-utilization.component */ "./src/app/delivery-utilization/delivery-utilization.component.ts");
/* harmony import */ var _project_reference_data_project_reference_data_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./project-reference-data/project-reference-data.component */ "./src/app/project-reference-data/project-reference-data.component.ts");
/* harmony import */ var _project_reference_data_update_project_reference_data_update_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./project-reference-data-update/project-reference-data-update.component */ "./src/app/project-reference-data-update/project-reference-data-update.component.ts");
/* harmony import */ var _file_upload_file_upload_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./file-upload/file-upload.component */ "./src/app/file-upload/file-upload.component.ts");











var appRoutes = [
    {
        path: "",
        redirectTo: "home",
        pathMatch: "full"
    },
    {
        path: "angular",
        redirectTo: "home",
        pathMatch: "full"
    },
    {
        path: "main",
        component: _app_home_home_component__WEBPACK_IMPORTED_MODULE_2__["HomeComponent"]
    },
    {
        path: "home",
        component: _app_home_home_component__WEBPACK_IMPORTED_MODULE_2__["HomeComponent"]
    },
    {
        path: "editUnbilledEmployee",
        component: _edit_unbillable_data_edit_unbillable_data_component__WEBPACK_IMPORTED_MODULE_1__["EditUnbillableDataComponent"]
    },
    {
        path: "summary",
        component: _emp_summary_dashboard_emp_summary_dashboard_component__WEBPACK_IMPORTED_MODULE_3__["EmpSummaryDashboardComponent"]
    },
    {
        path: "dashboard",
        component: _app_home_home_component__WEBPACK_IMPORTED_MODULE_2__["HomeComponent"]
    },
    {
        path: "entryExit",
        component: _entry_exit_component_entry_exit_component_component__WEBPACK_IMPORTED_MODULE_4__["EntryExitComponentComponent"]
    },
    {
        path: "unbillableData",
        component: _app_unbillable_data_unbillable_data_component__WEBPACK_IMPORTED_MODULE_5__["UnbillableDataComponent"]
    },
    {
        path: "trends",
        component: _trends_trends_component__WEBPACK_IMPORTED_MODULE_6__["TrendsComponent"]
    },
    {
        path: "deliveryUtilization",
        component: _delivery_utilization_delivery_utilization_component__WEBPACK_IMPORTED_MODULE_7__["DeliveryUtilizationComponent"]
    },
    {
        path: "projects",
        component: _project_reference_data_project_reference_data_component__WEBPACK_IMPORTED_MODULE_8__["ProjectReferenceDataComponent"]
    },
    {
        path: "updateproject",
        component: _project_reference_data_update_project_reference_data_update_component__WEBPACK_IMPORTED_MODULE_9__["ProjectReferenceDataUpdateComponent"]
    },
    {
        path: "addproject",
        component: _project_reference_data_update_project_reference_data_update_component__WEBPACK_IMPORTED_MODULE_9__["ProjectReferenceDataUpdateComponent"]
    },
    {
        path: "fileupload",
        component: _file_upload_file_upload_component__WEBPACK_IMPORTED_MODULE_10__["FileUploadComponent"]
    },
    // otherwise redirect to home
    { path: "**", redirectTo: "/" }
];
var routing = _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forRoot(appRoutes);


/***/ }),

/***/ "./src/app/data.sharing.service.ts":
/*!*****************************************!*\
  !*** ./src/app/data.sharing.service.ts ***!
  \*****************************************/
/*! exports provided: DataService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataService", function() { return DataService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var DataService = /** @class */ (function () {
    function DataService() {
    }
    DataService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [])
    ], DataService);
    return DataService;
}());



/***/ }),

/***/ "./src/app/delivery-utilization-chart/delivery-utilization-chart.component.css":
/*!*************************************************************************************!*\
  !*** ./src/app/delivery-utilization-chart/delivery-utilization-chart.component.css ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/delivery-utilization-chart/delivery-utilization-chart.component.html":
/*!**************************************************************************************!*\
  !*** ./src/app/delivery-utilization-chart/delivery-utilization-chart.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div #container></div>\n<div id=\"container\"></div>\n"

/***/ }),

/***/ "./src/app/delivery-utilization-chart/delivery-utilization-chart.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/delivery-utilization-chart/delivery-utilization-chart.component.ts ***!
  \************************************************************************************/
/*! exports provided: DeliveryUtilizationChartComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryUtilizationChartComponent", function() { return DeliveryUtilizationChartComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var highcharts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! highcharts */ "./node_modules/highcharts/highcharts.js");
/* harmony import */ var highcharts__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(highcharts__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var highcharts_highcharts_more__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! highcharts/highcharts-more */ "./node_modules/highcharts/highcharts-more.js");
/* harmony import */ var highcharts_highcharts_more__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(highcharts_highcharts_more__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! highcharts/modules/drilldown */ "./node_modules/highcharts/modules/drilldown.js");
/* harmony import */ var highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! highcharts/modules/exporting */ "./node_modules/highcharts/modules/exporting.js");
/* harmony import */ var highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _delivery_utilization_delivery_utilization_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../delivery-utilization/delivery-utilization.service */ "./src/app/delivery-utilization/delivery-utilization.service.ts");
/* harmony import */ var _delivery_utilization_series__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./delivery-utilization-series */ "./src/app/delivery-utilization-chart/delivery-utilization-series.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



highcharts_highcharts_more__WEBPACK_IMPORTED_MODULE_2___default()(highcharts__WEBPACK_IMPORTED_MODULE_1__);

highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_3___default()(highcharts__WEBPACK_IMPORTED_MODULE_1__);
// Load the exporting module.

// Initialize exporting module.
highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_4___default()(highcharts__WEBPACK_IMPORTED_MODULE_1__);


var DeliveryUtilizationChartComponent = /** @class */ (function () {
    function DeliveryUtilizationChartComponent(deliveryUtilizationService) {
        this.deliveryUtilizationService = deliveryUtilizationService;
        this.deliveryUtilizationSeries = new _delivery_utilization_series__WEBPACK_IMPORTED_MODULE_6__["DeliveryUtilizationSeries"];
        this.seriesList = [
            'UTILIZATION_DELIVERY_PROJ_WITH_PO',
            'UTILIZATION_DELIVERY_WITHOUT_PO',
            'DELIVERY_FTE_WITHOUT_PO',
            'UTILIZATION_IBU'
        ];
    }
    DeliveryUtilizationChartComponent.prototype.getDeliveryUtilizations = function () {
        var _this = this;
        this.deliveryUtilizationService.getDeliveryUtilization()
            .subscribe(function (deliveryUtilizationData) {
            _this.deliveryUtilizationList = deliveryUtilizationData;
            //console.log(this.deliveryUtilizationList);
            _this.refreshSeriesData(_this.deliveryUtilizationList);
        });
    };
    DeliveryUtilizationChartComponent.prototype.ngOnInit = function () {
        this.getDeliveryUtilizations();
        this.chart = highcharts__WEBPACK_IMPORTED_MODULE_1__["chart"]('container', {
            title: {
                text: 'Delivery Utilization for IBU'
            },
            subtitle: {
                text: 'Tech Mahindra'
            },
            yAxis: {
                title: {
                    text: 'Percentage'
                }
            },
            xAxis: {
                type: 'datetime',
                dateTimeLabelFormats: {
                    month: '%e. %b',
                    year: '%b'
                },
                title: {
                    text: 'Date'
                }
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle'
            },
            plotOptions: {
                series: {
                    label: {
                        connectorAllowed: false
                    }
                    // pointStart: Date.UTC(2014, 11, 2),
                }
            },
            series: [],
            responsive: {
                rules: [{
                        condition: {
                            maxWidth: 500
                        },
                        chartOptions: {
                            legend: {
                                layout: 'horizontal',
                                align: 'center',
                                verticalAlign: 'bottom'
                            }
                        }
                    }]
            }
        });
    };
    DeliveryUtilizationChartComponent.prototype.refreshSeriesData = function (deliveryUtilizationListP) {
        for (var i = 0; this.chart.series.length > 0; i++) {
            this.chart.series[0].remove(true);
        }
        this.getTrendSeries(deliveryUtilizationListP);
        //console.log(this.deliveryUtilizationSeries);
        this.chart.addSeries({
            name: this.seriesList[0],
            data: this.deliveryUtilizationSeries.DELIVERY_FTE_WITHOUT_PO
        });
        this.chart.addSeries({
            name: this.seriesList[1],
            data: this.deliveryUtilizationSeries.UTILIZATION_DELIVERY_PROJ_WITH_PO
        });
        this.chart.addSeries({
            name: this.seriesList[2],
            data: this.deliveryUtilizationSeries.UTILIZATION_DELIVERY_WITHOUT_PO
        });
        this.chart.addSeries({
            name: this.seriesList[3],
            data: this.deliveryUtilizationSeries.UTILIZATION_IBU
        });
    };
    DeliveryUtilizationChartComponent.prototype.getTrendSeries = function (deliveryUtilizationListPS) {
        this.deliveryUtilizationSeries = new _delivery_utilization_series__WEBPACK_IMPORTED_MODULE_6__["DeliveryUtilizationSeries"];
        for (var i = 0; i < deliveryUtilizationListPS.length; i++) {
            this.tempDate = new Date(deliveryUtilizationListPS[i].UT_DATE);
            //console.log(this.tempDate.getUTCDate());
            this.deliveryUtilizationSeries.DELIVERY_FTE_WITHOUT_PO.push([Date.UTC(this.tempDate.getUTCFullYear(), this.tempDate.getUTCMonth(), this.tempDate.getUTCDate()), deliveryUtilizationListPS[i].delivery_FTE_WITHOUT_PO]);
            this.deliveryUtilizationSeries.UTILIZATION_DELIVERY_PROJ_WITH_PO.push([
                Date.UTC(this.tempDate.getUTCFullYear(), this.tempDate.getUTCMonth(), this.tempDate.getUTCDate()),
                deliveryUtilizationListPS[i].utilization_DELIVERY_PROJ_WITH_PO
            ]);
            this.deliveryUtilizationSeries.UTILIZATION_DELIVERY_WITHOUT_PO.push([Date.UTC(this.tempDate.getUTCFullYear(), this.tempDate.getUTCMonth(), this.tempDate.getUTCDate()),
                deliveryUtilizationListPS[i].utilization_DELIVERY_WITHOUT_PO]);
            this.deliveryUtilizationSeries.UTILIZATION_IBU.push([Date.UTC(this.tempDate.getUTCFullYear(), this.tempDate.getUTCMonth(), this.tempDate.getUTCDate()),
                deliveryUtilizationListPS[i].utilization_IBU]);
        }
    };
    DeliveryUtilizationChartComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-delivery-utilization-chart',
            template: __webpack_require__(/*! ./delivery-utilization-chart.component.html */ "./src/app/delivery-utilization-chart/delivery-utilization-chart.component.html"),
            styles: [__webpack_require__(/*! ./delivery-utilization-chart.component.css */ "./src/app/delivery-utilization-chart/delivery-utilization-chart.component.css")]
        }),
        __metadata("design:paramtypes", [_delivery_utilization_delivery_utilization_service__WEBPACK_IMPORTED_MODULE_5__["DeliveryUtilizationService"]])
    ], DeliveryUtilizationChartComponent);
    return DeliveryUtilizationChartComponent;
}());



/***/ }),

/***/ "./src/app/delivery-utilization-chart/delivery-utilization-series.ts":
/*!***************************************************************************!*\
  !*** ./src/app/delivery-utilization-chart/delivery-utilization-series.ts ***!
  \***************************************************************************/
/*! exports provided: DeliveryUtilizationSeries */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryUtilizationSeries", function() { return DeliveryUtilizationSeries; });
var DeliveryUtilizationSeries = /** @class */ (function () {
    function DeliveryUtilizationSeries() {
        //yaxis : number[] = [];
        this.data = [];
        this.UTILIZATION_DELIVERY_PROJ_WITH_PO = [];
        this.UTILIZATION_DELIVERY_WITHOUT_PO = [];
        this.DELIVERY_FTE_WITHOUT_PO = [];
        this.UTILIZATION_IBU = [];
    }
    return DeliveryUtilizationSeries;
}());



/***/ }),

/***/ "./src/app/delivery-utilization/delivery-utilization.component.css":
/*!*************************************************************************!*\
  !*** ./src/app/delivery-utilization/delivery-utilization.component.css ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\n    width: 100%;\n  padding:15px 15px 5px 15px;\n      box-shadow: 0px 2px 14px 5px #dadada; \n      margin-top:10px;\n      border-radius:6px;\n  }\n  \n  tr:nth-child(even) {background-color: #f2f2f2;}\n  \n  th { background-color: #252323f6; \n    -webkit-text-fill-color: #d0d0df;\n    text-align: center;\n  }\n  \n  td, th:nth-child(even) {\n  border-collapse: collapse;\n  border: 1px dashed #ccc;;\n}\n  \n  tr:hover {background-color: #ccccff;}\n  \n  td:hover {background-color: #ccccff;}\n  \n  table {\n    border-collapse: collapse;\n  }\n  \n  table th{\n    font-weight: bold;\n    \n  }\n  \n  table td, table th {\n    \n    text-align: center;\n    \n  }\n  \n  table tr:first-child th {\n    border-top: 0;\n  }\n  \n  table tr:last-child td {\n    border-bottom: 0;\n  }\n  \n  table tr td:first-child,\n  table tr th:first-child {\n    border-left: 0;\n  }\n  \n  table tr td:last-child,\n  table tr th:last-child {\n    border-right: 0;\n  }\n  \n  #delivery-utilization-table-title{\n    width: 100%;\n    align-content: center;\n    text-align: center;\n     padding:15px 15px 5px 15px;\n      margin-top:10px;\n      border-radius:6px;\n      color: #333333;\n      font-size: 18px;\n      fill: #333333;\n      font-family: \"Lucida Grande\", \"Lucida Sans Unicode\", Arial, Helvetica, sans-serif;\n  \n  }\n  \n  #div-center{\n    text-align: center;\n  }\n  \n  #div-center{\n    text-align: center;\n  }\n\n"

/***/ }),

/***/ "./src/app/delivery-utilization/delivery-utilization.component.html":
/*!**************************************************************************!*\
  !*** ./src/app/delivery-utilization/delivery-utilization.component.html ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-delivery-utilization-chart></app-delivery-utilization-chart>\n<br><br>\n<div id=\"delivery-utilization-table-title\">Delivery Utilization</div>\n<table mat-table [dataSource]=\"deliveryUtilizationList\" title=\"delivery-utilization\">\n\n\t<ng-container matColumnDef=\"UT_DATE\">\n\t\t<th mat-header-cell *matHeaderCellDef> DATE </th>\n\t\t<td mat-cell *matCellDef=\"let deliveryUtilizationRow\">\n\t\t\t{{deliveryUtilizationRow.UT_DATE}} </td>\n\t</ng-container>\n\n\t<ng-container matColumnDef=\"UTILIZATION_DELIVERY_PROJ_WITH_PO\">\n\t\t<th mat-header-cell *matHeaderCellDef> UTILIZATION_DELIVERY_PROJ_WITH_PO </th>\n\t\t<td mat-cell *matCellDef=\"let deliveryUtilizationRow\" >\n\t\t\t{{deliveryUtilizationRow.utilization_DELIVERY_PROJ_WITH_PO}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"UTILIZATION_DELIVERY_WITHOUT_PO\">\n\t\t<th mat-header-cell *matHeaderCellDef> UTILIZATION_DELIVERY_WITHOUT_PO </th>\n\t\t<td mat-cell *matCellDef=\"let deliveryUtilizationRow\" >\n\t\t\t{{deliveryUtilizationRow.utilization_DELIVERY_WITHOUT_PO}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"DELIVERY_FTE_WITHOUT_PO\">\n\t\t<th mat-header-cell *matHeaderCellDef> DELIVERY_FTE_WITHOUT_PO </th>\n\t\t<td mat-cell *matCellDef=\"let deliveryUtilizationRow\" >\n\t\t\t{{deliveryUtilizationRow.delivery_FTE_WITHOUT_PO}} </td>\n\t</ng-container>\n\n\t<ng-container matColumnDef=\"UTILIZATION_IBU\">\n\t\t<th mat-header-cell *matHeaderCellDef> UTILIZATION_IBU </th>\n\t\t<td mat-cell *matCellDef=\"let deliveryUtilizationRow\" >\n\t\t\t{{deliveryUtilizationRow.utilization_IBU}} </td>\n\t</ng-container>\n\n\t<tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n\t<tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>\n</table>\n<br><br>"

/***/ }),

/***/ "./src/app/delivery-utilization/delivery-utilization.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/delivery-utilization/delivery-utilization.component.ts ***!
  \************************************************************************/
/*! exports provided: DeliveryUtilizationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryUtilizationComponent", function() { return DeliveryUtilizationComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _delivery_utilization_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./delivery-utilization.service */ "./src/app/delivery-utilization/delivery-utilization.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var DeliveryUtilizationComponent = /** @class */ (function () {
    function DeliveryUtilizationComponent(deliveryUtilizationService) {
        this.deliveryUtilizationService = deliveryUtilizationService;
        this.displayedColumns = [
            'UT_DATE',
            'UTILIZATION_DELIVERY_PROJ_WITH_PO',
            'UTILIZATION_DELIVERY_WITHOUT_PO',
            'DELIVERY_FTE_WITHOUT_PO',
            'UTILIZATION_IBU'
        ];
        this.getDeliveryUtilization();
    }
    DeliveryUtilizationComponent.prototype.getDeliveryUtilization = function () {
        var _this = this;
        this.deliveryUtilizationService.getDeliveryUtilization()
            .subscribe(function (deliveryUtilizationData) {
            _this.deliveryUtilizationList = deliveryUtilizationData;
            //console.log('Print Start');
            //console.log(this.deliveryUtilizationList);
            //console.log('Print End');
        });
    };
    DeliveryUtilizationComponent.prototype.ngOnInit = function () {
    };
    DeliveryUtilizationComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-delivery-utilization',
            template: __webpack_require__(/*! ./delivery-utilization.component.html */ "./src/app/delivery-utilization/delivery-utilization.component.html"),
            styles: [__webpack_require__(/*! ./delivery-utilization.component.css */ "./src/app/delivery-utilization/delivery-utilization.component.css")]
        }),
        __metadata("design:paramtypes", [_delivery_utilization_service__WEBPACK_IMPORTED_MODULE_1__["DeliveryUtilizationService"]])
    ], DeliveryUtilizationComponent);
    return DeliveryUtilizationComponent;
}());



/***/ }),

/***/ "./src/app/delivery-utilization/delivery-utilization.service.ts":
/*!**********************************************************************!*\
  !*** ./src/app/delivery-utilization/delivery-utilization.service.ts ***!
  \**********************************************************************/
/*! exports provided: DeliveryUtilizationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryUtilizationService", function() { return DeliveryUtilizationService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var DeliveryUtilizationService = /** @class */ (function () {
    function DeliveryUtilizationService(http) {
        this.http = http;
        this.deliveryUtilizationURL = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].deliveryUtilizationURL;
    }
    /** GET Data from the server */
    DeliveryUtilizationService.prototype.getDeliveryUtilization = function () {
        return this.http.get(this.deliveryUtilizationURL)
            .pipe();
    };
    DeliveryUtilizationService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // TODO: better job of transforming error for user consumption
            /**this.log(`${operation} failed: ${error.message}`);*/
            // Let the app keep running by returning an empty result.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(result);
        };
    };
    DeliveryUtilizationService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], DeliveryUtilizationService);
    return DeliveryUtilizationService;
}());



/***/ }),

/***/ "./src/app/edit-unbillable-data/edit-unbillable-data.component.css":
/*!*************************************************************************!*\
  !*** ./src/app/edit-unbillable-data/edit-unbillable-data.component.css ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".field-width {\n    width: 40%;\n  }\n  .text-width-height{\n      width: 40%;\n      height: 30pc;\n  }\n  "

/***/ }),

/***/ "./src/app/edit-unbillable-data/edit-unbillable-data.component.html":
/*!**************************************************************************!*\
  !*** ./src/app/edit-unbillable-data/edit-unbillable-data.component.html ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"Employee ID\" disabled [(ngModel)]=\"editEmployeeData.objCurrentEmployee.empid\" value={{editEmployeeData.objCurrentEmployee.empid}}>\n</mat-form-field> &nbsp;\n\n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"Employee Name\" disabled [(ngModel)]=\"editEmployeeData.objCurrentEmployee.emp_NAME\" value={{editEmployeeData.objCurrentEmployee.emp_NAME}}>\n</mat-form-field><br>\n<!--\n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"Project Type\" [(ngModel)]=\"editEmployeeData.project_TYPE\" value={{editEmployeeData.project_TYPE}}>\n</mat-form-field>\n<br>\n-->\n\n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"Account\" [(ngModel)]=\"editEmployeeData.account\" value={{editEmployeeData.account}}>\n</mat-form-field> &nbsp;\n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"Action\" [(ngModel)]=\"editEmployeeData.action\" value={{editEmployeeData.action}}>\n</mat-form-field><br>\n\n<mat-form-field class=\"field-width\">\n    <mat-select placeholder=\"Category\" (selectionChange)=\"setSubCategory($event)\"  [(ngModel)]=\"editEmployeeData.category.category\">\n      <mat-option *ngFor=\"let category of categories\" [value]=\"category.category\">\n        {{category.category}}\n      </mat-option>\n    </mat-select>\n  </mat-form-field>&nbsp;\n\n  <mat-form-field class=\"field-width\">\n    <mat-select placeholder=\"Sub Category\"  (selectionChange)=\"setSubCategoryEmployee($event)\" [(ngModel)]=\"editEmployeeData.category.sub_CATEGORY\">\n      <mat-option *ngFor=\"let subcategory of subcategories\" [value]=\"subcategory.sub_CATEGORY\">\n        {{subcategory.sub_CATEGORY}}\n      </mat-option>\n    </mat-select>\n  </mat-form-field>\n\n<!--\n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"Category\" [(ngModel)]=\"editEmployeeData.category.category\" >\n</mat-form-field> &nbsp;\n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"Sub Category\" [(ngModel)]=\"editEmployeeData.category.sub_CATEGORY\" >\n</mat-form-field>\n-->\n\n<br>\n\n<mat-form-field >\n    <input  matInput [matDatepicker]=\"billing_START_DATE\" placeholder=\"Billing Start Date\" disabled [(ngModel)]=\"editEmployeeData.billing_START_DATE\">\n    <mat-datepicker-toggle matSuffix [for]=\"billing_START_DATE\"></mat-datepicker-toggle>\n    <mat-datepicker #billing_START_DATE disabled=\"false\"></mat-datepicker>\n</mat-form-field>\n\n<!--\n [value]=\"editEmployeeData.billing_START_DATE | date\">\nvalue=\"editEmployeeData.billing_START_DATE | date\">\n \n    value=\"editEmployeeData.billing_START_DATE\"\n -->\n\n&nbsp;\n<mat-form-field class=\"field-width\">\n    <textarea matInput placeholder=\"Comments\" [(ngModel)]=\"editEmployeeData.comments\" [value]=\"editEmployeeData.comments\">\n      \n      </textarea>\n</mat-form-field>\n<br>\n<button (click)=\"saveEmployee(editEmployeeData)\">Save</button> &nbsp;\n<button routerLink=\"/unbillableData\" routerlink=\"active\">Cancel </button>\n<br>\n<br><br>\n<br>"

/***/ }),

/***/ "./src/app/edit-unbillable-data/edit-unbillable-data.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/edit-unbillable-data/edit-unbillable-data.component.ts ***!
  \************************************************************************/
/*! exports provided: EditUnbillableDataComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditUnbillableDataComponent", function() { return EditUnbillableDataComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _data_sharing_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data.sharing.service */ "./src/app/data.sharing.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _save_employee_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./save-employee-service.service */ "./src/app/edit-unbillable-data/save-employee-service.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var EditUnbillableDataComponent = /** @class */ (function () {
    function EditUnbillableDataComponent(dataService, router, saveEmployeeServiceService) {
        this.dataService = dataService;
        this.router = router;
        this.saveEmployeeServiceService = saveEmployeeServiceService;
        this.editEmployeeData = this.dataService.currentEmployeeDataForEdit;
        //console.log(this.editEmployeeData);
        if (this.editEmployeeData === undefined || null === this.editEmployeeData) {
            this.router.navigateByUrl('');
        }
        if (null != this.editEmployeeData && null != this.editEmployeeData.billing_START_DATE) {
            var date = new Date(this.editEmployeeData.billing_START_DATE);
            this.editEmployeeData.billing_START_DATE = date;
            //console.log(this.editEmployeeData);
        }
        this.setCategory();
        this.setSubCategoryFirst();
    }
    EditUnbillableDataComponent.prototype.setCategory = function () {
        var _this = this;
        this.saveEmployeeServiceService.getCategories().
            subscribe(function (response) {
            _this.categories = response;
        });
    };
    EditUnbillableDataComponent.prototype.ngOnInit = function () {
        if (this.editEmployeeData === undefined) {
            this.router.navigateByUrl('');
        }
        this.setCategory();
    };
    EditUnbillableDataComponent.prototype.getSubCategoryByName = function () {
    };
    EditUnbillableDataComponent.prototype.setSubCategory = function ($event) {
        var _this = this;
        console.log($event.value);
        this.saveEmployeeServiceService.getSubCategories($event.value).
            subscribe(function (response) {
            _this.subcategories = response;
        });
    };
    EditUnbillableDataComponent.prototype.setSubCategoryFirst = function () {
        var _this = this;
        if (null !== this.editEmployeeData && undefined !== this.editEmployeeData && null !== this.editEmployeeData.category) {
            this.saveEmployeeServiceService.getSubCategories(this.editEmployeeData.category.category).
                subscribe(function (response) {
                _this.subcategories = response;
            });
        }
    };
    EditUnbillableDataComponent.prototype.setSubCategoryEmployee = function ($event) {
        var _this = this;
        this.saveEmployeeServiceService.getSubCategory(this.editEmployeeData.category).
            subscribe(function (response) {
            _this.editEmployeeData.category.sub_CAT_ID = response.sub_CAT_ID;
            console.log(response);
            console.log(_this.editEmployeeData);
        });
        //this.setCategory();
        console.log(this.editEmployeeData);
        //console.log(this.categories);
    };
    EditUnbillableDataComponent.prototype.saveEmployee = function (editEmployeeData) {
        var _this = this;
        //this.temp.getDate
        //editEmployeeData.billing_START_DATE = 
        // let newDate = new Date(dateString);
        /*console.log(Date.UTC(editEmployeeData.billing_START_DATE.getFullYear,
         editEmployeeData.billing_START_DATE.getMonth,
         editEmployeeData.billing_START_DATE.getDate));
         */
        var date = new Date(editEmployeeData.billing_START_DATE);
        editEmployeeData.billing_START_DATE =
            Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
        var localOffset = date.getTimezoneOffset() * -1 * 60000 * 2;
        var utc = editEmployeeData.billing_START_DATE + localOffset;
        // console.log("hello " +utc);
        /*
             let localTime = date.getTime();
             
            
             let localOffset = date.getTimezoneOffset() * -1 * 60000 * 2;
             let utc = localTime + localOffset;
             console.log(utc + "  " + date.getDate());
            date.setTime(utc)
            date.setUTCDate(date.getDate());
            date.setUTCMonth(date.getMonth());
            date.setUTCFullYear(date.getFullYear());
            console.log(date);
            */
        //editEmployeeData.billing_START_DATE = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+date.getDate();    
        //console.log(date.getDate());
        /*
        let diff = date.getTimezoneOffset();
        let utcTime = date.getTime();
        date.setTime(utcTime + diff);
        console.log(date.getTime());
         */
        //editEmployeeData.billing_START_DATE.setTime(utcTime + diff);
        //console.log(date.getTimezoneOffset());
        // = date;
        console.log(editEmployeeData);
        this.saveEmployeeServiceService.updateEmployee(editEmployeeData).
            subscribe(function (response) {
            _this.response = response;
            _this.router.navigateByUrl('unbillableData');
        });
    };
    EditUnbillableDataComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-edit-unbillable-data',
            template: __webpack_require__(/*! ./edit-unbillable-data.component.html */ "./src/app/edit-unbillable-data/edit-unbillable-data.component.html"),
            styles: [__webpack_require__(/*! ./edit-unbillable-data.component.css */ "./src/app/edit-unbillable-data/edit-unbillable-data.component.css")],
        }),
        __metadata("design:paramtypes", [_data_sharing_service__WEBPACK_IMPORTED_MODULE_1__["DataService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _save_employee_service_service__WEBPACK_IMPORTED_MODULE_3__["SaveEmployeeServiceService"]])
    ], EditUnbillableDataComponent);
    return EditUnbillableDataComponent;
}());



/***/ }),

/***/ "./src/app/edit-unbillable-data/save-employee-service.service.ts":
/*!***********************************************************************!*\
  !*** ./src/app/edit-unbillable-data/save-employee-service.service.ts ***!
  \***********************************************************************/
/*! exports provided: SaveEmployeeServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaveEmployeeServiceService", function() { return SaveEmployeeServiceService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var SaveEmployeeServiceService = /** @class */ (function () {
    function SaveEmployeeServiceService(http) {
        this.http = http;
        this.saveEmployeeDataURL = _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].saveEmployeeURL;
        this.getCategoryURL = _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].getCategoryURL;
        this.getSubCategoryURL = _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].getSubCategoryURL;
        this.getSubCategoriesURL = _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].getSubCategoriesURL;
    }
    /** GET heroes from the server */
    SaveEmployeeServiceService.prototype.getUnbilledData = function () {
        return this.http.get(this.saveEmployeeDataURL)
            .pipe();
    };
    SaveEmployeeServiceService.prototype.getCategories = function () {
        return this.http.get(this.getCategoryURL)
            .pipe();
    };
    SaveEmployeeServiceService.prototype.getSubCategories = function (category) {
        return this.http.post(this.getSubCategoriesURL, category, httpOptions);
    };
    SaveEmployeeServiceService.prototype.getSubCategory = function (subcategory) {
        return this.http.post(this.getSubCategoryURL, subcategory, httpOptions);
    };
    SaveEmployeeServiceService.prototype.updateEmployee = function (employee) {
        return this.http.post(this.saveEmployeeDataURL, employee, httpOptions)
            .pipe();
    };
    SaveEmployeeServiceService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], SaveEmployeeServiceService);
    return SaveEmployeeServiceService;
}());



/***/ }),

/***/ "./src/app/emp-summary-dashboard/emp-summary-dashboard.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/emp-summary-dashboard/emp-summary-dashboard.component.css ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\r\n  width: 100%;\r\npadding:15px 15px 5px 15px;\r\n\tbox-shadow: 0px 2px 14px 5px #dadada; \r\n\tmargin-top:10px;\r\n\tborder-radius:6px;\r\n}\r\n\r\ntr:nth-child(even) {background-color: #f2f2f2;}\r\n\r\nth { background-color: #252323f6; \r\n    -webkit-text-fill-color: #d0d0df;\r\n    text-align: center;\r\n  }\r\n\r\ntd, th:nth-child(even) {\r\n  border-collapse: collapse;\r\n  border: 1px dashed #ccc;;\r\n}\r\n\r\n.notTotalRow {\r\n  text-align: center;\r\n}\r\n\r\ntr:hover {background-color: #ccccff;}\r\n\r\ntd:hover {background-color: #ccccff;}\r\n\r\n.totalRow{\r\n  background-color: rgba(0, 100, 0, 0.63);\r\n  font-weight: bold;\r\n  \r\n}\r\n\r\n.bufferRow{\r\n  background-color: rgba(255, 255, 0, 0.651);\r\n  font-weight: bold;\r\n}\r\n\r\n.nonDeliverySubTotalRow{\r\n  background-color: rgba(210, 105, 30, 0.596);\r\n  font-weight: bold;\r\n}\r\n\r\n.deliveryTotalRow{\r\n  background-color: rgba(210, 105, 30, 0.493);\r\n  font-weight: bold;\r\n}\r\n\r\ntable {\r\n  border-collapse: collapse;\r\n}\r\n\r\ntable th{\r\n  font-weight: bold;\r\n  \r\n}\r\n\r\ntable td, table th {\r\n  \r\n  text-align: center;\r\n  align-content: center;\r\n}\r\n\r\ntable tr:first-child th {\r\n  border-top: 0;\r\n}\r\n\r\ntable tr:last-child td {\r\n  border-bottom: 0;\r\n  padding-left: 2%;\r\n}\r\n\r\ntable tr td:first-child,\r\ntable tr th:first-child {\r\n  border-left: 0;\r\n}\r\n\r\ntable tr td:last-child,\r\ntable tr th:last-child {\r\n  border-right: 0;\r\n}\r\n\r\n#summary-table-title{\r\n  width: 100%;\r\n  align-content: center;\r\n  text-align: center;\r\n   padding:15px 15px 5px 15px;\r\n    margin-top:10px;\r\n    border-radius:6px;\r\n    color: #333333;\r\n    font-size: 18px;\r\n    fill: #333333;\r\n    font-family: \"Lucida Grande\", \"Lucida Sans Unicode\", Arial, Helvetica, sans-serif;\r\n\r\n}\r\n\r\n#div-center{\r\n  text-align: center;\r\n}\r\n\r\n/*\r\n.summary-charts{\r\n  width: 40%;\r\n  float: right;\r\n}\r\n*/"

/***/ }),

/***/ "./src/app/emp-summary-dashboard/emp-summary-dashboard.component.html":
/*!****************************************************************************!*\
  !*** ./src/app/emp-summary-dashboard/emp-summary-dashboard.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n\n\n\t<div class=\"summary-table\">\n\n\t<div id=\"summary-table-title\">Summary</div>\n\n<!--\n\t<button mat-button color=\"accent\" (click)=\"print()\">\n\t\t\t<mat-icon class=\"mat-24\" aria-label=\"Example icon-button with a heart icon\">\n\t\t\t\tprint</mat-icon>\n\t\t\t\tPrint\n\t</button>\n-->\n\n<table mat-table [dataSource]=\"summaryList\" title=\"Summary\">\n\t\n\t<ng-container matColumnDef=\"columnRowName\">\n\t\t<th mat-header-cell *matHeaderCellDef> Summary </th>\n\t\t<td mat-cell *matCellDef=\"let SummaryRow\" [ngClass]=\"(SummaryRow.columnRowName==='Grand Total')?'totalRow' : \n\t\t(SummaryRow.columnRowName==='Buffer')? 'bufferRow': \n\t\t(SummaryRow.columnRowName==='Non Delivery Sub Total')? 'nonDeliverySubTotalRow':\n\t\t(SummaryRow.columnRowName==='Delivery Total')? 'deliveryTotalRow':\n\t\t'notTotalRow'\">\n\t\t\t{{SummaryRow.columnRowName}} </td>\n\t</ng-container>\n\n\t<ng-container matColumnDef=\"totalOffshore\">\n\t\t<th mat-header-cell *matHeaderCellDef> Total Off shore </th>\n\t\t<td mat-cell *matCellDef=\"let SummaryRow\" [ngClass]=\"(SummaryRow.columnRowName==='Grand Total')?'totalRow' :  \t\t(SummaryRow.columnRowName==='Buffer')? 'bufferRow':  \t\t(SummaryRow.columnRowName==='Non Delivery Sub Total')? 'nonDeliverySubTotalRow': \t\t(SummaryRow.columnRowName==='Delivery Total')? 'deliveryTotalRow': \t\t'notTotalRow'\">\n\t\t\t{{SummaryRow.totalOffshore}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"totalOnsite\">\n\t\t<th mat-header-cell *matHeaderCellDef> Total On Site </th>\n\t\t<td mat-cell *matCellDef=\"let SummaryRow\" [ngClass]=\"(SummaryRow.columnRowName==='Grand Total')?'totalRow' :  \t\t(SummaryRow.columnRowName==='Buffer')? 'bufferRow':  \t\t(SummaryRow.columnRowName==='Non Delivery Sub Total')? 'nonDeliverySubTotalRow': \t\t(SummaryRow.columnRowName==='Delivery Total')? 'deliveryTotalRow': \t\t'notTotalRow'\">\n\t\t\t{{SummaryRow.totalOnsite}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"totalAllocated\">\n\t\t<th mat-header-cell *matHeaderCellDef> Total Allocated </th>\n\t\t<td mat-cell *matCellDef=\"let SummaryRow\" [ngClass]=\"(SummaryRow.columnRowName==='Grand Total')?'totalRow' :  \t\t(SummaryRow.columnRowName==='Buffer')? 'bufferRow':  \t\t(SummaryRow.columnRowName==='Non Delivery Sub Total')? 'nonDeliverySubTotalRow': \t\t(SummaryRow.columnRowName==='Delivery Total')? 'deliveryTotalRow': \t\t'notTotalRow'\">\n\t\t\t{{SummaryRow.totalAllocated}} </td>\n\t</ng-container>\n\n\t<ng-container matColumnDef=\"unbilledOffshore\">\n\t\t<th mat-header-cell *matHeaderCellDef> Unbilled Offshore </th>\n\t\t<td mat-cell *matCellDef=\"let SummaryRow\" [ngClass]=\"(SummaryRow.columnRowName==='Grand Total')?'totalRow' :  \t\t(SummaryRow.columnRowName==='Buffer')? 'bufferRow':  \t\t(SummaryRow.columnRowName==='Non Delivery Sub Total')? 'nonDeliverySubTotalRow': \t\t(SummaryRow.columnRowName==='Delivery Total')? 'deliveryTotalRow': \t\t'notTotalRow'\">\n\t\t\t{{SummaryRow.unbilledOffshore}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"unbilledOnsite\">\n\t\t<th mat-header-cell *matHeaderCellDef> Unbilled On Site </th>\n\t\t<td mat-cell *matCellDef=\"let SummaryRow\" [ngClass]=\"(SummaryRow.columnRowName==='Grand Total')?'totalRow' :  \t\t(SummaryRow.columnRowName==='Buffer')? 'bufferRow':  \t\t(SummaryRow.columnRowName==='Non Delivery Sub Total')? 'nonDeliverySubTotalRow': \t\t(SummaryRow.columnRowName==='Delivery Total')? 'deliveryTotalRow': \t\t'notTotalRow'\">\n\t\t\t{{SummaryRow.unbilledOnsite}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"doNOTBILL\">\n\t\t<th mat-header-cell *matHeaderCellDef> Do Not Bill </th>\n\t\t<td mat-cell *matCellDef=\"let SummaryRow\" [ngClass]=\"(SummaryRow.columnRowName==='Grand Total')?'totalRow' :  \t\t(SummaryRow.columnRowName==='Buffer')? 'bufferRow':  \t\t(SummaryRow.columnRowName==='Non Delivery Sub Total')? 'nonDeliverySubTotalRow': \t\t(SummaryRow.columnRowName==='Delivery Total')? 'deliveryTotalRow': \t\t'notTotalRow'\">\n\t\t\t{{SummaryRow.doNOTBILL}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"totalUnbilled\">\n\t\t<th mat-header-cell *matHeaderCellDef> Total Unbilled </th>\n\t\t<td mat-cell *matCellDef=\"let SummaryRow\" [ngClass]=\"(SummaryRow.columnRowName==='Grand Total')?'totalRow' :  \t\t(SummaryRow.columnRowName==='Buffer')? 'bufferRow':  \t\t(SummaryRow.columnRowName==='Non Delivery Sub Total')? 'nonDeliverySubTotalRow': \t\t(SummaryRow.columnRowName==='Delivery Total')? 'deliveryTotalRow': \t\t'notTotalRow'\">\n\t\t\t{{SummaryRow.totalUnbilled}} </td>\n\t</ng-container>\n\n\t<ng-container matColumnDef=\"billedOffshore\">\n\t\t<th mat-header-cell *matHeaderCellDef> Billed Offshore </th>\n\t\t<td mat-cell *matCellDef=\"let SummaryRow\" [ngClass]=\"(SummaryRow.columnRowName==='Grand Total')?'totalRow' : \n\t\t(SummaryRow.columnRowName==='Buffer')? 'bufferRow': \n\t\t(SummaryRow.columnRowName==='Non Delivery Sub Total')? 'nonDeliverySubTotalRow':\n\t\t(SummaryRow.columnRowName==='Delivery Total')? 'deliveryTotalRow':\n\t\t'notTotalRow'\">{{SummaryRow.billedOffshore}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"billedOnsite\">\n\t\t<th mat-header-cell *matHeaderCellDef> Billed Onsite </th>\n\t\t<td mat-cell *matCellDef=\"let SummaryRow\" [ngClass]=\"(SummaryRow.columnRowName==='Grand Total')?'totalRow' :  \t\t(SummaryRow.columnRowName==='Buffer')? 'bufferRow':  \t\t(SummaryRow.columnRowName==='Non Delivery Sub Total')? 'nonDeliverySubTotalRow': \t\t(SummaryRow.columnRowName==='Delivery Total')? 'deliveryTotalRow': \t\t'notTotalRow'\">\n\t\t\t{{SummaryRow.billedOnsite}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"totalBilled\">\n\t\t<th mat-header-cell *matHeaderCellDef> Total Billed </th>\n\t\t<td mat-cell *matCellDef=\"let SummaryRow\" [ngClass]=\"(SummaryRow.columnRowName==='Grand Total')?'totalRow' :  \t\t(SummaryRow.columnRowName==='Buffer')? 'bufferRow':  \t\t(SummaryRow.columnRowName==='Non Delivery Sub Total')? 'nonDeliverySubTotalRow': \t\t(SummaryRow.columnRowName==='Delivery Total')? 'deliveryTotalRow': \t\t'notTotalRow'\">\n\t\t\t{{SummaryRow.totalBilled}} </td>\n\t</ng-container>\n\n\n\t<ng-container matColumnDef=\"perBilled\">\n\t\n\t\t<th mat-header-cell *matHeaderCellDef> % Billed </th>\n\t\t<td mat-cell *matCellDef=\"let SummaryRow\" [ngClass]=\"(SummaryRow.columnRowName==='Grand Total')?'totalRow' :  \t\t(SummaryRow.columnRowName==='Buffer')? 'bufferRow':  \t\t(SummaryRow.columnRowName==='Non Delivery Sub Total')? 'nonDeliverySubTotalRow': \t\t(SummaryRow.columnRowName==='Delivery Total')? 'deliveryTotalRow': \t\t'notTotalRow'\">\n\t\t\t{{(SummaryRow.totalAllocated===0)? (0| number:'2.2-2') :(SummaryRow.totalBilled / SummaryRow.totalAllocated *100) | number:'2.2-2'\n\t\t\t}}% </td>\n\t\n\t</ng-container>\n\n\t<tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n\t<tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>\n</table>\n<br><br>\n</div>\n"

/***/ }),

/***/ "./src/app/emp-summary-dashboard/emp-summary-dashboard.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/emp-summary-dashboard/emp-summary-dashboard.component.ts ***!
  \**************************************************************************/
/*! exports provided: EmpSummaryDashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmpSummaryDashboardComponent", function() { return EmpSummaryDashboardComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _summary_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./summary.service */ "./src/app/emp-summary-dashboard/summary.service.ts");
/* harmony import */ var _data_sharing_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../data.sharing.service */ "./src/app/data.sharing.service.ts");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.min.js");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jspdf-autotable */ "./node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var EmpSummaryDashboardComponent = /** @class */ (function () {
    function EmpSummaryDashboardComponent(summaryService, dataService) {
        var _this = this;
        this.summaryService = summaryService;
        this.dataService = dataService;
        this.displayedColumns = ['columnRowName', 'totalOffshore', 'totalOnsite', 'totalAllocated', 'unbilledOffshore', 'unbilledOnsite', 'doNOTBILL', 'totalUnbilled', 'billedOffshore', 'billedOnsite', 'totalBilled', 'perBilled'];
        this.print = function () {
            var doc = new jspdf__WEBPACK_IMPORTED_MODULE_3___default.a();
            console.log(_this.summaryList);
            doc.autoTable({
                //head: [['Log','', 'Amount']],
                head: [['columnRowName', 'totalOffshore', 'totalOnsite', 'totalAllocated', 'unbilledOffshore', 'unbilledOnsite', 'doNOTBILL', 'totalUnbilled', 'billedOffshore', 'billedOnsite', 'totalBilled', 'perBilled']],
                body: _this.summaryList //returning [["log1", "$100"], ["log2", "$200"]]
                //body:  [["log1", "$100"], ["log2", "$200"]]
            });
            doc.save('table.pdf');
        };
        this.getSummary();
        //dataService.currentEmployeeData = this.summaryList;
    }
    EmpSummaryDashboardComponent.prototype.getSummary = function () {
        var _this = this;
        this.summaryService.getSummary()
            .subscribe(function (summaryData) { return _this.summaryList = summaryData.summaryTable; });
        /**
            this.summaryTable = [{"columnRowName":"Delivery Projects with PO","totalOffshore":145,"totalOnsite":65,"totalAllocated":210,"unbilledOffshore":9,"unbilledOnsite":5,"doNOTBILL":0,"totalUnbilled":14,"billedOffshore":136,"billedOnsite":60,"totalBilled":196},{"columnRowName":"Delivery without PO","totalOffshore":0,"totalOnsite":0,"totalAllocated":0,"unbilledOffshore":0,"unbilledOnsite":0,"doNOTBILL":0,"totalUnbilled":0,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":0,"totalOnsite":0,"totalAllocated":0,"unbilledOffshore":0,"unbilledOnsite":0,"doNOTBILL":0,"totalUnbilled":0,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":6,"totalOnsite":1,"totalAllocated":7,"unbilledOffshore":6,"unbilledOnsite":1,"doNOTBILL":0,"totalUnbilled":7,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":4,"totalOnsite":1,"totalAllocated":5,"unbilledOffshore":4,"unbilledOnsite":1,"doNOTBILL":0,"totalUnbilled":5,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":22,"totalOnsite":0,"totalAllocated":22,"unbilledOffshore":22,"unbilledOnsite":0,"doNOTBILL":0,"totalUnbilled":22,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":0,"totalOnsite":0,"totalAllocated":0,"unbilledOffshore":0,"unbilledOnsite":0,"doNOTBILL":0,"totalUnbilled":0,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":10,"totalOnsite":10,"totalAllocated":20,"unbilledOffshore":10,"unbilledOnsite":10,"doNOTBILL":0,"totalUnbilled":20,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":6,"totalOnsite":4,"totalAllocated":10,"unbilledOffshore":6,"unbilledOnsite":4,"doNOTBILL":0,"totalUnbilled":10,"billedOffshore":0,"billedOnsite":0,"totalBilled":0}];
         */
    };
    EmpSummaryDashboardComponent.prototype.ngOnInit = function () {
        //this.getSummary();
    };
    EmpSummaryDashboardComponent.prototype.getLiveData = function () {
    };
    EmpSummaryDashboardComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-emp-summary-dashboard',
            template: __webpack_require__(/*! ./emp-summary-dashboard.component.html */ "./src/app/emp-summary-dashboard/emp-summary-dashboard.component.html"),
            styles: [__webpack_require__(/*! ./emp-summary-dashboard.component.css */ "./src/app/emp-summary-dashboard/emp-summary-dashboard.component.css")]
        }),
        __metadata("design:paramtypes", [_summary_service__WEBPACK_IMPORTED_MODULE_1__["SummaryService"], _data_sharing_service__WEBPACK_IMPORTED_MODULE_2__["DataService"]])
    ], EmpSummaryDashboardComponent);
    return EmpSummaryDashboardComponent;
}());



/***/ }),

/***/ "./src/app/emp-summary-dashboard/summary.service.ts":
/*!**********************************************************!*\
  !*** ./src/app/emp-summary-dashboard/summary.service.ts ***!
  \**********************************************************/
/*! exports provided: SummaryService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SummaryService", function() { return SummaryService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var SummaryService = /** @class */ (function () {
    function SummaryService(http) {
        this.http = http;
        this.summaryURL = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].summaryDataURL;
    }
    /** GET heroes from the server */
    SummaryService.prototype.getSummary = function () {
        return this.http.get(this.summaryURL)
            .pipe();
    };
    SummaryService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // TODO: better job of transforming error for user consumption
            /**this.log(`${operation} failed: ${error.message}`);*/
            // Let the app keep running by returning an empty result.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(result);
        };
    };
    SummaryService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], SummaryService);
    return SummaryService;
}());



/***/ }),

/***/ "./src/app/entry-exit-component/entry-exit-component.component.css":
/*!*************************************************************************!*\
  !*** ./src/app/entry-exit-component/entry-exit-component.component.css ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\r\n    width: 100%;\r\n  padding:15px 15px 5px 15px;\r\n      box-shadow: 0px 2px 14px 5px #dadada; \r\n      margin-top:10px;\r\n      border-radius:6px;\r\n  }\r\n  \r\n  tr:nth-child(even) {background-color: #f2f2f2;}\r\n  \r\n  th { background-color: #252323f6; \r\n    -webkit-text-fill-color: #d0d0df;\r\n    text-align: center;\r\n  }\r\n  \r\n  td, th:nth-child(even) {\r\n  border-collapse: collapse;\r\n  border: 1px dashed #ccc;;\r\n}\r\n  \r\n  tr:hover {background-color: #ccccff;}\r\n  \r\n  td:hover {background-color: #ccccff;}\r\n  \r\n  table {\r\n    border-collapse: collapse;\r\n  }\r\n  \r\n  table th{\r\n    font-weight: bold;\r\n    \r\n  }\r\n  \r\n  table td, table th {\r\n    \r\n    text-align: center;\r\n    \r\n  }\r\n  \r\n  table tr:first-child th {\r\n    border-top: 0;\r\n  }\r\n  \r\n  table tr:last-child td {\r\n    border-bottom: 0;\r\n  }\r\n  \r\n  table tr td:first-child,\r\n  table tr th:first-child {\r\n    border-left: 0;\r\n  }\r\n  \r\n  table tr td:last-child,\r\n  table tr th:last-child {\r\n    border-right: 0;\r\n  }\r\n  \r\n  #entry-exit-table-title{\r\n    width: 100%;\r\n    align-content: center;\r\n    text-align: center;\r\n     padding:15px 15px 5px 15px;\r\n      margin-top:10px;\r\n      border-radius:6px;\r\n      color: #333333;\r\n      font-size: 18px;\r\n      fill: #333333;\r\n      font-family: \"Lucida Grande\", \"Lucida Sans Unicode\", Arial, Helvetica, sans-serif;\r\n  \r\n  }\r\n  \r\n  #div-center{\r\n    text-align: center;\r\n  }\r\n  \r\n  #div-center{\r\n    text-align: center;\r\n  }\r\n\r\n"

/***/ }),

/***/ "./src/app/entry-exit-component/entry-exit-component.component.html":
/*!**************************************************************************!*\
  !*** ./src/app/entry-exit-component/entry-exit-component.component.html ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"entry-exit-table-title\">Entry Exit</div>\n<table mat-table [dataSource]=\"entryExitList\" title=\"EntryExit\">\n\n\t<ng-container matColumnDef=\"edate\">\n\t\t<th mat-header-cell *matHeaderCellDef> Date </th>\n\t\t<td mat-cell *matCellDef=\"let EntryExitRow\">\n\t\t\t{{EntryExitRow.date}} </td>\n\t</ng-container>\n\n\t<ng-container matColumnDef=\"status\">\n\t\t<th mat-header-cell *matHeaderCellDef> Status </th>\n\t\t<td mat-cell *matCellDef=\"let EntryExitRow\" >\n\t\t\t{{EntryExitRow.status}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"employeeID\">\n\t\t<th mat-header-cell *matHeaderCellDef> Employee ID </th>\n\t\t<td mat-cell *matCellDef=\"let EntryExitRow\" >\n\t\t\t{{EntryExitRow.employeeID}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"employeeName\">\n\t\t<th mat-header-cell *matHeaderCellDef> Employee Name </th>\n\t\t<td mat-cell *matCellDef=\"let EntryExitRow\" >\n\t\t\t{{EntryExitRow.employeeName}} </td>\n\t</ng-container>\n\n\t<ng-container matColumnDef=\"band\">\n\t\t<th mat-header-cell *matHeaderCellDef> Band </th>\n\t\t<td mat-cell *matCellDef=\"let EntryExitRow\" >\n\t\t\t{{EntryExitRow.band}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"projectDescription\">\n\t\t<th mat-header-cell *matHeaderCellDef> Project Description </th>\n\t\t<td mat-cell *matCellDef=\"let EntryExitRow\" >\n\t\t\t{{EntryExitRow.projectDescription}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"programManagerName\">\n\t\t<th mat-header-cell *matHeaderCellDef> Program Manager Name </th>\n\t\t<td mat-cell *matCellDef=\"let EntryExitRow\" >\n\t\t\t{{EntryExitRow.programManagerName}} </td>\n\t</ng-container>\n\n\t<tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n\t<tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>\n</table>\n<br><br>"

/***/ }),

/***/ "./src/app/entry-exit-component/entry-exit-component.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/entry-exit-component/entry-exit-component.component.ts ***!
  \************************************************************************/
/*! exports provided: EntryExitComponentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EntryExitComponentComponent", function() { return EntryExitComponentComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _entry_exit_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./entry-exit.service */ "./src/app/entry-exit-component/entry-exit.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var EntryExitComponentComponent = /** @class */ (function () {
    function EntryExitComponentComponent(entryExitService) {
        this.entryExitService = entryExitService;
        this.displayedColumns = ['edate', 'status', 'employeeID', 'employeeName', 'band', 'projectDescription', 'programManagerName'];
        this.getEntryExit();
    }
    EntryExitComponentComponent.prototype.getEntryExit = function () {
        var _this = this;
        this.entryExitService.getEntryExit()
            .subscribe(function (entryExitData) { return _this.entryExitList = entryExitData.entryExitTable; });
    };
    EntryExitComponentComponent.prototype.ngOnInit = function () {
        //this.getEntryExit();
    };
    EntryExitComponentComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-entry-exit-component',
            template: __webpack_require__(/*! ./entry-exit-component.component.html */ "./src/app/entry-exit-component/entry-exit-component.component.html"),
            styles: [__webpack_require__(/*! ./entry-exit-component.component.css */ "./src/app/entry-exit-component/entry-exit-component.component.css")]
        }),
        __metadata("design:paramtypes", [_entry_exit_service__WEBPACK_IMPORTED_MODULE_1__["EntryExitService"]])
    ], EntryExitComponentComponent);
    return EntryExitComponentComponent;
}());



/***/ }),

/***/ "./src/app/entry-exit-component/entry-exit.service.ts":
/*!************************************************************!*\
  !*** ./src/app/entry-exit-component/entry-exit.service.ts ***!
  \************************************************************/
/*! exports provided: EntryExitService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EntryExitService", function() { return EntryExitService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var EntryExitService = /** @class */ (function () {
    function EntryExitService(http) {
        this.http = http;
        this.entryExitURL = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].entryExitDataURL;
    }
    /** GET Data from the server */
    EntryExitService.prototype.getEntryExit = function () {
        return this.http.get(this.entryExitURL)
            .pipe();
    };
    EntryExitService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // TODO: better job of transforming error for user consumption
            /**this.log(`${operation} failed: ${error.message}`);*/
            // Let the app keep running by returning an empty result.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(result);
        };
    };
    EntryExitService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], EntryExitService);
    return EntryExitService;
}());



/***/ }),

/***/ "./src/app/file-upload/file-upload.component.css":
/*!*******************************************************!*\
  !*** ./src/app/file-upload/file-upload.component.css ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".upload-drop-zone {\n    height: 200px;\n    border-width: 2px;\n    margin-bottom: 20px;\n  }\n  \n  /* skin.css Style*/\n  \n  .upload-drop-zone {\n    color: #ccc;\n    border-style: dashed;\n    border-color: #ccc;\n    line-height: 200px;\n    text-align: center\n  }\n  \n  .upload-drop-zone.drop {\n    color: #222;\n    border-color: #222;\n}\n  \n  body { \n    font-family: Material Icons, Arial, sans-serif;\n    margin: 0;\n  }\n  \n  .mat-card{ \n    font-family: Material Icons, Arial, sans-serif;\n    margin: 0;\n  }\n  \n  .basic-container {\n    padding: 5px;\n  }\n  \n  .version-info {\n    font-size: 8pt;\n    float: right;\n  }\n\n\n  \n  "

/***/ }),

/***/ "./src/app/file-upload/file-upload.component.html":
/*!********************************************************!*\
  !*** ./src/app/file-upload/file-upload.component.html ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<div [fileUploadInputFor]=\"fileUploadQueue\" class=\"upload-drop-zone\">\n    Just drag and drop files here\n</div>\n \n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"yyyy_MM_dd\"  [(ngModel)]=\"dateInput\" value={{dateInput}}>\n</mat-form-field><br>\n\n\n<div style=\"width: 100%\">\n    <mat-file-upload-queue #fileUploadQueue\n        \n        [httpUrl]=\"fileUploadURL\" \n        [httpRequestParams]=\"{'dateInput': dateInput}\"\n        multiple>\n        \n        <mat-file-upload [file]=\"file\" [id]=\"i\" *ngFor=\"let file of fileUploadQueue.files; let i = index\"></mat-file-upload>\n    </mat-file-upload-queue>\n</div>\n\n<br>\n<button mat-raised-button (click)=\"runPythonScript()\">RUN SCRIPT</button>\n\n\n"

/***/ }),

/***/ "./src/app/file-upload/file-upload.component.ts":
/*!******************************************************!*\
  !*** ./src/app/file-upload/file-upload.component.ts ***!
  \******************************************************/
/*! exports provided: FileUploadComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileUploadComponent", function() { return FileUploadComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _file_upload_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./file-upload.service */ "./src/app/file-upload/file-upload.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var FileUploadComponent = /** @class */ (function () {
    function FileUploadComponent(fileUploadService, datepipe) {
        this.fileUploadService = fileUploadService;
        this.datepipe = datepipe;
        this.fileUploadURL = _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].fileUploadURL;
        this.dateInput = this.datepipe.transform(new Date(), 'yyyy-MM-dd');
    }
    FileUploadComponent.prototype.ngOnInit = function () {
    };
    FileUploadComponent.prototype.runPythonScript = function () {
        var _this = this;
        this.fileUploadService.runPythonFile(this.dateInput)
            .subscribe(function (response) { return _this.response = response; });
    };
    FileUploadComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-file-upload',
            template: __webpack_require__(/*! ./file-upload.component.html */ "./src/app/file-upload/file-upload.component.html"),
            styles: [__webpack_require__(/*! ./file-upload.component.css */ "./src/app/file-upload/file-upload.component.css")]
        }),
        __metadata("design:paramtypes", [_file_upload_service__WEBPACK_IMPORTED_MODULE_2__["FileUploadService"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"]])
    ], FileUploadComponent);
    return FileUploadComponent;
}());



/***/ }),

/***/ "./src/app/file-upload/file-upload.service.ts":
/*!****************************************************!*\
  !*** ./src/app/file-upload/file-upload.service.ts ***!
  \****************************************************/
/*! exports provided: FileUploadService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileUploadService", function() { return FileUploadService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var FileUploadService = /** @class */ (function () {
    function FileUploadService(http) {
        this.http = http;
        this.runPythonScript = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].runPythonScript;
    }
    FileUploadService.prototype.runPythonFile = function (dateP) {
        console.log(dateP);
        return this.http.post(this.runPythonScript, dateP, httpOptions)
            .pipe();
    };
    FileUploadService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], FileUploadService);
    return FileUploadService;
}());



/***/ }),

/***/ "./src/app/home/home.component.css":
/*!*****************************************!*\
  !*** ./src/app/home/home.component.css ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/home/home.component.html":
/*!******************************************!*\
  !*** ./src/app/home/home.component.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<div id=\"page-wrapper\">\n\n        <div class=\"summary-charts\">\n                <br><br>\n                <app-summary-charts></app-summary-charts>\n                </div>\n    \n    </div>"

/***/ }),

/***/ "./src/app/home/home.component.ts":
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var HomeComponent = /** @class */ (function () {
    function HomeComponent() {
    }
    HomeComponent.prototype.ngOnInit = function () {
    };
    HomeComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.component.html */ "./src/app/home/home.component.html"),
            styles: [__webpack_require__(/*! ./home.component.css */ "./src/app/home/home.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], HomeComponent);
    return HomeComponent;
}());



/***/ }),

/***/ "./src/app/project-reference-data-update/project-details.ts":
/*!******************************************************************!*\
  !*** ./src/app/project-reference-data-update/project-details.ts ***!
  \******************************************************************/
/*! exports provided: Project */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Project", function() { return Project; });
var Project = /** @class */ (function () {
    function Project() {
    }
    return Project;
}());



/***/ }),

/***/ "./src/app/project-reference-data-update/project-reference-data-update.component.css":
/*!*******************************************************************************************!*\
  !*** ./src/app/project-reference-data-update/project-reference-data-update.component.css ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".field-width {\n    width: 40%;\n  }\n  .text-width-height{\n      width: 40%;\n      height: 30pc;\n  }\n  "

/***/ }),

/***/ "./src/app/project-reference-data-update/project-reference-data-update.component.html":
/*!********************************************************************************************!*\
  !*** ./src/app/project-reference-data-update/project-reference-data-update.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"PROJECT ID\" [(ngModel)]=\"editProjectData.project_ID\" value={{editProjectData.project_ID}} [disabled]=\"!isNewEntry\" >\n</mat-form-field> &nbsp;\n\n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"CUSTOMER NAME\" [(ngModel)]=\"editProjectData.customer_NAME\" value={{editProjectData.customer_NAME}}>\n</mat-form-field> &nbsp;\n\n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"DELIVERY MANAGER\" [(ngModel)]=\"editProjectData.dm\" value={{editProjectData.dm}}>\n</mat-form-field> &nbsp;\n\n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"PROJECT DESCRIPTION\" [(ngModel)]=\"editProjectData.project_DESCRIPTION\" value={{editProjectData.project_DESCRIPTION}}>\n</mat-form-field> &nbsp;\n\n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"PROJECT TYPE\" [(ngModel)]=\"editProjectData.project_TYPE\" value={{editProjectData.project_TYPE}}>\n</mat-form-field> &nbsp;\n\n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"PO FLAG\" [(ngModel)]=\"editProjectData.po_FLAG\" value={{editProjectData.po_FLAG}}>\n</mat-form-field> &nbsp;\n\n\n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"DM\" [(ngModel)]=\"editProjectData.dm\" value={{editProjectData.dm}}>\n</mat-form-field> &nbsp;\n\n<mat-form-field class=\"field-width\">\n    <input matInput placeholder=\"SALES MANAGER\" [(ngModel)]=\"editProjectData.sales_MANAGER\" value={{editProjectData.sales_MANAGER}}>\n</mat-form-field> &nbsp;\n\n\n<mat-checkbox class=\"field-width\" [checked]=\"editProjectData.is_PROJECT_ACTIVE\" (change)=\"isProjectActiveUpdate()\">\n    ACTIVE</mat-checkbox>\n\n\n<br>\n<button (click)=\"saveProject(editProjectData)\" routerLink=\"/projects\" routerlink=\"active\">Save</button> &nbsp;\n<button routerLink=\"/projects\" routerlink=\"active\">Cancel </button>\n<br>"

/***/ }),

/***/ "./src/app/project-reference-data-update/project-reference-data-update.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/project-reference-data-update/project-reference-data-update.component.ts ***!
  \******************************************************************************************/
/*! exports provided: ProjectReferenceDataUpdateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectReferenceDataUpdateComponent", function() { return ProjectReferenceDataUpdateComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _save_project_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./save-project.service */ "./src/app/project-reference-data-update/save-project.service.ts");
/* harmony import */ var _data_sharing_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../data.sharing.service */ "./src/app/data.sharing.service.ts");
/* harmony import */ var _project_details__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./project-details */ "./src/app/project-reference-data-update/project-details.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var ProjectReferenceDataUpdateComponent = /** @class */ (function () {
    function ProjectReferenceDataUpdateComponent(dataService, router, saveProjectService) {
        this.dataService = dataService;
        this.router = router;
        this.saveProjectService = saveProjectService;
        this.isNewEntry = false;
        this.editProjectData = this.dataService.currentProjectDataForEdit;
        //console.log(this.editProjectData + ' ' + this.dataService.currentEmployeeDataForEdit );
        if (this.editProjectData === undefined) {
            this.router.navigateByUrl('');
        }
        if (this.editProjectData === null) {
            this.editProjectData = new _project_details__WEBPACK_IMPORTED_MODULE_4__["Project"]();
            //this.editProjectData.last_MODIFIED_TS = new Date();
        }
        if ((this.editProjectData !== undefined) && (this.editProjectData.project_ID === undefined)) {
            this.isNewEntry = true;
        }
        else {
            this.isNewEntry = false;
        }
        if ((this.editProjectData !== undefined) &&
            (this.editProjectData.project_ID === undefined ||
                (this.editProjectData.is_PROJECT_ACTIVE !== undefined &&
                    (this.editProjectData.is_PROJECT_ACTIVE === 'Y' ||
                        this.editProjectData.is_PROJECT_ACTIVE === 'y')))) {
            this.editProjectData.is_PROJECT_ACTIVE = true;
        }
        else {
            if (this.editProjectData !== undefined)
                this.editProjectData.is_PROJECT_ACTIVE = false;
        }
        //console.log("TCONST");
        //let date = new Date(this.editProjectData.billing_START_DATE);
        //console.log(this.editEmployeeData);
    }
    ProjectReferenceDataUpdateComponent.prototype.ngOnInit = function () {
    };
    ProjectReferenceDataUpdateComponent.prototype.isProjectActiveUpdate = function () {
        //console.log(this.editProjectData.is_PROJECT_ACTIVE);
        if ((this.editProjectData.is_PROJECT_ACTIVE !== undefined &&
            this.editProjectData.is_PROJECT_ACTIVE === true)) {
            // console.log("TRUE");
            this.editProjectData.is_PROJECT_ACTIVE = false;
        }
        else {
            // console.log("FALSE");
            this.editProjectData.is_PROJECT_ACTIVE = true;
        }
        //console.log(this.editProjectData.is_PROJECT_ACTIVE);
    };
    ProjectReferenceDataUpdateComponent.prototype.saveProject = function (editProjectData) {
        var _this = this;
        //console.log('savingProject' + editProjectData);
        if (editProjectData.is_PROJECT_ACTIVE === true) {
            editProjectData.is_PROJECT_ACTIVE = 'Y';
        }
        else {
            editProjectData.is_PROJECT_ACTIVE = 'N';
        }
        if (this.isNewEntry) {
            this.saveProjectService.addProduct(editProjectData).
                subscribe(function (response) { return _this.response = response; });
        }
        else {
            this.saveProjectService.updateProduct(editProjectData).
                subscribe(function (response) {
                _this.response = response;
                _this.router.navigateByUrl('projects');
            });
        }
    };
    ProjectReferenceDataUpdateComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-project-reference-data-update',
            template: __webpack_require__(/*! ./project-reference-data-update.component.html */ "./src/app/project-reference-data-update/project-reference-data-update.component.html"),
            styles: [__webpack_require__(/*! ./project-reference-data-update.component.css */ "./src/app/project-reference-data-update/project-reference-data-update.component.css")]
        }),
        __metadata("design:paramtypes", [_data_sharing_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"], _save_project_service__WEBPACK_IMPORTED_MODULE_2__["SaveProjectService"]])
    ], ProjectReferenceDataUpdateComponent);
    return ProjectReferenceDataUpdateComponent;
}());



/***/ }),

/***/ "./src/app/project-reference-data-update/save-project.service.ts":
/*!***********************************************************************!*\
  !*** ./src/app/project-reference-data-update/save-project.service.ts ***!
  \***********************************************************************/
/*! exports provided: SaveProjectService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaveProjectService", function() { return SaveProjectService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var SaveProjectService = /** @class */ (function () {
    function SaveProjectService(http) {
        this.http = http;
        this.updateProducteDataURL = _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].updateProductURL;
        this.addProducteDataURL = _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].addProductURL;
    }
    SaveProjectService.prototype.addProduct = function (editProjectData) {
        return this.http.post(this.addProducteDataURL, editProjectData, httpOptions)
            .pipe();
    };
    SaveProjectService.prototype.updateProduct = function (editProjectData) {
        return this.http.post(this.updateProducteDataURL, editProjectData, httpOptions)
            .pipe();
    };
    SaveProjectService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], SaveProjectService);
    return SaveProjectService;
}());



/***/ }),

/***/ "./src/app/project-reference-data/project-data-service.service.ts":
/*!************************************************************************!*\
  !*** ./src/app/project-reference-data/project-data-service.service.ts ***!
  \************************************************************************/
/*! exports provided: ProjectDataServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectDataServiceService", function() { return ProjectDataServiceService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var ProjectDataServiceService = /** @class */ (function () {
    function ProjectDataServiceService(http) {
        this.http = http;
        this.projectDataURL = _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].projectDataURL;
    }
    /** GET heroes from the server */
    ProjectDataServiceService.prototype.getProjectData = function () {
        return this.http.get(this.projectDataURL)
            .pipe();
    };
    ProjectDataServiceService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], ProjectDataServiceService);
    return ProjectDataServiceService;
}());



/***/ }),

/***/ "./src/app/project-reference-data/project-reference-data.component.css":
/*!*****************************************************************************!*\
  !*** ./src/app/project-reference-data/project-reference-data.component.css ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\n    width: 100%;\n  padding:15px 15px 5px 15px;\n      box-shadow: 0px 2px 14px 5px #dadada; \n      margin-top:10px;\n      border-radius:6px;\n  }\n  \n  tr:nth-child(even) {background-color: #f2f2f2;}\n  \n  th { background-color: #252323f6; \n    -webkit-text-fill-color: #d0d0df;\n    text-align: center;\n  }\n  \n  td, th:nth-child(even) {\n  border-collapse: collapse;\n  border: 1px dashed #ccc;;\n}\n  \n  tr:hover {background-color: #ccccff;}\n  \n  td:hover {background-color: #ccccff;}\n  \n  .totalRow{\n    background-color: rgba(0, 100, 0, 0.63);\n    font-weight: bold;\n  }\n  \n  .bufferRow{\n    background-color: rgba(255, 255, 0, 0.651);\n    font-weight: bold;\n  }\n  \n  .nonDeliverySubTotalRow{\n    background-color: rgba(210, 105, 30, 0.596);\n    font-weight: bold;\n  }\n  \n  .deliveryTotalRow{\n    background-color: rgba(210, 105, 30, 0.493);\n    font-weight: bold;\n  }\n  \n  table {\n    border-collapse: collapse;\n  }\n  \n  table th{\n    font-weight: bold;\n    \n  }\n  \n  table td, table th {\n    \n    text-align: center;\n  }\n  \n  table tr:first-child th {\n    border-top: 0;\n  }\n  \n  table tr:last-child td {\n    border-bottom: 0;\n  }\n  \n  table tr td:first-child,\n  table tr th:first-child {\n    border-left: 0;\n  }\n  \n  table tr td:last-child,\n  table tr th:last-child {\n    border-right: 0;\n  }\n  \n  #project-reference-data-table-title{\n    width: 100%;\n    align-content: center;\n    text-align: center;\n     padding:15px 15px 5px 15px;\n      margin-top:10px;\n      border-radius:6px;\n      color: #333333;\n      font-size: 18px;\n      fill: #333333;\n      font-family: \"Lucida Grande\", \"Lucida Sans Unicode\", Arial, Helvetica, sans-serif;\n  \n  }\n  \n  #div-center{\n    text-align: center;\n  }\n  \n  .summary-charts{\n    width: 40%;\n    float: right;\n  }\n  \n  .mat-form-field {\n    padding: 2%;\n    font-size: 14px;\n    width: 70%;\n  }"

/***/ }),

/***/ "./src/app/project-reference-data/project-reference-data.component.html":
/*!******************************************************************************!*\
  !*** ./src/app/project-reference-data/project-reference-data.component.html ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"project-reference-data-table-title\">Project List</div>\n<div class=\"mat-elevation-z8\">\n\t\t<mat-form-field>\n\t\t\t\t<input matInput (keyup)=\"applyFilter($event.target.value)\" placeholder=\"Filter\">\n\t\t\t  </mat-form-field>\n\n\t\t\t  <button (click)=\"addNewProject()\" routerLink = \"/addproject\" routerlink =\"active\">Add New Project </button>\n<table mat-table [dataSource]=\"dataSource\" title=\"ProjectList\" matSort class=\"mat-elevation-z8\">\n\n\t<ng-container matColumnDef=\"project_ID\">\n\t\t<th mat-header-cell *matHeaderCellDef mat-sort-header> PROJECT_ID </th>\n\t\t<td mat-cell *matCellDef=\"let element; \">\n         {{element.project_ID}} </td>\n\t</ng-container>\n\n\t<ng-container matColumnDef=\"customer_NAME\">\n\t\t<th mat-header-cell *matHeaderCellDef> CUSTOMER_NAME </th>\n\t\t<td mat-cell *matCellDef=\"let element\" >\n\t\t\t{{element.customer_NAME}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"project_DESCRIPTION\">\n\t\t<th mat-header-cell *matHeaderCellDef> PROJECT_DESCRIPTION </th>\n\t\t<td mat-cell *matCellDef=\"let element\" >\n\t\t\t{{element.project_DESCRIPTION}} </td>\n\t</ng-container>\n\t\n\t<ng-container matColumnDef=\"project_TYPE\">\n\t\t<th mat-header-cell *matHeaderCellDef mat-sort-header>  PROJECT_TYPE </th>\n\t\t<td mat-cell *matCellDef=\"let element\" >\n\t\t\t{{element.project_TYPE}} </td>\n\t</ng-container>\n\n\t<ng-container matColumnDef=\"dm\">\n\t\t<th mat-header-cell *matHeaderCellDef> DM </th>\n\t\t<td mat-cell *matCellDef=\"let element\" >\n\t\t\t{{element.dm}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"is_PROJECT_ACTIVE\">\n\t\t<th mat-header-cell *matHeaderCellDef> ACTIVE </th>\n\n\t\t<td mat-cell *matCellDef=\"let element\" disabled>\n\t\t\t\t<mat-checkbox \n\t\t\t\t\t\t\t  [checked]=\"(element.is_PROJECT_ACTIVE!== null && element.is_PROJECT_ACTIVE === 'Y' )? true:false\"\n\t\t\t\t\t\t\t  [disabled]=\"true\" \n\t\t\t\t\t\t\t  >\n\n\t\t\t\t</mat-checkbox>\n\t\t</td>\n\t</ng-container>\n\t\n    <ng-container matColumnDef=\"onEdit\">\n        <th mat-header-cell *matHeaderCellDef> EDIT </th>\n        <td mat-cell *matCellDef=\"let element; let i = index;\" >\n\t\t\t\n\t\t\t\t<button (click)=\"edit(i)\" routerLink = \"/updateproject\" routerlink =\"active\">Edit </button>\n\t\t\t\n        </td>\n      </ng-container>\n\t \n\t<tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n\t<tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>\n</table>\n<mat-paginator [pageSizeOptions]=\"[10, 25, 50]\" showFirstLastButtons></mat-paginator>\n</div>\n<br><br>\n"

/***/ }),

/***/ "./src/app/project-reference-data/project-reference-data.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/project-reference-data/project-reference-data.component.ts ***!
  \****************************************************************************/
/*! exports provided: ProjectReferenceDataComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectReferenceDataComponent", function() { return ProjectReferenceDataComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _data_sharing_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data.sharing.service */ "./src/app/data.sharing.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _project_data_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./project-data-service.service */ "./src/app/project-reference-data/project-data-service.service.ts");
/* harmony import */ var _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/cdk/collections */ "./node_modules/@angular/cdk/esm5/collections.es5.js");
/* harmony import */ var _project_reference_data_update_project_details__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../project-reference-data-update/project-details */ "./src/app/project-reference-data-update/project-details.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var ProjectReferenceDataComponent = /** @class */ (function () {
    function ProjectReferenceDataComponent(projectDataServiceService, dataService) {
        this.projectDataServiceService = projectDataServiceService;
        this.dataService = dataService;
        this.displayedColumns = ['project_ID', 'customer_NAME', 'project_DESCRIPTION', 'project_TYPE', 'dm', 'is_PROJECT_ACTIVE', 'onEdit'];
        this.getProjectData();
    }
    ProjectReferenceDataComponent.prototype.applyFilter = function (filterValue) {
        this.dataSource.filter = filterValue.trim().toLowerCase();
    };
    ProjectReferenceDataComponent.prototype.ngOnInit = function () {
    };
    ProjectReferenceDataComponent.prototype.getProjectData = function () {
        var _this = this;
        this.projectDataServiceService.getProjectData()
            .subscribe(function (projectData) {
            _this.projectList = projectData;
            _this.projectList.forEach(function (employee) {
                if (null !== employee.billing_START_DATE) {
                    var date = new Date(employee.billing_START_DATE);
                    //console.log(date);
                    employee.billing_START_DATE = date;
                    _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](_this.projectList);
                    _this.selection = new _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_4__["SelectionModel"](true, []);
                    _this.dataSource.paginator = _this.paginator;
                    _this.dataSource.sort = _this.sort;
                    _this.applyFilter('');
                }
            });
        });
    };
    ProjectReferenceDataComponent.prototype.addNewProject = function () {
        this.dataService.currentProjectDataForEdit = new _project_reference_data_update_project_details__WEBPACK_IMPORTED_MODULE_5__["Project"]();
        //console.log('addNewProject ' + this.dataService.currentProjectDataForEdit);
    };
    ProjectReferenceDataComponent.prototype.edit = function (i) {
        this.dataService.currentProjectDataForEdit = this.projectList[i];
        //console.log(this.dataService.currentProjectDataForEdit);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_angular_material__WEBPACK_IMPORTED_MODULE_2__["MatPaginator"]),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatPaginator"])
    ], ProjectReferenceDataComponent.prototype, "paginator", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSort"]),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSort"])
    ], ProjectReferenceDataComponent.prototype, "sort", void 0);
    ProjectReferenceDataComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-project-reference-data',
            template: __webpack_require__(/*! ./project-reference-data.component.html */ "./src/app/project-reference-data/project-reference-data.component.html"),
            styles: [__webpack_require__(/*! ./project-reference-data.component.css */ "./src/app/project-reference-data/project-reference-data.component.css")]
        }),
        __metadata("design:paramtypes", [_project_data_service_service__WEBPACK_IMPORTED_MODULE_3__["ProjectDataServiceService"], _data_sharing_service__WEBPACK_IMPORTED_MODULE_1__["DataService"]])
    ], ProjectReferenceDataComponent);
    return ProjectReferenceDataComponent;
}());



/***/ }),

/***/ "./src/app/summary-charts/summary-charts.component.css":
/*!*************************************************************!*\
  !*** ./src/app/summary-charts/summary-charts.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/summary-charts/summary-charts.component.html":
/*!**************************************************************!*\
  !*** ./src/app/summary-charts/summary-charts.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div #container></div>\n"

/***/ }),

/***/ "./src/app/summary-charts/summary-charts.component.ts":
/*!************************************************************!*\
  !*** ./src/app/summary-charts/summary-charts.component.ts ***!
  \************************************************************/
/*! exports provided: SummaryChartsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SummaryChartsComponent", function() { return SummaryChartsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var highcharts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! highcharts */ "./node_modules/highcharts/highcharts.js");
/* harmony import */ var highcharts__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(highcharts__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var highcharts_highcharts_more__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! highcharts/highcharts-more */ "./node_modules/highcharts/highcharts-more.js");
/* harmony import */ var highcharts_highcharts_more__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(highcharts_highcharts_more__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! highcharts/modules/drilldown */ "./node_modules/highcharts/modules/drilldown.js");
/* harmony import */ var highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! highcharts/modules/exporting */ "./node_modules/highcharts/modules/exporting.js");
/* harmony import */ var highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _summary_charts_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./summary-charts.service */ "./src/app/summary-charts/summary-charts.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



highcharts_highcharts_more__WEBPACK_IMPORTED_MODULE_2___default()(highcharts__WEBPACK_IMPORTED_MODULE_1__);

highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_3___default()(highcharts__WEBPACK_IMPORTED_MODULE_1__);
// Load the exporting module.

// Initialize exporting module.
highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_4___default()(highcharts__WEBPACK_IMPORTED_MODULE_1__);


var SummaryChartsComponent = /** @class */ (function () {
    function SummaryChartsComponent(summaryChartsService) {
        //summaryChartsService.readValues();
        //this.setChartValue() ;
        this.summaryChartsService = summaryChartsService;
    }
    SummaryChartsComponent.prototype.ngOnInit = function () {
        var _this = this;
        setTimeout(function () {
            _this.offshoreBillablePerc = ((_this.summaryChartsService.OffshoreBillable === 0) ? 0 :
                ((_this.summaryChartsService.OffshoreBillable) * 100 /
                    (_this.summaryChartsService.OffshoreBillable
                        + _this.summaryChartsService.OffshoreUnbillable
                        + _this.summaryChartsService.OnsiteBillable
                        + _this.summaryChartsService.OnsiteUnbillable)));
            _this.OffshoreUnbillable = (_this.summaryChartsService.OffshoreUnbillable === 0) ? 0 :
                ((_this.summaryChartsService.OffshoreUnbillable) * 100 /
                    (_this.summaryChartsService.OffshoreBillable
                        + _this.summaryChartsService.OffshoreUnbillable
                        + _this.summaryChartsService.OnsiteBillable
                        + _this.summaryChartsService.OnsiteUnbillable));
            _this.OnsiteBillable = (_this.summaryChartsService.OnsiteBillable === 0) ? 0 :
                ((_this.summaryChartsService.OnsiteBillable) * 100 /
                    (_this.summaryChartsService.OffshoreBillable
                        + _this.summaryChartsService.OffshoreUnbillable
                        + _this.summaryChartsService.OnsiteBillable
                        + _this.summaryChartsService.OnsiteUnbillable));
            _this.OnsiteUnbillable = (_this.summaryChartsService.OnsiteUnbillable === 0) ? 0 :
                ((_this.summaryChartsService.OnsiteUnbillable) * 100 /
                    (_this.summaryChartsService.OffshoreBillable
                        + _this.summaryChartsService.OffshoreUnbillable
                        + _this.summaryChartsService.OnsiteBillable
                        + _this.summaryChartsService.OnsiteUnbillable));
            //console.log(this.summaryChartsService);
            highcharts__WEBPACK_IMPORTED_MODULE_1__["chart"](_this.container.nativeElement, {
                // Created pie chart using Highchart
                chart: {
                    type: 'pie',
                    options3d: {
                        enabled: true,
                        alpha: 45
                    }
                },
                title: {
                    text: 'Summary using Pie chart'
                },
                subtitle: {
                    text: 'TME 6 Reports'
                },
                plotOptions: {
                    pie: {
                        innerSize: 10,
                        depth: 45
                    }
                },
                tooltip: {
                    headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                    pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
                },
                series: [{
                        name: 'Summary',
                        data: [
                            {
                                name: 'Offshore Billable : ' + _this.offshoreBillablePerc.toFixed(2) + '%',
                                y: _this.offshoreBillablePerc,
                                drilldown: 'Offshore-Billable-Project-Type'
                            },
                            {
                                name: 'Offshore Unbillable : ' + _this.OffshoreUnbillable.toFixed(2) + '%',
                                y: _this.OffshoreUnbillable,
                                drilldown: 'Offshore-Unbillable-Project-Type'
                            },
                            {
                                name: 'Onsite-Billable : ' + _this.OnsiteBillable.toFixed(2) + '%',
                                y: _this.OnsiteBillable,
                                drilldown: 'Onsite-Billable-Project-Type'
                            },
                            {
                                name: 'Onsite-Unbillable : ' + _this.OnsiteUnbillable.toFixed(2) + '%',
                                y: _this.OnsiteUnbillable,
                                drilldown: 'Onsite-Unbillable-Project-Type'
                            }
                        ]
                    }],
                drilldown: {
                    series: [
                        //Offshore Billable
                        {
                            name: 'Offshore Billable',
                            id: 'Offshore-Billable-Project-Type',
                            data: [
                                {
                                    name: 'Offshore-Billable-Delivery Total',
                                    y: (_this.summaryChartsService.OffshoreBillableDeliveryTotal === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreBillableDeliveryTotal /
                                            _this.summaryChartsService.OffshoreBillable) * 100,
                                    drilldown: 'Offshore-Billable-Project-Type-PO'
                                },
                                {
                                    name: 'Offshore-Billable-Non Delivery Sub Total',
                                    y: (_this.summaryChartsService.OffshoreBillableNonDeliverySubTotal === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreBillableNonDeliverySubTotal / _this.summaryChartsService.OffshoreBillable) * 100,
                                    drilldown: 'Offshore-Billable-Non Delivery Sub Total'
                                },
                                ['Offshore-Billable-Buffer', (_this.summaryChartsService.OffshoreBillableBuffer === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreBillableBuffer / _this.summaryChartsService.OffshoreBillable) * 100],
                            ]
                        },
                        {
                            name: 'Offshore-Billable-Project-Type-PO',
                            id: 'Offshore-Billable-Project-Type-PO',
                            data: [
                                ['Offshore-Billable-Delivery Projects with PO',
                                    (_this.summaryChartsService.OffshoreBillableDeliveryProjectswithPO === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreBillableDeliveryProjectswithPO /
                                            _this.summaryChartsService.OffshoreBillableDeliveryTotal) * 100
                                ],
                                ['Offshore-Billable-Delivery without PO',
                                    (_this.summaryChartsService.OffshoreBillableDeliverywithoutPO === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreBillableDeliverywithoutPO /
                                            _this.summaryChartsService.OffshoreBillableDeliveryTotal) * 100
                                ]
                            ]
                        },
                        {
                            name: 'Offshore-Billable-Non Delivery Sub Total',
                            id: 'Offshore-Billable-Non Delivery Sub Total',
                            data: [
                                ['Delivery WD',
                                    (_this.summaryChartsService.OffshoreBillableDeliveryWD === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreBillableDeliveryWD /
                                            _this.summaryChartsService.OffshoreBillableNonDeliverySubTotal) * 100
                                ],
                                ['ME No PO Americas',
                                    (_this.summaryChartsService.OffshoreBillableMENoPOAmericas === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreBillableMENoPOAmericas /
                                            _this.summaryChartsService.OffshoreBillableNonDeliverySubTotal) * 100
                                ],
                                ['Other Investment',
                                    (_this.summaryChartsService.OffshoreBillableOtherInvestment === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreBillableOtherInvestment /
                                            _this.summaryChartsService.OffshoreBillableNonDeliverySubTotal) * 100
                                ],
                                ['Pipeline Project',
                                    (_this.summaryChartsService.OffshoreBillablePipelineProject === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreBillablePipelineProject /
                                            _this.summaryChartsService.OffshoreBillableNonDeliverySubTotal) * 100],
                                ['Management Project',
                                    (_this.summaryChartsService.OffshoreBillableManagementProject === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreBillableManagementProject /
                                            _this.summaryChartsService.OffshoreBillableNonDeliverySubTotal) * 100]
                            ]
                        },
                        //Offshore Unbillable
                        {
                            name: 'Offshore-Unbillable',
                            id: 'Offshore-Unbillable-Project-Type',
                            data: [
                                {
                                    name: 'Offshore-Unbillable-Delivery Total',
                                    y: (_this.summaryChartsService.OffshoreUnbillableDeliveryTotal === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreUnbillableDeliveryTotal /
                                            _this.summaryChartsService.OffshoreUnbillable) * 100,
                                    drilldown: 'Offshore-Unbillable-Project-Type-PO'
                                },
                                {
                                    name: 'Offshore-Unbillable-Non Delivery Sub Total',
                                    y: (_this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal /
                                            _this.summaryChartsService.OffshoreUnbillable) * 100,
                                    drilldown: 'Offshore-Unbillable-Non Delivery Sub Total'
                                },
                                ['Offshore-Unbillable-Buffer',
                                    (_this.summaryChartsService.OffshoreUnbillableBuffer === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreUnbillableBuffer /
                                            _this.summaryChartsService.OffshoreUnbillable) * 100,
                                ],
                            ]
                        },
                        {
                            name: 'Offshore-Unbillable-Project-Type-PO',
                            id: 'Offshore-Unbillable-Project-Type-PO',
                            data: [
                                ['Offshore-Unbillable-Delivery Projects with PO',
                                    (_this.summaryChartsService.OffshoreUnbillableDeliveryProjectswithPO === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreUnbillableDeliveryProjectswithPO /
                                            _this.summaryChartsService.OffshoreUnbillableDeliveryTotal) * 100,
                                ],
                                ['Offshore-Unbillable-Delivery without PO',
                                    (_this.summaryChartsService.OffshoreUnbillableDeliverywithoutPO === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreUnbillableDeliverywithoutPO /
                                            _this.summaryChartsService.OffshoreUnbillableDeliveryTotal) * 100,
                                ]
                            ]
                        },
                        {
                            name: 'Offshore-Unbillable-Non Delivery Sub Total',
                            id: 'Offshore-Unbillable-Non Delivery Sub Total',
                            data: [
                                ['Delivery WD',
                                    (_this.summaryChartsService.OffshoreUnbillableDeliveryWD === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreUnbillableDeliveryWD /
                                            _this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal) * 100
                                ],
                                ['ME No PO Americas',
                                    (_this.summaryChartsService.OffshoreUnbillableMENoPOAmericas === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreUnbillableMENoPOAmericas /
                                            _this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal) * 100
                                ],
                                ['Other Investment',
                                    (_this.summaryChartsService.OffshoreUnbillableOtherInvestment === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreUnbillableOtherInvestment /
                                            _this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal) * 100
                                ],
                                ['Pipeline Project',
                                    (_this.summaryChartsService.OffshoreUnbillablePipelineProject === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreUnbillablePipelineProject /
                                            _this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal) * 100
                                ],
                                ['Management Project',
                                    (_this.summaryChartsService.OffshoreUnbillableManagementProject === 0) ? 0 :
                                        (_this.summaryChartsService.OffshoreUnbillableManagementProject /
                                            _this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal) * 100
                                ]
                            ]
                        },
                        //Onsite Billable
                        {
                            name: 'Onsite Billable',
                            id: 'Onsite-Billable-Project-Type',
                            data: [
                                {
                                    name: 'Onsite-Billable-Delivery Total',
                                    y: (_this.summaryChartsService.OnsiteBillableDeliveryTotal === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteBillableDeliveryTotal /
                                            _this.summaryChartsService.OnsiteBillable) * 100,
                                    drilldown: 'Onsite-Billable-Project-Type-PO'
                                },
                                {
                                    name: 'Onsite-Billable-Non Delivery Sub Total',
                                    y: (_this.summaryChartsService.OnsiteBillableNonDeliverySubTotal === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteBillableNonDeliverySubTotal / _this.summaryChartsService.OnsiteBillable) * 100,
                                    drilldown: 'Onsite-Billable-Non Delivery Sub Total'
                                },
                                ['Onsite-Billable-Buffer', (_this.summaryChartsService.OnsiteBillableBuffer === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteBillableBuffer / _this.summaryChartsService.OnsiteBillable) * 100],
                            ]
                        },
                        {
                            name: 'Onsite-Billable-Project-Type-PO',
                            id: 'Onsite-Billable-Project-Type-PO',
                            data: [
                                ['Onsite-Billable-Delivery Projects with PO',
                                    (_this.summaryChartsService.OnsiteBillableDeliveryProjectswithPO === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteBillableDeliveryProjectswithPO /
                                            _this.summaryChartsService.OnsiteBillableDeliveryTotal) * 100
                                ],
                                ['Onsite-Billable-Delivery without PO',
                                    (_this.summaryChartsService.OnsiteBillableDeliverywithoutPO === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteBillableDeliverywithoutPO /
                                            _this.summaryChartsService.OnsiteBillableDeliveryTotal) * 100
                                ]
                            ]
                        },
                        {
                            name: 'Onsite-Billable-Non Delivery Sub Total',
                            id: 'Onsite-Billable-Non Delivery Sub Total',
                            data: [
                                ['Delivery WD',
                                    (_this.summaryChartsService.OnsiteBillableDeliveryWD === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteBillableDeliveryWD /
                                            _this.summaryChartsService.OnsiteBillableNonDeliverySubTotal) * 100
                                ],
                                ['ME No PO Americas',
                                    (_this.summaryChartsService.OnsiteBillableMENoPOAmericas === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteBillableMENoPOAmericas /
                                            _this.summaryChartsService.OnsiteBillableNonDeliverySubTotal) * 100
                                ],
                                ['Other Investment',
                                    (_this.summaryChartsService.OnsiteBillableOtherInvestment === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteBillableOtherInvestment /
                                            _this.summaryChartsService.OnsiteBillableNonDeliverySubTotal) * 100
                                ],
                                ['Pipeline Project',
                                    (_this.summaryChartsService.OnsiteBillablePipelineProject === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteBillablePipelineProject /
                                            _this.summaryChartsService.OnsiteBillableNonDeliverySubTotal) * 100],
                                ['Management Project',
                                    (_this.summaryChartsService.OnsiteBillableManagementProject === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteBillableManagementProject /
                                            _this.summaryChartsService.OnsiteBillableNonDeliverySubTotal) * 100]
                            ]
                        },
                        //Onsite Unbillable
                        {
                            name: 'Onsite-Unbillable',
                            id: 'Onsite-Unbillable-Project-Type',
                            data: [
                                {
                                    name: 'Onsite-Unbillable-Delivery Total',
                                    y: (_this.summaryChartsService.OnsiteUnbillableDeliveryTotal === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteUnbillableDeliveryTotal /
                                            _this.summaryChartsService.OnsiteUnbillable) * 100,
                                    drilldown: 'Onsite-Unbillable-Project-Type-PO'
                                },
                                {
                                    name: 'Onsite-Unbillable-Non Delivery Sub Total',
                                    y: (_this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal /
                                            _this.summaryChartsService.OnsiteUnbillable) * 100,
                                    drilldown: 'Onsite-Unbillable-Non Delivery Sub Total'
                                },
                                ['Onsite-Unbillable-Buffer',
                                    (_this.summaryChartsService.OnsiteUnbillableBuffer === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteUnbillableBuffer /
                                            _this.summaryChartsService.OnsiteUnbillable) * 100,
                                ],
                            ]
                        },
                        {
                            name: 'Onsite-Unbillable-Project-Type-PO',
                            id: 'Onsite-Unbillable-Project-Type-PO',
                            data: [
                                ['Onsite-Unbillable-Delivery Projects with PO',
                                    (_this.summaryChartsService.OnsiteUnbillableDeliveryProjectswithPO === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteUnbillableDeliveryProjectswithPO /
                                            _this.summaryChartsService.OnsiteUnbillableDeliveryTotal) * 100,
                                ],
                                ['Onsite-Unbillable-Delivery without PO',
                                    (_this.summaryChartsService.OnsiteUnbillableDeliverywithoutPO === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteUnbillableDeliverywithoutPO /
                                            _this.summaryChartsService.OnsiteUnbillableDeliveryTotal) * 100,
                                ]
                            ]
                        },
                        {
                            name: 'Onsite-Unbillable-Non Delivery Sub Total',
                            id: 'Onsite-Unbillable-Non Delivery Sub Total',
                            data: [
                                ['Delivery WD',
                                    (_this.summaryChartsService.OnsiteUnbillableDeliveryWD === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteUnbillableDeliveryWD /
                                            _this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal) * 100
                                ],
                                ['ME No PO Americas',
                                    (_this.summaryChartsService.OnsiteUnbillableMENoPOAmericas === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteUnbillableMENoPOAmericas /
                                            _this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal) * 100
                                ],
                                ['Other Investment',
                                    (_this.summaryChartsService.OnsiteUnbillableOtherInvestment === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteUnbillableOtherInvestment /
                                            _this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal) * 100
                                ],
                                ['Pipeline Project',
                                    (_this.summaryChartsService.OnsiteUnbillablePipelineProject === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteUnbillablePipelineProject /
                                            _this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal) * 100
                                ],
                                ['Management Project',
                                    (_this.summaryChartsService.OnsiteUnbillableManagementProject === 0) ? 0 :
                                        (_this.summaryChartsService.OnsiteUnbillableManagementProject /
                                            _this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal) * 100
                                ]
                            ]
                        }
                    ]
                }
            });
        }, 500);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])("container", { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])
    ], SummaryChartsComponent.prototype, "container", void 0);
    SummaryChartsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-summary-charts',
            template: __webpack_require__(/*! ./summary-charts.component.html */ "./src/app/summary-charts/summary-charts.component.html"),
            styles: [__webpack_require__(/*! ./summary-charts.component.css */ "./src/app/summary-charts/summary-charts.component.css")]
        }),
        __metadata("design:paramtypes", [_summary_charts_service__WEBPACK_IMPORTED_MODULE_5__["SummaryChartsService"]])
    ], SummaryChartsComponent);
    return SummaryChartsComponent;
}());



/***/ }),

/***/ "./src/app/summary-charts/summary-charts.service.ts":
/*!**********************************************************!*\
  !*** ./src/app/summary-charts/summary-charts.service.ts ***!
  \**********************************************************/
/*! exports provided: SummaryChartsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SummaryChartsService", function() { return SummaryChartsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _emp_summary_dashboard_summary_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../emp-summary-dashboard/summary.service */ "./src/app/emp-summary-dashboard/summary.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var SummaryChartsService = /** @class */ (function () {
    function SummaryChartsService(summaryService) {
        this.summaryService = summaryService;
        this.OffshoreBillable = 0;
        this.OffshoreBillableDeliveryTotal = 0;
        this.OffshoreBillableDeliveryProjectswithPO = 0;
        this.OffshoreBillableDeliverywithoutPO = 0;
        this.OffshoreBillableNonDeliverySubTotal = 0;
        this.OffshoreBillableDeliveryWD = 0;
        this.OffshoreBillableMENoPOAmericas = 0;
        this.OffshoreBillableOtherInvestment = 0;
        this.OffshoreBillablePipelineProject = 0;
        this.OffshoreBillableManagementProject = 0;
        this.OffshoreBillableBuffer = 0;
        this.OffshoreUnbillable = 0;
        this.OffshoreUnbillableDeliveryTotal = 0;
        this.OffshoreUnbillableDeliveryProjectswithPO = 0;
        this.OffshoreUnbillableDeliverywithoutPO = 0;
        this.OffshoreUnbillableNonDeliverySubTotal = 0;
        this.OffshoreUnbillableDeliveryWD = 0;
        this.OffshoreUnbillableMENoPOAmericas = 0;
        this.OffshoreUnbillableOtherInvestment = 0;
        this.OffshoreUnbillablePipelineProject = 0;
        this.OffshoreUnbillableManagementProject = 0;
        this.OffshoreUnbillableBuffer = 0;
        this.OnsiteBillable = 0;
        this.OnsiteBillableDeliveryTotal = 0;
        this.OnsiteBillableDeliveryProjectswithPO = 0;
        this.OnsiteBillableDeliverywithoutPO = 0;
        this.OnsiteBillableNonDeliverySubTotal = 0;
        this.OnsiteBillableDeliveryWD = 0;
        this.OnsiteBillableMENoPOAmericas = 0;
        this.OnsiteBillableOtherInvestment = 0;
        this.OnsiteBillablePipelineProject = 0;
        this.OnsiteBillableManagementProject = 0;
        this.OnsiteBillableBuffer = 0;
        this.OnsiteUnbillable = 0;
        this.OnsiteUnbillableDeliveryTotal = 0;
        this.OnsiteUnbillableDeliveryProjectswithPO = 0;
        this.OnsiteUnbillableDeliverywithoutPO = 0;
        this.OnsiteUnbillableNonDeliverySubTotal = 0;
        this.OnsiteUnbillableDeliveryWD = 0;
        this.OnsiteUnbillableMENoPOAmericas = 0;
        this.OnsiteUnbillableOtherInvestment = 0;
        this.OnsiteUnbillablePipelineProject = 0;
        this.OnsiteUnbillableManagementProject = 0;
        this.OnsiteUnbillableBuffer = 0;
        this.readValues();
    }
    SummaryChartsService.prototype.resetValues = function () {
        this.OffshoreBillable = 0;
        this.OffshoreBillableDeliveryTotal = 0;
        this.OffshoreBillableDeliveryProjectswithPO = 0;
        this.OffshoreBillableDeliverywithoutPO = 0;
        this.OffshoreBillableNonDeliverySubTotal = 0;
        this.OffshoreBillableDeliveryWD = 0;
        this.OffshoreBillableMENoPOAmericas = 0;
        this.OffshoreBillableOtherInvestment = 0;
        this.OffshoreBillablePipelineProject = 0;
        this.OffshoreBillableManagementProject = 0;
        this.OffshoreBillableBuffer = 0;
        this.OffshoreUnbillable = 0;
        this.OffshoreUnbillableDeliveryTotal = 0;
        this.OffshoreUnbillableDeliveryProjectswithPO = 0;
        this.OffshoreUnbillableDeliverywithoutPO = 0;
        this.OffshoreUnbillableNonDeliverySubTotal = 0;
        this.OffshoreUnbillableDeliveryWD = 0;
        this.OffshoreUnbillableMENoPOAmericas = 0;
        this.OffshoreUnbillableOtherInvestment = 0;
        this.OffshoreUnbillablePipelineProject = 0;
        this.OffshoreUnbillableManagementProject = 0;
        this.OffshoreUnbillableBuffer = 0;
        this.OnsiteBillable = 0;
        this.OnsiteBillableDeliveryTotal = 0;
        this.OnsiteBillableDeliveryProjectswithPO = 0;
        this.OnsiteBillableDeliverywithoutPO = 0;
        this.OnsiteBillableNonDeliverySubTotal = 0;
        this.OnsiteBillableDeliveryWD = 0;
        this.OnsiteBillableMENoPOAmericas = 0;
        this.OnsiteBillableOtherInvestment = 0;
        this.OnsiteBillablePipelineProject = 0;
        this.OnsiteBillableManagementProject = 0;
        this.OnsiteBillableBuffer = 0;
        this.OnsiteUnbillable = 0;
        this.OnsiteUnbillableDeliveryTotal = 0;
        this.OnsiteUnbillableDeliveryProjectswithPO = 0;
        this.OnsiteUnbillableDeliverywithoutPO = 0;
        this.OnsiteUnbillableNonDeliverySubTotal = 0;
        this.OnsiteUnbillableDeliveryWD = 0;
        this.OnsiteUnbillableMENoPOAmericas = 0;
        this.OnsiteUnbillableOtherInvestment = 0;
        this.OnsiteUnbillablePipelineProject = 0;
        this.OnsiteUnbillableManagementProject = 0;
        this.OnsiteUnbillableBuffer = 0;
    };
    SummaryChartsService.prototype.readValues = function () {
        var _this = this;
        this.summaryService.getSummary()
            .subscribe(function (summaryData) {
            _this.setValues(summaryData.summaryTable);
        });
    };
    SummaryChartsService.prototype.setValues = function (summaryRow) {
        var _this = this;
        //console.log(summaryRow);
        if (summaryRow !== undefined) {
            this.resetValues();
            summaryRow.forEach(function (sr) {
                if (sr.columnRowName === 'Delivery Projects with PO') {
                    _this.OffshoreBillableDeliveryProjectswithPO = _this.OffshoreBillableDeliveryProjectswithPO + sr.billedOffshore;
                    _this.OnsiteBillableDeliveryProjectswithPO = _this.OnsiteBillableDeliveryProjectswithPO + sr.billedOnsite;
                    _this.OffshoreUnbillableDeliveryProjectswithPO = _this.OffshoreUnbillableDeliveryProjectswithPO + sr.unbilledOffshore;
                    _this.OnsiteUnbillableDeliveryProjectswithPO = _this.OnsiteUnbillableDeliveryProjectswithPO + sr.unbilledOnsite;
                }
                if (sr.columnRowName === 'Delivery without PO') {
                    _this.OffshoreBillableDeliverywithoutPO = _this.OffshoreBillableDeliverywithoutPO + sr.billedOffshore;
                    _this.OnsiteBillableDeliverywithoutPO = _this.OnsiteBillableDeliverywithoutPO + sr.billedOnsite;
                    _this.OffshoreUnbillableDeliverywithoutPO = _this.OffshoreUnbillableDeliverywithoutPO + sr.unbilledOffshore;
                    _this.OnsiteUnbillableDeliverywithoutPO = _this.OnsiteUnbillableDeliverywithoutPO + sr.unbilledOnsite;
                }
                //Delivery WD
                if (sr.columnRowName === 'Delivery WD') {
                    _this.OffshoreBillableDeliveryWD = _this.OffshoreBillableDeliveryWD + sr.billedOffshore;
                    _this.OnsiteBillableDeliveryWD = _this.OnsiteBillableDeliveryWD + sr.billedOnsite;
                    _this.OffshoreUnbillableDeliveryWD = _this.OffshoreUnbillableDeliveryWD + sr.unbilledOffshore;
                    _this.OnsiteUnbillableDeliveryWD = _this.OnsiteUnbillableDeliveryWD + sr.unbilledOnsite;
                }
                if (sr.columnRowName === 'ME No PO Americas') {
                    _this.OffshoreBillableMENoPOAmericas = _this.OffshoreBillableMENoPOAmericas + sr.billedOffshore;
                    _this.OnsiteBillableMENoPOAmericas = _this.OnsiteBillableMENoPOAmericas + sr.billedOnsite;
                    _this.OffshoreUnbillableMENoPOAmericas = _this.OffshoreUnbillableMENoPOAmericas + sr.unbilledOffshore;
                    _this.OnsiteUnbillableMENoPOAmericas = _this.OnsiteUnbillableMENoPOAmericas + sr.unbilledOnsite;
                }
                if (sr.columnRowName === 'Other Investment') {
                    _this.OffshoreBillableOtherInvestment = _this.OffshoreBillableOtherInvestment + sr.billedOffshore;
                    _this.OnsiteBillableOtherInvestment = _this.OnsiteBillableOtherInvestment + sr.billedOnsite;
                    _this.OffshoreUnbillableOtherInvestment = _this.OffshoreUnbillableOtherInvestment + sr.unbilledOffshore;
                    _this.OnsiteUnbillableOtherInvestment = _this.OnsiteUnbillableOtherInvestment + sr.unbilledOnsite;
                }
                if (sr.columnRowName === 'Pipeline Project') {
                    _this.OffshoreBillablePipelineProject = _this.OffshoreBillablePipelineProject + sr.billedOffshore;
                    _this.OnsiteBillablePipelineProject = _this.OnsiteBillablePipelineProject + sr.billedOnsite;
                    _this.OffshoreUnbillablePipelineProject = _this.OffshoreUnbillablePipelineProject + sr.unbilledOffshore;
                    _this.OnsiteUnbillablePipelineProject = _this.OnsiteUnbillablePipelineProject + sr.unbilledOnsite;
                }
                if (sr.columnRowName === 'Management Project') {
                    _this.OffshoreBillableManagementProject = _this.OffshoreBillableManagementProject + sr.billedOffshore;
                    _this.OnsiteBillableManagementProject = _this.OnsiteBillableManagementProject + sr.billedOnsite;
                    _this.OffshoreUnbillableManagementProject = _this.OffshoreUnbillableManagementProject + sr.unbilledOffshore;
                    _this.OnsiteUnbillableManagementProject = _this.OnsiteUnbillableManagementProject + sr.unbilledOnsite;
                }
                if (sr.columnRowName === 'Non Delivery Sub Total') {
                }
                if (sr.columnRowName === 'Buffer') {
                    _this.OffshoreBillableBuffer = _this.OffshoreBillableBuffer + sr.billedOffshore;
                    _this.OnsiteBillableBuffer = _this.OnsiteBillableBuffer + sr.billedOnsite;
                    _this.OffshoreUnbillableBuffer = _this.OffshoreUnbillableBuffer + sr.unbilledOffshore;
                    _this.OnsiteUnbillableBuffer = _this.OnsiteUnbillableBuffer + sr.unbilledOnsite;
                }
                if (sr.columnRowName === 'Grand Total') {
                }
            });
            this.OffshoreBillableDeliveryTotal = this.OffshoreBillableDeliveryProjectswithPO + this.OffshoreBillableDeliverywithoutPO;
            this.OnsiteBillableDeliveryTotal = this.OnsiteBillableDeliveryProjectswithPO + this.OnsiteBillableDeliverywithoutPO;
            this.OffshoreUnbillableDeliveryTotal = this.OffshoreUnbillableDeliveryProjectswithPO + this.OffshoreUnbillableDeliverywithoutPO;
            this.OnsiteUnbillableDeliveryTotal = this.OnsiteUnbillableDeliveryProjectswithPO + this.OnsiteUnbillableDeliverywithoutPO;
            this.OffshoreBillableNonDeliverySubTotal = this.OffshoreBillableDeliveryWD
                + this.OffshoreBillableMENoPOAmericas
                + this.OffshoreBillableOtherInvestment
                + this.OffshoreBillablePipelineProject
                + this.OffshoreBillableManagementProject;
            this.OffshoreUnbillableNonDeliverySubTotal = this.OffshoreUnbillableDeliveryWD
                + this.OffshoreUnbillableMENoPOAmericas
                + this.OffshoreUnbillableOtherInvestment
                + this.OffshoreUnbillablePipelineProject
                + this.OffshoreUnbillableManagementProject;
            this.OnsiteBillableNonDeliverySubTotal =
                this.OnsiteBillableDeliveryWD
                    + this.OnsiteBillableMENoPOAmericas
                    + this.OnsiteBillableOtherInvestment
                    + this.OnsiteBillablePipelineProject
                    + this.OnsiteBillableManagementProject;
            this.OnsiteUnbillableNonDeliverySubTotal =
                this.OnsiteUnbillableDeliveryWD
                    + this.OnsiteUnbillableMENoPOAmericas
                    + this.OnsiteUnbillableOtherInvestment
                    + this.OnsiteUnbillablePipelineProject
                    + this.OnsiteUnbillableManagementProject;
            this.OffshoreBillable = this.OffshoreBillableDeliveryTotal + this.OffshoreBillableNonDeliverySubTotal + this.OffshoreBillableBuffer;
            this.OffshoreUnbillable = this.OffshoreUnbillableDeliveryTotal + this.OffshoreUnbillableNonDeliverySubTotal + this.OffshoreUnbillableBuffer;
            this.OnsiteBillable = this.OnsiteBillableDeliveryTotal + this.OnsiteBillableNonDeliverySubTotal + this.OnsiteBillableBuffer;
            this.OnsiteUnbillable = this.OnsiteUnbillableDeliveryTotal + this.OnsiteUnbillableNonDeliverySubTotal + this.OnsiteUnbillableBuffer;
            //console.log(this.OffshoreBillable  + " " + this.OffshoreUnbillable + " " + this.OnsiteBillable + " " +  this.OnsiteUnbillable );
        }
    };
    SummaryChartsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_emp_summary_dashboard_summary_service__WEBPACK_IMPORTED_MODULE_1__["SummaryService"]])
    ], SummaryChartsService);
    return SummaryChartsService;
}());



/***/ }),

/***/ "./src/app/trends-chart/trends-chart.component.css":
/*!*********************************************************!*\
  !*** ./src/app/trends-chart/trends-chart.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/trends-chart/trends-chart.component.html":
/*!**********************************************************!*\
  !*** ./src/app/trends-chart/trends-chart.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div #container></div>\n<div id=\"container\"></div>\n"

/***/ }),

/***/ "./src/app/trends-chart/trends-chart.component.ts":
/*!********************************************************!*\
  !*** ./src/app/trends-chart/trends-chart.component.ts ***!
  \********************************************************/
/*! exports provided: TrendsChartComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrendsChartComponent", function() { return TrendsChartComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var highcharts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! highcharts */ "./node_modules/highcharts/highcharts.js");
/* harmony import */ var highcharts__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(highcharts__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var highcharts_highcharts_more__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! highcharts/highcharts-more */ "./node_modules/highcharts/highcharts-more.js");
/* harmony import */ var highcharts_highcharts_more__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(highcharts_highcharts_more__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! highcharts/modules/drilldown */ "./node_modules/highcharts/modules/drilldown.js");
/* harmony import */ var highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! highcharts/modules/exporting */ "./node_modules/highcharts/modules/exporting.js");
/* harmony import */ var highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _trends_trends_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../trends/trends.service */ "./src/app/trends/trends.service.ts");
/* harmony import */ var _trends_series__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./trends-series */ "./src/app/trends-chart/trends-series.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



highcharts_highcharts_more__WEBPACK_IMPORTED_MODULE_2___default()(highcharts__WEBPACK_IMPORTED_MODULE_1__);

highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_3___default()(highcharts__WEBPACK_IMPORTED_MODULE_1__);
// Load the exporting module.

// Initialize exporting module.
highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_4___default()(highcharts__WEBPACK_IMPORTED_MODULE_1__);


var TrendsChartComponent = /** @class */ (function () {
    function TrendsChartComponent(trendsService) {
        this.trendsService = trendsService;
        this.trendSeries = new _trends_series__WEBPACK_IMPORTED_MODULE_6__["TrendsSeries"];
        this.seriesList = [
            'DELIVERY_TOTAL',
            'NON_DELIVERY_SUB_TOTAL',
            'IBU_BUFFER',
            'TOTAL_UNBILLED',
            'TOTAL_BILLED',
            'UNBILLED_DELIVERY',
            'IBU_TOTAL'
        ];
    }
    TrendsChartComponent.prototype.getTrends = function () {
        var _this = this;
        this.trendsService.getTrends()
            .subscribe(function (trendsData) {
            _this.trendsList = trendsData;
            //console.log(this.trendsList);
            _this.refreshSeriesData(_this.trendsList);
        });
    };
    TrendsChartComponent.prototype.ngOnInit = function () {
        this.getTrends();
        this.chart = highcharts__WEBPACK_IMPORTED_MODULE_1__["chart"]('container', {
            title: {
                text: 'Trends for IBU'
            },
            subtitle: {
                text: 'Tech Mahindra'
            },
            yAxis: {
                title: {
                    text: 'Number of Employees'
                }
            },
            xAxis: {
                type: 'datetime',
                dateTimeLabelFormats: {
                    month: '%e. %b',
                    year: '%b'
                },
                title: {
                    text: 'Date'
                }
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle'
            },
            plotOptions: {
                series: {
                    label: {
                        connectorAllowed: false
                    }
                    // pointStart: Date.UTC(2014, 11, 2),
                }
            },
            series: [],
            responsive: {
                rules: [{
                        condition: {
                            maxWidth: 500
                        },
                        chartOptions: {
                            legend: {
                                layout: 'horizontal',
                                align: 'center',
                                verticalAlign: 'bottom'
                            }
                        }
                    }]
            }
        });
    };
    TrendsChartComponent.prototype.refreshSeriesData = function (trendsListP) {
        for (var i = 0; this.chart.series.length > 0; i++) {
            this.chart.series[0].remove(true);
        }
        this.getTrendSeries(trendsListP);
        //console.log(this.trendSeries);
        this.chart.addSeries({
            name: 'DELIVERY_TOTAL',
            data: this.trendSeries.DELIVERY_TOTAL
        });
        this.chart.addSeries({
            name: 'NON_DELIVERY_SUB_TOTAL',
            data: this.trendSeries.NON_DELIVERY_SUB_TOTAL
        });
        this.chart.addSeries({
            name: 'IBU_BUFFER',
            data: this.trendSeries.IBU_BUFFER
        });
        this.chart.addSeries({
            name: 'TOTAL_UNBILLED',
            data: this.trendSeries.TOTAL_UNBILLED
        });
        this.chart.addSeries({
            name: 'TOTAL_BILLED',
            data: this.trendSeries.TOTAL_BILLED
        });
        this.chart.addSeries({
            name: 'UNBILLED_DELIVERY',
            data: this.trendSeries.UNBILLED_DELIVERY
        });
        this.chart.addSeries({
            name: 'IBU_TOTAL',
            data: this.trendSeries.IBU_TOTAL
        });
    };
    TrendsChartComponent.prototype.getTrendSeries = function (trendsListPS) {
        this.trendSeries = new _trends_series__WEBPACK_IMPORTED_MODULE_6__["TrendsSeries"];
        for (var i = 0; i < trendsListPS.length; i++) {
            this.tempDate = new Date(trendsListPS[i].IT_DATE);
            //console.log(this.tempDate.getUTCDate());
            this.trendSeries.DELIVERY_TOTAL.push([Date.UTC(this.tempDate.getUTCFullYear(), this.tempDate.getUTCMonth(), this.tempDate.getUTCDate()), trendsListPS[i].delivery_TOTAL]);
            this.trendSeries.NON_DELIVERY_SUB_TOTAL.push([
                Date.UTC(this.tempDate.getUTCFullYear(), this.tempDate.getUTCMonth(), this.tempDate.getUTCDate()),
                trendsListPS[i].non_DELIVERY_SUB_TOTAL
            ]);
            this.trendSeries.IBU_BUFFER.push([Date.UTC(this.tempDate.getUTCFullYear(), this.tempDate.getUTCMonth(), this.tempDate.getUTCDate()),
                trendsListPS[i].ibu_BUFFER]);
            this.trendSeries.TOTAL_UNBILLED.push([Date.UTC(this.tempDate.getUTCFullYear(), this.tempDate.getUTCMonth(), this.tempDate.getUTCDate()),
                trendsListPS[i].total_UNBILLED]);
            this.trendSeries.TOTAL_BILLED.push([Date.UTC(this.tempDate.getUTCFullYear(), this.tempDate.getUTCMonth(), this.tempDate.getUTCDate()),
                trendsListPS[i].total_BILLED]);
            this.trendSeries.UNBILLED_DELIVERY.push([Date.UTC(this.tempDate.getUTCFullYear(), this.tempDate.getUTCMonth(), this.tempDate.getUTCDate()),
                trendsListPS[i].unbilled_DELIVERY]);
            this.trendSeries.IBU_TOTAL.push([Date.UTC(this.tempDate.getUTCFullYear(), this.tempDate.getUTCMonth(), this.tempDate.getUTCDate()),
                trendsListPS[i].ibu_TOTAL]);
        }
        //push(trendRow.IT_DATE);
        //this.trendSeries.EDATE.push( Date.UTC(new Date(trendRow.IT_DATE).getFullYear(), new Date(trendRow.IT_DATE).getDate() , new Date(trendRow.IT_DATE).getMonth()) );
        //});
    };
    TrendsChartComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-trends-chart',
            template: __webpack_require__(/*! ./trends-chart.component.html */ "./src/app/trends-chart/trends-chart.component.html"),
            styles: [__webpack_require__(/*! ./trends-chart.component.css */ "./src/app/trends-chart/trends-chart.component.css")]
        }),
        __metadata("design:paramtypes", [_trends_trends_service__WEBPACK_IMPORTED_MODULE_5__["TrendsService"]])
    ], TrendsChartComponent);
    return TrendsChartComponent;
}());



/***/ }),

/***/ "./src/app/trends-chart/trends-series.ts":
/*!***********************************************!*\
  !*** ./src/app/trends-chart/trends-series.ts ***!
  \***********************************************/
/*! exports provided: TrendsSeries */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrendsSeries", function() { return TrendsSeries; });
var TrendsSeries = /** @class */ (function () {
    function TrendsSeries() {
        //yaxis : number[] = [];
        this.data = [];
        this.DELIVERY_TOTAL = [];
        this.NON_DELIVERY_SUB_TOTAL = [];
        this.IBU_BUFFER = [];
        this.TOTAL_UNBILLED = [];
        this.TOTAL_BILLED = [];
        this.UNBILLED_DELIVERY = [];
        this.IBU_TOTAL = [];
    }
    return TrendsSeries;
}());



/***/ }),

/***/ "./src/app/trends/trends.component.css":
/*!*********************************************!*\
  !*** ./src/app/trends/trends.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\n    width: 100%;\n  padding:15px 15px 5px 15px;\n      box-shadow: 0px 2px 14px 5px #dadada; \n      margin-top:10px;\n      border-radius:6px;\n  }\n  \n  tr:nth-child(even) {background-color: #f2f2f2;}\n  \n  th { background-color: #252323f6; \n    -webkit-text-fill-color: #d0d0df;\n    text-align: center;\n  }\n  \n  td, th:nth-child(even) {\n  border-collapse: collapse;\n  border: 1px dashed #ccc;;\n}\n  \n  tr:hover {background-color: #ccccff;}\n  \n  td:hover {background-color: #ccccff;}\n  \n  table {\n    border-collapse: collapse;\n  }\n  \n  table th{\n    font-weight: bold;\n    \n  }\n  \n  table td, table th {\n    \n    text-align: center;\n    \n  }\n  \n  table tr:first-child th {\n    border-top: 0;\n  }\n  \n  table tr:last-child td {\n    border-bottom: 0;\n  }\n  \n  table tr td:first-child,\n  table tr th:first-child {\n    border-left: 0;\n  }\n  \n  table tr td:last-child,\n  table tr th:last-child {\n    border-right: 0;\n  }\n  \n  #trends-table-title{\n    width: 100%;\n    align-content: center;\n    text-align: center;\n     padding:15px 15px 5px 15px;\n      margin-top:10px;\n      border-radius:6px;\n      color: #333333;\n      font-size: 18px;\n      fill: #333333;\n      font-family: \"Lucida Grande\", \"Lucida Sans Unicode\", Arial, Helvetica, sans-serif;\n  \n  }\n  \n  #div-center{\n    text-align: center;\n  }\n  \n  #div-center{\n    text-align: center;\n  }\n\n"

/***/ }),

/***/ "./src/app/trends/trends.component.html":
/*!**********************************************!*\
  !*** ./src/app/trends/trends.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-trends-chart></app-trends-chart>\n<br><br>\n<div id=\"trends-table-title\">Trends</div>\n<table mat-table [dataSource]=\"trendsList\" title=\"trends\">\n\n\t<ng-container matColumnDef=\"IT_DATE\">\n\t\t<th mat-header-cell *matHeaderCellDef> Date </th>\n\t\t<td mat-cell *matCellDef=\"let trendsRow\">\n\t\t\t{{trendsRow.IT_DATE}} </td>\n\t</ng-container>\n\n\t<ng-container matColumnDef=\"delivery_TOTAL\">\n\t\t<th mat-header-cell *matHeaderCellDef> DELIVERY TOTAL </th>\n\t\t<td mat-cell *matCellDef=\"let trendsRow\" >\n\t\t\t{{trendsRow.delivery_TOTAL}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"non_DELIVERY_SUB_TOTAL\">\n\t\t<th mat-header-cell *matHeaderCellDef> NON DELIVERY SUB TOTAL </th>\n\t\t<td mat-cell *matCellDef=\"let trendsRow\" >\n\t\t\t{{trendsRow.non_DELIVERY_SUB_TOTAL}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"ibu_BUFFER\">\n\t\t<th mat-header-cell *matHeaderCellDef> IBU BUFFER </th>\n\t\t<td mat-cell *matCellDef=\"let trendsRow\" >\n\t\t\t{{trendsRow.ibu_BUFFER}} </td>\n\t</ng-container>\n\n\t<ng-container matColumnDef=\"total_UNBILLED\">\n\t\t<th mat-header-cell *matHeaderCellDef> TOTAL UNBILLED </th>\n\t\t<td mat-cell *matCellDef=\"let trendsRow\" >\n\t\t\t{{trendsRow.total_UNBILLED}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"total_BILLED\">\n\t\t<th mat-header-cell *matHeaderCellDef> TOTAL BILLED </th>\n\t\t<td mat-cell *matCellDef=\"let trendsRow\" >\n\t\t\t{{trendsRow.total_BILLED}} </td>\n\t</ng-container>\n\t<ng-container matColumnDef=\"unbilled_DELIVERY\">\n\t\t<th mat-header-cell *matHeaderCellDef> UNBILLED DELIVERY </th>\n\t\t<td mat-cell *matCellDef=\"let trendsRow\" >\n\t\t\t{{trendsRow.unbilled_DELIVERY}} </td>\n  </ng-container>\n  \n  <ng-container matColumnDef=\"ibu_TOTAL\">\n\t\t<th mat-header-cell *matHeaderCellDef> IBU TOTAL  </th>\n\t\t<td mat-cell *matCellDef=\"let trendsRow\" >\n\t\t\t{{trendsRow.ibu_TOTAL}} </td>\n\t</ng-container>\n\n\t<tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n\t<tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>\n</table>\n<br><br>"

/***/ }),

/***/ "./src/app/trends/trends.component.ts":
/*!********************************************!*\
  !*** ./src/app/trends/trends.component.ts ***!
  \********************************************/
/*! exports provided: TrendsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrendsComponent", function() { return TrendsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _trends_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./trends.service */ "./src/app/trends/trends.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var TrendsComponent = /** @class */ (function () {
    function TrendsComponent(trendsService) {
        this.trendsService = trendsService;
        this.displayedColumns = [
            'IT_DATE',
            'delivery_TOTAL',
            'non_DELIVERY_SUB_TOTAL',
            'ibu_BUFFER',
            'total_UNBILLED',
            'total_BILLED',
            'unbilled_DELIVERY',
            'ibu_TOTAL'
        ];
        this.getTrends();
    }
    TrendsComponent.prototype.getTrends = function () {
        var _this = this;
        this.trendsService.getTrends()
            .subscribe(function (trendsData) {
            _this.trendsList = trendsData;
        });
    };
    TrendsComponent.prototype.ngOnInit = function () {
    };
    TrendsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-trends',
            template: __webpack_require__(/*! ./trends.component.html */ "./src/app/trends/trends.component.html"),
            styles: [__webpack_require__(/*! ./trends.component.css */ "./src/app/trends/trends.component.css")]
        }),
        __metadata("design:paramtypes", [_trends_service__WEBPACK_IMPORTED_MODULE_1__["TrendsService"]])
    ], TrendsComponent);
    return TrendsComponent;
}());



/***/ }),

/***/ "./src/app/trends/trends.service.ts":
/*!******************************************!*\
  !*** ./src/app/trends/trends.service.ts ***!
  \******************************************/
/*! exports provided: TrendsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrendsService", function() { return TrendsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var TrendsService = /** @class */ (function () {
    function TrendsService(http) {
        this.http = http;
        this.trendsURL = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].trendsURL;
    }
    /** GET Data from the server */
    TrendsService.prototype.getTrends = function () {
        return this.http.get(this.trendsURL)
            .pipe();
    };
    TrendsService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // TODO: better job of transforming error for user consumption
            /**this.log(`${operation} failed: ${error.message}`);*/
            // Let the app keep running by returning an empty result.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(result);
        };
    };
    TrendsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], TrendsService);
    return TrendsService;
}());



/***/ }),

/***/ "./src/app/unbillable-data/unbillable-data.component.css":
/*!***************************************************************!*\
  !*** ./src/app/unbillable-data/unbillable-data.component.css ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\n    width: 100%;\n  padding:15px 15px 5px 15px;\n      box-shadow: 0px 2px 14px 5px #dadada; \n      margin-top:10px;\n      border-radius:6px;\n  }\n  \n  tr:nth-child(even) {background-color: #f2f2f2;}\n  \n  th { background-color: #252323f6; \n    -webkit-text-fill-color: #d0d0df;\n    text-align: center;\n  }\n  \n  td, th:nth-child(even) {\n  border-collapse: collapse;\n  border: 1px dashed #ccc;;\n}\n  \n  tr:hover {background-color: #ccccff;}\n  \n  td:hover {background-color: #ccccff;}\n  \n  .totalRow{\n    background-color: rgba(0, 100, 0, 0.63);\n    font-weight: bold;\n  }\n  \n  .bufferRow{\n    background-color: rgba(255, 255, 0, 0.651);\n    font-weight: bold;\n  }\n  \n  .nonDeliverySubTotalRow{\n    background-color: rgba(210, 105, 30, 0.596);\n    font-weight: bold;\n  }\n  \n  .deliveryTotalRow{\n    background-color: rgba(210, 105, 30, 0.493);\n    font-weight: bold;\n  }\n  \n  table {\n    border-collapse: collapse;\n  }\n  \n  table th{\n    font-weight: bold;\n    \n  }\n  \n  table td, table th {\n    \n    text-align: center;\n  }\n  \n  table tr:first-child th {\n    border-top: 0;\n    padding: 2%;\n  }\n  \n  table tr:last-child td {\n    border-bottom: 0;\n    padding: 2%;\n    text-align: center;\n    align-content: center;\n  }\n  \n  table tr td:first-child,\n  table tr th:first-child {\n    border-left: 0;\n    padding: 1%;\n  }\n  \n  table tr td:last-child,\n  table tr th:last-child {\n    border-right: 0;\n    padding: 1%;\n  }\n  \n  #unbilled-data-table-title{\n    width: 100%;\n    align-content: center;\n    text-align: center;\n     padding:15px 15px 5px 15px;\n      margin-top:10px;\n      border-radius:6px;\n      color: #333333;\n      font-size: 18px;\n      fill: #333333;\n      font-family: \"Lucida Grande\", \"Lucida Sans Unicode\", Arial, Helvetica, sans-serif;\n  \n  }\n  \n  #div-center{\n    text-align: center;\n  }\n  \n  .summary-charts{\n    width: 40%;\n    float: right;\n  }\n  \n  .mat-form-field {\n    padding: 2%;\n    font-size: 14px;\n    width: 80%;\n  }\n  \n  .field-width {\n    width: 25%;\n    padding: 2%\n  }"

/***/ }),

/***/ "./src/app/unbillable-data/unbillable-data.component.html":
/*!****************************************************************!*\
  !*** ./src/app/unbillable-data/unbillable-data.component.html ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"unbilled-data-table-title\">Unbilled Employee List</div>\n<div class=\"mat-elevation-z8\">\n\n\t<mat-form-field class=\"field-width\">\n\t\t<input matInput class=\"filter-input\" (keyup)=\"setEMPIDFilter($event.target.value)\" [(ngModel)]=\"empidfilter\" value={{empidfilter}}\n\t\t placeholder=\"EMP ID FILTER\">\n\t</mat-form-field>\n\t<mat-form-field class=\"field-width\">\n\t\t\t<input matInput class=\"filter-input\" (keyup)=\"setEmployeeName($event.target.value)\" [(ngModel)]=\"employeeNameFilter\"\n\t\t\t value={{employeeNameFilter}} placeholder=\"EMPLOYEE NAME\">\n\t</mat-form-field>\n\t<mat-form-field class=\"field-width\">\n\t\t<input matInput class=\"filter-input\" (keyup)=\"setProgramManagerName($event.target.value)\" [(ngModel)]=\"programManagerFilter\"\n\t\t value={{programManagerFilter}} placeholder=\"PROGRAM MANAGER NAME\">\n\t</mat-form-field>\n\t\n\t<div class=\"field-width\">\n\t<button mat-raised-button (click)=\"resetFilters()\">RESET FILTERS</button>\n</div>\n\n\n\n\n\n\t<table mat-table [dataSource]=\"dataSource\" title=\"UnbilledData\" matSort class=\"mat-elevation-z8\">\n\n\t\t<ng-container matColumnDef=\"empid\">\n\t\t\t<th mat-header-cell *matHeaderCellDef mat-sort-header>\n\t\t\t\tEMPLOYEE ID\n\t\t\t</th>\n\t\t\t<td mat-cell *matCellDef=\"let element; \">\n\t\t\t\t{{element.objCurrentEmployee.empid}} </td>\n\t\t</ng-container>\n\n\t\t<ng-container matColumnDef=\"emp_NAME\">\n\t\t\t<th mat-header-cell *matHeaderCellDef> EMPLOYEE NAME </th>\n\t\t\t<td mat-cell *matCellDef=\"let element\">\n\t\t\t\t{{element.objCurrentEmployee.emp_NAME}} </td>\n\t\t</ng-container>\n\t\t<ng-container matColumnDef=\"comments\">\n\t\t\t<th mat-header-cell *matHeaderCellDef> COMMENTS </th>\n\t\t\t<td mat-cell *matCellDef=\"let element\">\n\t\t\t\t{{element.comments}} </td>\n\t\t</ng-container>\n\n\t\t<ng-container matColumnDef=\"program_MANAGER_NAME\">\n\t\t\t<th mat-header-cell *matHeaderCellDef mat-sort-header> PROGRAM MANAGER </th>\n\t\t\t<td mat-cell *matCellDef=\"let element\">\n\t\t\t\t{{element.objCurrentEmployee.program_MANAGER_NAME}} </td>\n\t\t</ng-container>\n\n\t\t<ng-container matColumnDef=\"customer_NAME\">\n\t\t\t<th mat-header-cell *matHeaderCellDef> CUSTOMER </th>\n\t\t\t<td mat-cell *matCellDef=\"let element\">\n\t\t\t\t{{element.objCurrentEmployee.customer_NAME}} </td>\n\t\t</ng-container>\n\t\t<ng-container matColumnDef=\"category\">\n\t\t\t<th mat-header-cell *matHeaderCellDef> CATEGORY </th>\n\t\t\t<td mat-cell *matCellDef=\"let element\">\n\t\t\t\t{{(null!==element.category)?element.category.category:''}} </td>\n\t\t</ng-container>\n\n\t\t<ng-container matColumnDef=\"unbilledDays\">\n\t\t\t<th mat-header-cell *matHeaderCellDef> UNBILLED DAYS </th>\n\t\t\t<td mat-cell *matCellDef=\"let element\">\n\t\t\t\t{{((today - element.unbilled_FROM)/ (1000 * 60 * 60 * 24) - 1) | number : '1.0-0'}}\n\t\t\t\t\n\t\t\t</td>\n\t\t</ng-container>\n\n\t\t<ng-container matColumnDef=\"onEdit\">\n\t\t\t<th mat-header-cell *matHeaderCellDef> EDIT </th>\n\t\t\t<td mat-cell *matCellDef=\"let element; let i = index;\">\n\t\t\t\t<button (click)=\"edit(i)\" >Edit </button>\n\t\t\t</td>\n\t\t</ng-container>\n\n\t\t<tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n\t\t<tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>\n\t</table>\n\t<mat-paginator [pageSizeOptions]=\"[10, 25, 50]\" showFirstLastButtons></mat-paginator>\n</div>\n<br><br>"

/***/ }),

/***/ "./src/app/unbillable-data/unbillable-data.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/unbillable-data/unbillable-data.component.ts ***!
  \**************************************************************/
/*! exports provided: UnbillableDataComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnbillableDataComponent", function() { return UnbillableDataComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _unbilled_data_service_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./unbilled.data.service.service */ "./src/app/unbillable-data/unbilled.data.service.service.ts");
/* harmony import */ var _data_sharing_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../data.sharing.service */ "./src/app/data.sharing.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jspdf-autotable */ "./node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _edit_unbillable_data_save_employee_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../edit-unbillable-data/save-employee-service.service */ "./src/app/edit-unbillable-data/save-employee-service.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var UnbillableDataComponent = /** @class */ (function () {
    function UnbillableDataComponent(router, saveEmployeeServiceService, unbilledDataServiceService, dataService) {
        this.router = router;
        this.saveEmployeeServiceService = saveEmployeeServiceService;
        this.unbilledDataServiceService = unbilledDataServiceService;
        this.dataService = dataService;
        this.empidfilter = '';
        this.programManagerFilter = '';
        this.employeeNameFilter = '';
        this.today = new Date().getTime();
        this.displayedColumns = ['empid', 'emp_NAME', 'comments', 'program_MANAGER_NAME', 'customer_NAME', 'category', 'unbilledDays', 'onEdit'];
        this.getUnbilledData();
        this.filterValue = [this.empidfilter, this.programManagerFilter, this.employeeNameFilter];
    }
    UnbillableDataComponent.prototype.ngOnInit = function () {
        //console.log(this.dataSource);
    };
    UnbillableDataComponent.prototype.setEMPIDFilter = function (filterValue) {
        this.empidfilter = filterValue;
        this.applyFilter();
    };
    UnbillableDataComponent.prototype.setProgramManagerName = function (filterValue) {
        this.programManagerFilter = filterValue;
        this.applyFilter();
    };
    UnbillableDataComponent.prototype.setEmployeeName = function (filterValue) {
        this.employeeNameFilter = filterValue;
        this.applyFilter();
    };
    /*
    applyEMPIDFilter(filterValue: string) {
      this.dataSource.filterPredicate =
      (data: any, filter: string) => data.empid.indexOf(filter) != -1;
      this.dataSource.filter = filterValue.trim().toLowerCase();
    }
    */
    UnbillableDataComponent.prototype.applyFilter = function () {
        this.dataSource.filterPredicate =
            function (data, filter) {
                return (data.objCurrentEmployee.empid.indexOf(filter[0]) != -1) &&
                    (data.objCurrentEmployee.program_MANAGER_NAME.toLowerCase().indexOf(filter[1]) != -1) &&
                    (data.objCurrentEmployee.emp_NAME.toLowerCase().indexOf(filter[2]) != -1);
            };
        if (this.empidfilter !== undefined)
            this.filterValue[0] = this.empidfilter.trim().toLowerCase();
        if (this.programManagerFilter !== undefined)
            this.filterValue[1] = this.programManagerFilter.trim().toLowerCase();
        if (this.employeeNameFilter !== undefined)
            this.filterValue[2] = this.employeeNameFilter.trim().toLowerCase();
        console.log(this.filterValue);
        this.dataSource.filter = this.filterValue;
    };
    UnbillableDataComponent.prototype.resetFilters = function () {
        this.empidfilter = '';
        this.programManagerFilter = '';
        this.employeeNameFilter = '';
        this.applyFilter();
    };
    UnbillableDataComponent.prototype.getUnbilledData = function () {
        var _this = this;
        this.unbilledDataServiceService.getUnbilledData()
            .subscribe(function (unbilledData) {
            _this.unbilledEmployeeList = unbilledData;
            _this.unbilledEmployeeList.forEach(function (employee) {
                if (null !== employee.objCurrentEmployee && null !== employee.objCurrentEmployee.billing_START_DATE) {
                    var date = new Date(employee.objCurrentEmployee.billing_START_DATE);
                    //console.log(date);
                    employee.objCurrentEmployee.billing_START_DATE = date;
                    //this.applyPMFilter('');
                }
                _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatTableDataSource"](_this.unbilledEmployeeList);
                _this.dataSource.paginator = _this.paginator;
                _this.dataSource.sort = _this.sort;
            });
        });
    };
    UnbillableDataComponent.prototype.edit = function (i) {
        var _this = this;
        if (null === this.unbilledEmployeeList[i].category) {
            this.saveEmployeeServiceService.getSubCategories('#N/A').
                subscribe(function (response) {
                _this.unbilledEmployeeList[i].category = response[0];
                _this.dataService.currentEmployeeDataForEdit = _this.unbilledEmployeeList[i];
                _this.router.navigateByUrl('/editUnbilledEmployee');
            });
        }
        else {
            this.dataService.currentEmployeeDataForEdit = this.unbilledEmployeeList[i];
            this.router.navigateByUrl('/editUnbilledEmployee');
        }
        console.log("Edit " + this.dataService.currentEmployeeDataForEdit);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_angular_material__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"]),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"])
    ], UnbillableDataComponent.prototype, "paginator", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_angular_material__WEBPACK_IMPORTED_MODULE_3__["MatSort"]),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatSort"])
    ], UnbillableDataComponent.prototype, "sort", void 0);
    UnbillableDataComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-unbillable-data',
            template: __webpack_require__(/*! ./unbillable-data.component.html */ "./src/app/unbillable-data/unbillable-data.component.html"),
            styles: [__webpack_require__(/*! ./unbillable-data.component.css */ "./src/app/unbillable-data/unbillable-data.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"], _edit_unbillable_data_save_employee_service_service__WEBPACK_IMPORTED_MODULE_5__["SaveEmployeeServiceService"], _unbilled_data_service_service__WEBPACK_IMPORTED_MODULE_1__["UnbilledDataServiceService"], _data_sharing_service__WEBPACK_IMPORTED_MODULE_2__["DataService"]])
    ], UnbillableDataComponent);
    return UnbillableDataComponent;
}());



/***/ }),

/***/ "./src/app/unbillable-data/unbilled.data.service.service.ts":
/*!******************************************************************!*\
  !*** ./src/app/unbillable-data/unbilled.data.service.service.ts ***!
  \******************************************************************/
/*! exports provided: UnbilledDataServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnbilledDataServiceService", function() { return UnbilledDataServiceService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var UnbilledDataServiceService = /** @class */ (function () {
    function UnbilledDataServiceService(http) {
        this.http = http;
        this.unbilledDataURL = _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].unbilledDataURL;
    }
    /** GET heroes from the server */
    UnbilledDataServiceService.prototype.getUnbilledData = function () {
        return this.http.get(this.unbilledDataURL)
            .pipe();
    };
    UnbilledDataServiceService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], UnbilledDataServiceService);
    return UnbilledDataServiceService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    /*
    summaryDataURL: 'http://10.10.195.63:9089/mvc/getSummaryData',
    entryExitDataURL: 'http://10.10.195.63:9089/mvc/getEntryExitData',
    unbilledDataURL:'http://10.10.195.63:9089/mvc/getUnbillableData',
    saveEmployeeURL:'http://10.10.195.63:9089/mvc/updateEmployee',
    trendsURL:'http://10.10.195.63:9089/mvc/getTrendsData',
    deliveryUtilizationURL: 'http://10.10.195.63:9089/mvc/getDeliveryUtilizationData',
    projectDataURL: 'http://10.10.195.63:9089/mvc/getProjectData',
    updateProductURL: 'http://10.10.195.63:9089/mvc/updateProjectData',
    addProductURL:'http://10.10.195.63:9089/mvc/createProjectData',
    fileUploadURL:'http://10.10.195.63:9089/mvc/fileUpload',
    runPythonScript:'http://10.10.195.63:9089/mvc/runPythonScript',
    getCategoryURL:'http://10.10.195.63:9089/mvc/getCategories',
    getSubCategoryURL :'http://10.10.195.63:9089/mvc/getSubCategory',
    getSubCategoriesURL : 'http://10.10.195.63:9089/mvc/getSubCategories',
    */
    summaryDataURL: 'http://localhost:8989/EmpDashboard/getSummaryData',
    entryExitDataURL: 'http://localhost:8989/EmpDashboard/getEntryExitData',
    unbilledDataURL: 'http://localhost:8989/EmpDashboard/getUnbillableData',
    saveEmployeeURL: 'http://localhost:8989/EmpDashboard/updateEmployee',
    trendsURL: 'http://localhost:8989/EmpDashboard/getTrendsData',
    deliveryUtilizationURL: 'http://localhost:8989/EmpDashboard/getDeliveryUtilizationData',
    projectDataURL: 'http://localhost:8989/EmpDashboard/getProjectData',
    updateProductURL: 'http://localhost:8989/EmpDashboard/updateProjectData',
    addProductURL: 'http://localhost:8989/EmpDashboard/createProjectData',
    fileUploadURL: 'http://localhost:8989/EmpDashboard/fileUpload',
    runPythonScript: 'http://localhost:8989/EmpDashboard/runPythonScript',
    getCategoryURL: 'http://localhost:8989/EmpDashboard/getCategories',
    getSubCategoryURL: 'http://localhost:8989/EmpDashboard/getSubCategory',
    getSubCategoriesURL: 'http://localhost:8989/EmpDashboard/getSubCategories',
};
/*
 * In development mode, for easier debugging, you can ignore zone related error
 * stack frames such as `zone.run`/`zoneDelegate.invokeTask` by importing the
 * below file. Don't forget to comment it out in production mode
 * because it will have a performance impact when errors are thrown
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /home/mldev/shrikant/angular-poc/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map