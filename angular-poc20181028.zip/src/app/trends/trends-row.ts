
export class TrendsRow{

    IT_DATE: Date;
    delivery_TOTAL: number;
    non_DELIVERY_SUB_TOTAL: number;
    ibu_BUFFER: number;
    total_UNBILLED: number;
    total_BILLED: number;
    unbilled_DELIVERY: number;
    ibu_TOTAL:number;
    
}