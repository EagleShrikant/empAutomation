import { Component, OnInit } from '@angular/core';
import { DeliveryUtilizationTable} from './delivery-utilization-table';
import { DeliveryUtilizationRow} from './delivery-utilization-row';
import {DeliveryUtilizationService} from './delivery-utilization.service';

@Component({
  selector: 'app-delivery-utilization',
  templateUrl: './delivery-utilization.component.html',
  styleUrls: ['./delivery-utilization.component.css']
})
export class DeliveryUtilizationComponent implements OnInit {

  displayedColumns: string[] = [
    'UT_DATE',
    'UTILIZATION_DELIVERY_PROJ_WITH_PO',
    'UTILIZATION_DELIVERY_WITHOUT_PO',
    'DELIVERY_FTE_WITHOUT_PO',
    'UTILIZATION_IBU' ];
    
    deliveryUtilizationData: DeliveryUtilizationTable;
    deliveryUtilizationList: DeliveryUtilizationRow[];
  
    getDeliveryUtilization(): void {
      this.deliveryUtilizationService.getDeliveryUtilization()
      .subscribe(deliveryUtilizationData => {
        this.deliveryUtilizationList = deliveryUtilizationData;
        //console.log('Print Start');
        //console.log(this.deliveryUtilizationList);
        //console.log('Print End');
      });
      
    }

  constructor(private deliveryUtilizationService: DeliveryUtilizationService) { this.getDeliveryUtilization(); }

  ngOnInit() {
  }

}
