import { Injectable } from '@angular/core';
import {environment} from '../../environments/environment'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class SaveProjectService {

  private updateProducteDataURL = environment.updateProductURL; 
  private addProducteDataURL = environment.addProductURL; 
  constructor(private http: HttpClient,) { }


  addProduct(editProjectData : any): Observable<any[]> {
    return this.http.post<any>(this.addProducteDataURL, editProjectData , httpOptions)
      .pipe(
        /**tap(heroes => this.log('fetched heroes')),*/
        //catchError(this.handleError('getSummary', []))
      );
  }

  updateProduct(editProjectData : any): Observable<any[]> {
    return this.http.post<any>(this.updateProducteDataURL, editProjectData , httpOptions)
    .pipe(
      /**tap(heroes => this.log('fetched heroes')),*/
      //catchError(this.handleError('getSummary', []))
    );
    
  }
}
