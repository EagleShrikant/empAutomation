import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.sharing.service';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { SaveEmployeeServiceService } from './save-employee-service.service';




@Component({
  selector: 'app-edit-unbillable-data',
  templateUrl: './edit-unbillable-data.component.html',
  styleUrls: ['./edit-unbillable-data.component.css'],

})
export class EditUnbillableDataComponent implements OnInit {
  temp: Date;
  categories: any;
  subcategories: any;
  response: any;
  editEmployeeData: any;


  constructor(private dataService: DataService, private router: Router, private saveEmployeeServiceService: SaveEmployeeServiceService) {
    this.editEmployeeData = this.dataService.currentEmployeeDataForEdit;

    //console.log(this.editEmployeeData);

    if (this.editEmployeeData === undefined || null === this.editEmployeeData) {

      this.router.navigateByUrl('');
    }



    if (null != this.editEmployeeData && null != this.editEmployeeData.billing_START_DATE) {
      let date = new Date(this.editEmployeeData.billing_START_DATE);

      this.editEmployeeData.billing_START_DATE = date;
      //console.log(this.editEmployeeData);
    }


    this.setCategory();
    this.setSubCategoryFirst();



  }

  setCategory() {
    this.saveEmployeeServiceService.getCategories().
      subscribe(response => {
        this.categories = response;
      });
  }
  ngOnInit() {
    if (this.editEmployeeData === undefined) {

      this.router.navigateByUrl('');
    }
    this.setCategory();
  }


  getSubCategoryByName() {

  }

  setSubCategory($event) {
    console.log($event.value);

    this.saveEmployeeServiceService.getSubCategories($event.value).
      subscribe(response => {
        this.subcategories = response;

      });

  }

  setSubCategoryFirst() {
    if (null !== this.editEmployeeData && undefined!==this.editEmployeeData && null !== this.editEmployeeData.category) {
      this.saveEmployeeServiceService.getSubCategories(this.editEmployeeData.category.category).
        subscribe(response => {
          this.subcategories = response;
        });
    }
  }

  setSubCategoryEmployee($event) {
    this.saveEmployeeServiceService.getSubCategory(this.editEmployeeData.category).
      subscribe(response => {
        this.editEmployeeData.category.sub_CAT_ID = response.sub_CAT_ID;
        console.log(response);
        console.log(this.editEmployeeData);    
      });
    //this.setCategory();
    console.log(this.editEmployeeData);
    //console.log(this.categories);

  }

  saveEmployee(editEmployeeData) {
    //this.temp.getDate
    //editEmployeeData.billing_START_DATE = 
    // let newDate = new Date(dateString);
    /*console.log(Date.UTC(editEmployeeData.billing_START_DATE.getFullYear,
     editEmployeeData.billing_START_DATE.getMonth,
     editEmployeeData.billing_START_DATE.getDate));  
     */
    let date = new Date(editEmployeeData.billing_START_DATE);
    editEmployeeData.billing_START_DATE =
      Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
    let localOffset = date.getTimezoneOffset() * -1 * 60000 * 2;
    let utc = editEmployeeData.billing_START_DATE + localOffset;
    // console.log("hello " +utc);
    /*
         let localTime = date.getTime();
         
        
         let localOffset = date.getTimezoneOffset() * -1 * 60000 * 2;
         let utc = localTime + localOffset;
         console.log(utc + "  " + date.getDate());
        date.setTime(utc)
        date.setUTCDate(date.getDate());
        date.setUTCMonth(date.getMonth());
        date.setUTCFullYear(date.getFullYear());
        console.log(date);
        */
    //editEmployeeData.billing_START_DATE = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+date.getDate();    
    //console.log(date.getDate());
    /*
    let diff = date.getTimezoneOffset();
    let utcTime = date.getTime();
    date.setTime(utcTime + diff);
    console.log(date.getTime());
     */

    //editEmployeeData.billing_START_DATE.setTime(utcTime + diff);
    //console.log(date.getTimezoneOffset());
    // = date;
    console.log(editEmployeeData);
    this.saveEmployeeServiceService.updateEmployee(editEmployeeData).
      subscribe(response => {
        this.response = response;
        this.router.navigateByUrl('unbillableData');
      });
  }

}
