import { Component, OnInit } from '@angular/core';

import * as  Highcharts from 'highcharts';
import More from 'highcharts/highcharts-more';
More(Highcharts);
import Drilldown from 'highcharts/modules/drilldown';
Drilldown(Highcharts);
// Load the exporting module.
import Exporting from 'highcharts/modules/exporting';
// Initialize exporting module.
Exporting(Highcharts);
import { ViewChild, ElementRef } from '@angular/core';
import { DeliveryUtilizationTable } from '../delivery-utilization/delivery-utilization-table';
import { DeliveryUtilizationRow } from '../delivery-utilization/delivery-utilization-row';
import { DeliveryUtilizationService } from '../delivery-utilization/delivery-utilization.service';
import { DeliveryUtilizationSeries } from './delivery-utilization-series';
@Component({
  selector: 'app-delivery-utilization-chart',
  templateUrl: './delivery-utilization-chart.component.html',
  styleUrls: ['./delivery-utilization-chart.component.css']
})
export class DeliveryUtilizationChartComponent implements OnInit {
  chart;
  deliveryUtilizationSeries: DeliveryUtilizationSeries = new DeliveryUtilizationSeries;
  tempDate: Date;
  constructor(private deliveryUtilizationService: DeliveryUtilizationService) { }

  seriesList: string[] = [
    
    'UTILIZATION_DELIVERY_PROJ_WITH_PO',
    'UTILIZATION_DELIVERY_WITHOUT_PO',
    'DELIVERY_FTE_WITHOUT_PO',
    'UTILIZATION_IBU' 
  ];

  deliveryUtilizationData: DeliveryUtilizationTable;
  deliveryUtilizationList: DeliveryUtilizationRow[];

  getDeliveryUtilizations(): void {
    this.deliveryUtilizationService.getDeliveryUtilization()
      .subscribe(deliveryUtilizationData => {
        this.deliveryUtilizationList = deliveryUtilizationData;
        //console.log(this.deliveryUtilizationList);
        this.refreshSeriesData(this.deliveryUtilizationList);

      });

  }

  ngOnInit() {
    this.getDeliveryUtilizations();
    this.chart = Highcharts.chart('container', {

      title: {
        text: 'Delivery Utilization for IBU'
      },

      subtitle: {
        text: 'Tech Mahindra'
      },

      yAxis: {
        title: {
          text: 'Percentage'
        }
      },
      xAxis: {
        type: 'datetime',
        dateTimeLabelFormats: { // don't display the dummy year
          month: '%e. %b',
          year: '%b'
        },
        title: {
          text: 'Date'
        }
      },
      legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
      },



      plotOptions: {
        series: {
          label: {
            connectorAllowed: false
          }
          // pointStart: Date.UTC(2014, 11, 2),
        }
      },
      series: [],

      responsive: {
        rules: [{
          condition: {
            maxWidth: 500
          },
          chartOptions: {
            legend: {
              layout: 'horizontal',
              align: 'center',
              verticalAlign: 'bottom'
            }
          }
        }]
      }

    });

  }



  refreshSeriesData(deliveryUtilizationListP: DeliveryUtilizationRow[]) {
    for (var i = 0; this.chart.series.length > 0; i++) {
      this.chart.series[0].remove(true);
    }

    this.getTrendSeries(deliveryUtilizationListP);
    //console.log(this.deliveryUtilizationSeries);


    this.chart.addSeries({
      name: this.seriesList[0],
      data: this.deliveryUtilizationSeries.DELIVERY_FTE_WITHOUT_PO
    });

    this.chart.addSeries({
      name: this.seriesList[1],
      data: this.deliveryUtilizationSeries.UTILIZATION_DELIVERY_PROJ_WITH_PO
    });

    this.chart.addSeries({
      name: this.seriesList[2],
      data: this.deliveryUtilizationSeries.UTILIZATION_DELIVERY_WITHOUT_PO
    });
    this.chart.addSeries({
      name: this.seriesList[3],
      data: this.deliveryUtilizationSeries.UTILIZATION_IBU
    });

  }


  getTrendSeries(deliveryUtilizationListPS: DeliveryUtilizationRow[]) {

    this.deliveryUtilizationSeries = new DeliveryUtilizationSeries;
    for (var i = 0; i < deliveryUtilizationListPS.length; i++) {

      this.tempDate = new Date(deliveryUtilizationListPS[i].UT_DATE);
      //console.log(this.tempDate.getUTCDate());

      this.deliveryUtilizationSeries.DELIVERY_FTE_WITHOUT_PO.push(
        [Date.UTC(this.tempDate.getUTCFullYear(),
          this.tempDate.getUTCMonth(),
          this.tempDate.getUTCDate()), deliveryUtilizationListPS[i].delivery_FTE_WITHOUT_PO]);

      this.deliveryUtilizationSeries.UTILIZATION_DELIVERY_PROJ_WITH_PO.push([
        Date.UTC(this.tempDate.getUTCFullYear(),
          this.tempDate.getUTCMonth(),
          this.tempDate.getUTCDate()),
          deliveryUtilizationListPS[i].utilization_DELIVERY_PROJ_WITH_PO]);

      this.deliveryUtilizationSeries.UTILIZATION_DELIVERY_WITHOUT_PO.push(
        [Date.UTC(this.tempDate.getUTCFullYear(),
          this.tempDate.getUTCMonth(),
          this.tempDate.getUTCDate()),
          deliveryUtilizationListPS[i].utilization_DELIVERY_WITHOUT_PO]);

      this.deliveryUtilizationSeries.UTILIZATION_IBU.push(
        [Date.UTC(this.tempDate.getUTCFullYear(),
          this.tempDate.getUTCMonth(),
          this.tempDate.getUTCDate()),
          deliveryUtilizationListPS[i].utilization_IBU]);
    }

  }

}
