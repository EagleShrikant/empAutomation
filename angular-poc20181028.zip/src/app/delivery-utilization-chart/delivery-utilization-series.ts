export class DeliveryUtilizationSeries{

    constructor(){}
    name : string[];
    //yaxis : number[] = [];
    data : number[][] = []; 
    
    UTILIZATION_DELIVERY_PROJ_WITH_PO: number[][] = [];
    UTILIZATION_DELIVERY_WITHOUT_PO: number[][] = [];
    DELIVERY_FTE_WITHOUT_PO: number[][] = [];
    UTILIZATION_IBU: number[][] = [];
    
}