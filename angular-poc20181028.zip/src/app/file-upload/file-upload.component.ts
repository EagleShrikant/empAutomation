import { Component, OnInit } from '@angular/core';
import {environment} from '../../environments/environment';
import { FileUploadService } from './file-upload.service';
import { DatePipe } from '@angular/common'

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {

  fileUploadURL:String;
  response : any;
  dateInput : String;
  constructor(private fileUploadService: FileUploadService, public datepipe: DatePipe) { 
    this.fileUploadURL = environment.fileUploadURL;
    this.dateInput = this.datepipe.transform(new Date(), 'yyyy-MM-dd');
  }

  ngOnInit() {
  }

  runPythonScript(): void {
    this.fileUploadService.runPythonFile(this.dateInput)
    .subscribe(response => this.response = response);
  }

}
