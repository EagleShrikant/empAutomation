import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import {environment} from '../../environments/environment'

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class FileUploadService {

  private runPythonScript = environment.runPythonScript;

  constructor(private http: HttpClient) {
   }

   runPythonFile(dateP): Observable<any> {
     console.log(dateP);
    return this.http.post<any>(this.runPythonScript, dateP, httpOptions)
      .pipe(
        /**tap(heroes => this.log('fetched heroes')),*/
        //catchError(this.handleError('getSummary', []))
      );
  }
}
