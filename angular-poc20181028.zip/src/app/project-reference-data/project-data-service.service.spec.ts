import { TestBed, inject } from '@angular/core/testing';

import { ProjectDataServiceService } from './project-data-service.service';

describe('ProjectDataServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProjectDataServiceService]
    });
  });

  it('should be created', inject([ProjectDataServiceService], (service: ProjectDataServiceService) => {
    expect(service).toBeTruthy();
  }));
});
