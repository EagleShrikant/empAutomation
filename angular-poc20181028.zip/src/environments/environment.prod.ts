export const environment = {
  production: true,
  //summaryDataURL: 'http://demo8976463.mockable.io/mvc/getSummaryData',
  //entryExitDataURL: 'http://demo0220709.mockable.io/getEntryExitData',
  //unbilledDataURL:'http://demo8976463.mockable.io/mvc/getUnbillableData',
  //saveEmployeeURL:'http://10.10.195.63:9089/mvc/updateEmployee',
  //trendsURL:'http://demo8976463.mockable.io/mvc/getTrendsData'


  
  summaryDataURL: 'http://localhost:8989/EmpDashboard/getSummaryData',
  entryExitDataURL: 'http://localhost:8989/EmpDashboard/getEntryExitData',
  unbilledDataURL:'http://localhost:8989/EmpDashboard/getUnbillableData',
  saveEmployeeURL:'http://localhost:8989/EmpDashboard/updateEmployee',
  trendsURL:'http://localhost:8989/EmpDashboard/getTrendsData',
  deliveryUtilizationURL: 'http://localhost:8989/EmpDashboard/getDeliveryUtilizationData',
  projectDataURL: 'http://localhost:8989/EmpDashboard/getProjectData',
  updateProductURL: 'http://localhost:8989/EmpDashboard/updateProjectData',
  addProductURL:'http://localhost:8989/EmpDashboard/createProjectData',
  fileUploadURL:'http://localhost:8989/EmpDashboard/fileUpload',
  runPythonScript:'http://localhost:8989/EmpDashboard/runPythonScript',
  getCategoryURL:'http://localhost:8989/EmpDashboard/getCategories',
  getSubCategoryURL :'http://localhost:8989/EmpDashboard/getSubCategory',
  getSubCategoriesURL : 'http://localhost:8989/EmpDashboard/getSubCategories',

};
