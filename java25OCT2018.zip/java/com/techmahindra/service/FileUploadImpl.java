package com.techmahindra.service;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.techmahindra.dao.DeliveryUtilization;
import com.techmahindra.dao.IBUTrends;
import com.techmahindra.model.SummaryModel;



@RestController
public class FileUploadImpl {

	@Autowired
	DeliveryUtilization du;
	
	@Autowired
	SummaryModel sm;
	
	
	@Value("${fileUploadPath}")
	String fileUploadPath;
	
	@Value("${pythonScriptPath}")
	String pythonScriptPath;
	
	@CrossOrigin
	@PostMapping(path = "/fileUpload")
	public void getFileModel(@RequestParam("file") MultipartFile uploadfile) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd");
		File outFile = new File(fileUploadPath+dateFormat.format(new Date())+".xls"); 
		
		System.out.println("fileUpload" + uploadfile.getOriginalFilename() + outFile.getAbsolutePath() );
		try {
		FileCopyUtils.copy(convert(uploadfile), outFile);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	@CrossOrigin
	@PostMapping(path = "/runPythonScript")
	public void runPythonScript(String dateP) throws IOException   {
		Timestamp ts;
		try {
			
		
		ts = new Timestamp(new SimpleDateFormat("yyyy/MM/dd").parse(dateP).getTime());
		System.out.println("Running Script : Start");
		}
		catch (Exception e) {
			ts = new Timestamp(new Date().getTime());
		}
		
		
		Process p = Runtime.getRuntime().exec("python "+ pythonScriptPath + "script.py");
		BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String ret = in.readLine();
		
		
		IBUTrends objIBUTrends = sm.getIBUTrends();
		
		objIBUTrends.setDATE(ts); 
				
		
		du.setUT_DATE(ts);
		//du.setDELIVERY_FTE_WITHOUT_PO();
		du.getUTILIZATION_DELIVERY_WITHOUT_PO();
		du.setUTILIZATION_DELIVERY_PROJ_WITH_PO(objIBUTrends.getTOTAL_BILLED()/objIBUTrends.getDELIVERY_TOTAL()*100);;
		
		du.setUTILIZATION_IBU(objIBUTrends.getTOTAL_BILLED()/objIBUTrends.getIBU_TOTAL()*100);
		
				
		System.out.println("Running Script : End");
	}
	
	
	public File convert(MultipartFile file) throws IOException
	{    
	    File convFile = new File(file.getOriginalFilename());
	    convFile.createNewFile(); 
	    FileOutputStream fos = new FileOutputStream(convFile); 
	    fos.write(file.getBytes());
	    fos.close(); 
	    return convFile;
	}
	
}
