package com.techmahindra.model;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.techmahindra.boot.MySQLAppConfig;
import com.techmahindra.dao.Category;
import com.techmahindra.dao.CurrentEmployee;
import com.techmahindra.dao.UnbilledData;

@Component
public class UnbillableDataModel {
	@Autowired
	MySQLAppConfig mySQLAppConfig;

	List<UnbilledData> unbillableDataList;
	List<Category> categoryList;
	Set<Category> distCatList = new TreeSet<Category>(new CategoryComparator());
	Set<Category> distSubCatList = new TreeSet<Category>(new SubCategoryComparator());
	public List<UnbilledData> UnbillableModelDataFetch() {

		System.out.println("UnbillableModelDataFetch");
		Session session = mySQLAppConfig.getSessionFactory(mySQLAppConfig.getDataSource()).openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();

			unbillableDataList = session.createQuery("from UnbilledData").list();

			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		}

		finally {
			session.close();
		}

		return unbillableDataList;
	}

	public void saveEmployee(UnbilledData ud) {
		Session session = mySQLAppConfig.getSessionFactory(mySQLAppConfig.getDataSource()).openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			UnbilledData unbilledEmployee = (UnbilledData) session.get(UnbilledData.class, ud.getUNBILLED_REC_ID());
			System.out.println("Save"+ud);
			unbilledEmployee.updateUnbilled(ud);
			session.update(unbilledEmployee);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

	public Set<Category> getCategories() {
		distCatList.clear();
		
		Session session = mySQLAppConfig.getSessionFactory(mySQLAppConfig.getDataSource()).openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			categoryList = session.createQuery("from Category").list();
			tx.commit();

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		}

		finally {
			session.close();
		}

		System.out.println(categoryList);
		if(null != categoryList) {
		distCatList.addAll(categoryList);
		}
		return distCatList;

	}

	public Set<Category> getSubCategories(String category) {
		System.out.println("Category" + category);
		distSubCatList.clear();
		categoryList = null;
		Session session = mySQLAppConfig.getSessionFactory(mySQLAppConfig.getDataSource()).openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			
			//Category objCategory = (Category) session.get(Category.class, category);
			String hql = "SELECT c FROM Category c WHERE c.CATEGORY = :CATEGORY";
			Query query = session.createQuery(hql);
			query.setParameter("CATEGORY",category /*objCategory.getCATEGORY()*/);
			categoryList = query.getResultList();
			System.out.println("CAT LIST " + categoryList);
			tx.commit();

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		}

		finally {
			session.close();
		}
		System.out.println(categoryList);
		distSubCatList.addAll(categoryList);

		return distSubCatList;


	}

	public Category getSubCategory(Category subcategory) {
		System.out.println("Category" + subcategory);
		Category objCategory = null;
		
		Session session = mySQLAppConfig.getSessionFactory(mySQLAppConfig.getDataSource()).openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			
			//objCategory = (Category) session.get(Category.class, subcategory);
			String hql = "SELECT c FROM Category c WHERE c.CATEGORY = :CATEGORY AND c.SUB_CATEGORY = :SUB_CATEGORY";
			Query query = session.createQuery(hql);
			query.setParameter("CATEGORY",subcategory.getCATEGORY() /*objCategory.getCATEGORY()*/);
			query.setParameter("SUB_CATEGORY",subcategory.getSUB_CATEGORY() /*objCategory.getCATEGORY()*/);
			categoryList = query.getResultList();
			System.out.println("Sub CAT LIST " + categoryList);
			if(null!=categoryList && null!=categoryList.get(0))
			objCategory = categoryList.get(0);
			tx.commit();
			
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		}

		finally {
			session.close();
		}
		//System.out.println(categoryList);
		//distSubCatList.addAll(categoryList);

		return objCategory;
	}

}
