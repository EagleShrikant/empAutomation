package com.techmahindra.model;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.techmahindra.boot.MySQLAppConfig;
import com.techmahindra.dao.CurrentEmployee;
import com.techmahindra.dao.DeliveryUtilization;
import com.techmahindra.dao.IBUTrends;

@Component
public class TrendModel {
	
	@Autowired
	MySQLAppConfig mySQLAppConfig;
	
	List<IBUTrends> trendsDataList;

	private List<DeliveryUtilization> deliveryUtilizationDataList;
	
public List<IBUTrends> trendModelDataFetch() {
		
		System.out.println("TrendModelDataFetch");
		Session session = mySQLAppConfig.getSessionFactory(mySQLAppConfig.getDataSource()).openSession();
	      Transaction tx = null;
	      
	      try {
	         tx = session.beginTransaction();

	         trendsDataList = session.createQuery("from IBUTrends").list();
	         
	         tx.commit();
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } catch (Exception e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      }
	      
	      finally {
	         session.close(); 
	      }
	      
	      return trendsDataList;
	}

public List<DeliveryUtilization> deliveryUtilizationModelDataFetch() {
	
	System.out.println("DeliveryUtilizationModelDataFetch");
	Session session = mySQLAppConfig.getSessionFactory(mySQLAppConfig.getDataSource()).openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();

         deliveryUtilizationDataList = session.createQuery("from DeliveryUtilization").list();
         
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace(); 
      } catch (Exception e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      }
      
      finally {
         session.close(); 
      }
      
      return deliveryUtilizationDataList;
}

}
