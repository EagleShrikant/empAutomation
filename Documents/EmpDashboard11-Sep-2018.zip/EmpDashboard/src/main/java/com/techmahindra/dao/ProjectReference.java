package com.techmahindra.dao;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PROJECT_REFERENCE_DATA")
public class ProjectReference {

	
	@Id
	@Column(name = "PROJECT_ID", length=32 ) private String PROJECT_ID;
	@Column(name = "PROJECT_TYPE", length=32) private String PROJECT_TYPE;
	@Column(name = "CUSTOMER_NAME", length=32) private String CUSTOMER_NAME;
	@Column(name = "PROJECT_DESCRIPTION", length=255) private String PROJECT_DESCRIPTION;	
	@Column(name = "PO_FLAG", length=1) private String PO_FLAG;
	@Column(name = "DM", length=64) private String DM;
	@Column(name = "SALES_MANAGER", length=64) private String SALES_MANAGER;
	
	
	@Column(name = "IS_PROJECT_ACTIVE", length=1) private String IS_PROJECT_ACTIVE;
	
	@Column(name = "LAST_MODIFIED_TS") private Timestamp LAST_MODIFIED_TS;
	
	public String getPROJECT_ID() {
		return PROJECT_ID;
	}
	public String getPROJECT_DESCRIPTION() {
		return PROJECT_DESCRIPTION;
	}
	public String getPROJECT_TYPE() {
		return PROJECT_TYPE;
	}
	public String getPO_FLAG() {
		return PO_FLAG;
	}
	public String getDM() {
		return DM;
	}
	public String getSALES_MANAGER() {
		return SALES_MANAGER;
	}
	
	public String getIS_PROJECT_ACTIVE() {
		return IS_PROJECT_ACTIVE;
	}
	
	public void setPROJECT_ID(String pROJECT_ID) {
		PROJECT_ID = pROJECT_ID;
	}
	public void setPROJECT_DESCRIPTION(String pROJECT_DESCRIPTION) {
		PROJECT_DESCRIPTION = pROJECT_DESCRIPTION;
	}
	public void setPROJECT_TYPE(String pROJECT_TYPE) {
		PROJECT_TYPE = pROJECT_TYPE;
	}
	public void setPO_FLAG(String pO_FLAG) {
		PO_FLAG = pO_FLAG;
	}
	public void setDM(String dM) {
		DM = dM;
	}
	public void setSALES_MANAGER(String sALES_MANAGER) {
		SALES_MANAGER = sALES_MANAGER;
	}
	
	public void setCUSTOMER_NAME(String cUSTOMER_NAME) {
		CUSTOMER_NAME = cUSTOMER_NAME;
	}
	
	public void setIS_PROJECT_ACTIVE(String iS_PROJECT_ACTIVE) {
		IS_PROJECT_ACTIVE = iS_PROJECT_ACTIVE;
	}
	public String getCUSTOMER_NAME() {
		return CUSTOMER_NAME;
	}
	public Timestamp getLAST_MODIFIED_TS() {
		return LAST_MODIFIED_TS;
	}
	public void setLAST_MODIFIED_TS(Timestamp lAST_MODIFIED_TS) {
		LAST_MODIFIED_TS = lAST_MODIFIED_TS;
	}
	
	@Override
	public String toString() {
		return "ProjectReference [PROJECT_ID=" + PROJECT_ID + ", PROJECT_TYPE=" + PROJECT_TYPE + ", CUSTOMER_NAME="
				+ CUSTOMER_NAME + ", PROJECT_DESCRIPTION=" + PROJECT_DESCRIPTION + ", PO_FLAG=" + PO_FLAG + ", DM=" + DM
				+ ", SALES_MANAGER=" + SALES_MANAGER + ", IS_PROJECT_ACTIVE=" + IS_PROJECT_ACTIVE
				+ ", LAST_MODIFIED_TS=" + LAST_MODIFIED_TS + "]";
	}
	public void updateProject(ProjectReference pr) {
		// TODO Auto-generated method stub
		
	}
	
	
}
