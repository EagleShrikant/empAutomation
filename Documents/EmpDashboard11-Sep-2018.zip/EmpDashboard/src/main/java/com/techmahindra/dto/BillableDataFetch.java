package com.techmahindra.dto;

import com.techmahindra.model.BillableModel;

public class BillableDataFetch {

	public static BillableModel setBillableModel(BillableModel billableModel) {
		
		return billableModel;
	}
}
