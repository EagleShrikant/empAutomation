
export class EntryExitRow{

    edate: Date;
    status: string;
    employeeID: string;
    employeeName: string;
    band: string;
    projectDescription: string;
    programManagerName: string;
    
}
    