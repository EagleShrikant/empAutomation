import { Component, OnInit } from '@angular/core';
import { EntryExitTable } from './entry-exit-table';
import { EntryExitRow } from './entry-exit-row';
import { EntryExitService } from './entry-exit.service';

@Component({
  selector: 'app-entry-exit-component',
  templateUrl: './entry-exit-component.component.html',
  styleUrls: ['./entry-exit-component.component.css']
})
export class EntryExitComponentComponent implements OnInit {
  displayedColumns: string[] = ['edate' , 'status' , 'employeeID' , 'employeeName', 'band' , 'projectDescription', 'programManagerName' ];
  
  entryExitData: EntryExitTable;
  entryExitList: EntryExitRow[];

  getEntryExit(): void {
    this.entryExitService.getEntryExit()
    .subscribe(entryExitData => this.entryExitList = entryExitData.entryExitTable);
  }

  constructor(private entryExitService: EntryExitService) { this.getEntryExit(); }


  ngOnInit() {
    //this.getEntryExit();
  }

}
