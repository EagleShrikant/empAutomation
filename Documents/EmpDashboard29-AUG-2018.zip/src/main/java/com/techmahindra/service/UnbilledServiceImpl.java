package com.techmahindra.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.techmahindra.dao.CurrentEmployee;
import com.techmahindra.dto.APIResponse;
import com.techmahindra.model.EntryExitModel;
import com.techmahindra.model.UnbillableDataModel;

@RestController
public class UnbilledServiceImpl {

	
	
	@Autowired
	UnbillableDataModel unbillableModel;
	
	@Autowired
	APIResponse response;
	
	@CrossOrigin
	@GetMapping("/getUnbillableData")
	public List<CurrentEmployee> getUnbillableModel() {
		System.out.println("getUnbillableData");
		
		return unbillableModel.UnbillableModelDataFetch();
	}
	
	@CrossOrigin
	@PostMapping("/updateEmployee")
	public APIResponse updateEmployee(@RequestBody CurrentEmployee ce) {
		System.out.println(ce);
		unbillableModel.saveEmployee(ce);
		return response;
	}

}
