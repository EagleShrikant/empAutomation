package com.techmahindra.model;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.techmahindra.boot.MySQLAppConfig;
import com.techmahindra.dao.CurrentEmployee;
import com.techmahindra.dao.UnbilledData;

@Component
public class UnbillableDataModel {
	@Autowired
	MySQLAppConfig mySQLAppConfig;
	
	List<UnbilledData> unbillableDataList;
	
public List<UnbilledData> UnbillableModelDataFetch() {
		
		System.out.println("UnbillableModelDataFetch");
		Session session = mySQLAppConfig.getSessionFactory(mySQLAppConfig.getDataSource()).openSession();
	      Transaction tx = null;
	      
	      try {
	         tx = session.beginTransaction();

	         unbillableDataList = session.createQuery("from UnbilledData").list();
	         
	         tx.commit();
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } catch (Exception e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      }
	      
	      finally {
	         session.close(); 
	      }
	      
	      return unbillableDataList;
	}

public void saveEmployee(CurrentEmployee ce) {
	Session session = mySQLAppConfig.getSessionFactory(mySQLAppConfig.getDataSource()).openSession();
    Transaction tx = null;
    
    try {
       tx = session.beginTransaction();
       CurrentEmployee employee = (CurrentEmployee)session.get(CurrentEmployee.class, ce.getEMPID());
       //System.out.println("Save"+ce);
       //employee.updateEmployee(ce);
		 session.update(employee); 
       tx.commit();
    } catch (HibernateException e) {
       if (tx!=null) tx.rollback();
       e.printStackTrace(); 
    } finally {
       session.close(); 
    }
	
}

}
