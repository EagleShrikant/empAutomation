package com.techmahindra.service;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;



@RestController
public class FileUploadImpl {
	
	@Value("${fileUploadPath}")
	String fileUploadPath;
	
	@Value("${pythonScriptPath}")
	String pythonScriptPath;
	
	@CrossOrigin
	@PostMapping(path = "/fileUpload")
	public void getFileModel(@RequestParam("file") MultipartFile uploadfile) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd");
		File outFile = new File(fileUploadPath+dateFormat.format(new Date())+".xls"); 
		
		System.out.println("fileUpload" + uploadfile.getOriginalFilename() + outFile.getAbsolutePath() );
		try {
		FileCopyUtils.copy(convert(uploadfile), outFile);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	@CrossOrigin
	@GetMapping(path = "/runPythonScript")
	public void runPythonScript() throws IOException   {
		System.out.println("Running Script : Start");

		Process p = Runtime.getRuntime().exec("python "+ pythonScriptPath + "script.py");
		BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String ret = in.readLine();
		
		System.out.println("Running Script : End");
	}
	
	
	public File convert(MultipartFile file) throws IOException
	{    
	    File convFile = new File(file.getOriginalFilename());
	    convFile.createNewFile(); 
	    FileOutputStream fos = new FileOutputStream(convFile); 
	    fos.write(file.getBytes());
	    fos.close(); 
	    return convFile;
	}
	
}
