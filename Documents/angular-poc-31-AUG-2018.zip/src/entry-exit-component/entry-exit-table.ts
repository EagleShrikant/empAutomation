import { EntryExitRow} from './entry-exit-row';
export class EntryExitTable {
  entryExitTable : EntryExitRow[];
}