import { Component, OnInit } from '@angular/core';
import { UnbilledDataServiceService} from './unbilled.data.service.service';
import {DataService} from '../data.sharing.service'

@Component({
  selector: 'app-unbillable-data',
  templateUrl: './unbillable-data.component.html',
  styleUrls: ['./unbillable-data.component.css']
})
export class UnbillableDataComponent implements OnInit {

  unbilledEmployeeList : any[];

  displayedColumns: string[] = ['empid' , 'emp_NAME' , 'comments' , 'account' , 'billing_START_DATE', 'category' , 'sub_CATEGORY', 'action' ,'onEdit'];

  constructor(private unbilledDataServiceService: UnbilledDataServiceService, private dataService:DataService) {
    this.getUnbilledData();
   }

  ngOnInit() {
  }

  getUnbilledData(): void {
    this.unbilledDataServiceService.getUnbilledData()
    .subscribe(unbilledData => this.unbilledEmployeeList = unbilledData);
    
    
  }

  edit(i): void{
     this.dataService.currentEmployeeDataForEdit = this.unbilledEmployeeList[i];
     //console.log(this.dataService.currentEmployeeDataForEdit);
  }


}
