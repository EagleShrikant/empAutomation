import { Component, OnInit } from '@angular/core';
import { DataService} from '../data.sharing.service';
import {Router} from '@angular/router';
import {SaveEmployeeServiceService} from './save-employee-service.service'

@Component({
  selector: 'app-edit-unbillable-data',
  templateUrl: './edit-unbillable-data.component.html',
  styleUrls: ['./edit-unbillable-data.component.css']
})
export class EditUnbillableDataComponent implements OnInit {
  response : any;
  editEmployeeData : any;
  constructor(private dataService : DataService , private router: Router, private saveEmployeeServiceService:SaveEmployeeServiceService) { 
    this.editEmployeeData = this.dataService.currentEmployeeDataForEdit;
    //console.log(this.editEmployeeData);

    if (this.editEmployeeData === undefined){
      
      this.router.navigateByUrl('');
    }
    console.log(this.editEmployeeData);
  }

  ngOnInit() {
    
  }

  saveEmployee(editEmployeeData){
    this.saveEmployeeServiceService.updateEmployee(editEmployeeData).
         subscribe(response => this.response = response);
  }

}
