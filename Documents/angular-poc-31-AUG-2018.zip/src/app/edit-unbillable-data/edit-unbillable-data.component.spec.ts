import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditUnbillableDataComponent } from './edit-unbillable-data.component';

describe('EditUnbillableDataComponent', () => {
  let component: EditUnbillableDataComponent;
  let fixture: ComponentFixture<EditUnbillableDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditUnbillableDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditUnbillableDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
