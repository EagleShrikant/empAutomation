import { Routes, RouterModule } from "@angular/router";
import { AppComponent } from './app.component';
import {EditUnbillableDataComponent} from './edit-unbillable-data/edit-unbillable-data.component';
import {HomeComponent} from '../app/home/home.component';
import {EmpSummaryDashboardComponent} from '../emp-summary-dashboard/emp-summary-dashboard.component';
import {EntryExitComponentComponent} from '../entry-exit-component/entry-exit-component.component';
import {UnbillableDataComponent} from '../app/unbillable-data/unbillable-data.component';
import { TrendsComponent } from "./trends/trends.component";


const appRoutes: Routes = [
  {
    path: "",
    redirectTo: "home",
    pathMatch: "full"
  },
  {
    path: "main",
    component: HomeComponent
  },
  {
    path: "home",
    component: HomeComponent
  },
    {
    path: "editUnbilledEmployee",
    component: EditUnbillableDataComponent
  },
  {
    path: "summary",
    component: EmpSummaryDashboardComponent
  },
  
  {
    path: "dashboard",
    component: HomeComponent
  },
  {
    path: "entryExit",
    component: EntryExitComponentComponent
  },
  {
    path: "unbillableData",
    component: UnbillableDataComponent
  },
  {
    path: "trends",
    component: TrendsComponent
  },
  
  
  
  // otherwise redirect to home
  { path: "**", redirectTo: "/" }
];

export const routing = RouterModule.forRoot(appRoutes);