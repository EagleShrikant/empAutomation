package com.techmahindra.service;

import org.springframework.stereotype.Component;

@Component
public class UnbilledServiceImpl {

}
