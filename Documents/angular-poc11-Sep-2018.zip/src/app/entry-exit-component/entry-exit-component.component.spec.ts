import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EntryExitComponentComponent } from './entry-exit-component.component';

describe('EntryExitComponentComponent', () => {
  let component: EntryExitComponentComponent;
  let fixture: ComponentFixture<EntryExitComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EntryExitComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EntryExitComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
