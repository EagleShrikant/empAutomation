import { Injectable } from '@angular/core';
import {SummaryRow} from './emp-summary-dashboard/summary-row'
import {SummaryService} from './emp-summary-dashboard/summary.service'

@Injectable()
export class DataService {

    constructor(){
       
    }
 currentEmployeeDataForEdit:any;
 currentProjectDataForEdit:any;
 
}