import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectReferenceDataUpdateComponent } from './project-reference-data-update.component';

describe('ProjectReferenceDataUpdateComponent', () => {
  let component: ProjectReferenceDataUpdateComponent;
  let fixture: ComponentFixture<ProjectReferenceDataUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectReferenceDataUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectReferenceDataUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
