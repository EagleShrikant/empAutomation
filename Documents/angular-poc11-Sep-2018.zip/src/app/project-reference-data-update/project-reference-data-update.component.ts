import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {SaveProjectService} from './save-project.service';
import { DataService} from '../data.sharing.service';
import {Project} from './project-details';

@Component({
  selector: 'app-project-reference-data-update',
  templateUrl: './project-reference-data-update.component.html',
  styleUrls: ['./project-reference-data-update.component.css']
})
export class ProjectReferenceDataUpdateComponent implements OnInit {

  editProjectData;
  
  constructor(private dataService : DataService , private router: Router, private saveProjectService:SaveProjectService) { 
    this.editProjectData = this.dataService.currentProjectDataForEdit;
    //console.log(this.editProjectData + ' ' + this.dataService.currentEmployeeDataForEdit );

    if (this.editProjectData === undefined){
      
      this.router.navigateByUrl('');
    }

    if (this.editProjectData === null){
      
      this.editProjectData = new Project();
      
      //this.editProjectData.last_MODIFIED_TS = new Date();
    } 
    
    

    //let date = new Date(this.editProjectData.billing_START_DATE);
    
    
    
    //console.log(this.editEmployeeData);


  }

  ngOnInit() {
  }

}
