import { TestBed, inject } from '@angular/core/testing';

import { SummaryChartsService } from './summary-charts.service';

describe('SummaryChartsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SummaryChartsService]
    });
  });

  it('should be created', inject([SummaryChartsService], (service: SummaryChartsService) => {
    expect(service).toBeTruthy();
  }));
});
