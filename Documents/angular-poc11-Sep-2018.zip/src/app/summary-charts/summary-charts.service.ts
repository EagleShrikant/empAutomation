import { Injectable } from '@angular/core';
import { SummaryRow } from '../emp-summary-dashboard/summary-row';
import {SummaryService} from '../emp-summary-dashboard/summary.service';

@Injectable({
  providedIn: 'root'
})
export class SummaryChartsService {
  
  OffshoreBillable=0;
  OffshoreBillableDeliveryTotal=0;
  OffshoreBillableDeliveryProjectswithPO=0;
  OffshoreBillableDeliverywithoutPO=0;
  OffshoreBillableNonDeliverySubTotal=0;
  OffshoreBillableDeliveryWD=0;
  OffshoreBillableMENoPOAmericas=0;
  OffshoreBillableOtherInvestment=0;
  OffshoreBillablePipelineProject=0;
  OffshoreBillableManagementProject=0;
  OffshoreBillableBuffer=0;

  OffshoreUnbillable = 0;
  OffshoreUnbillableDeliveryTotal = 0;
  OffshoreUnbillableDeliveryProjectswithPO = 0;
  OffshoreUnbillableDeliverywithoutPO = 0;
  OffshoreUnbillableNonDeliverySubTotal = 0;
  OffshoreUnbillableDeliveryWD = 0;
  OffshoreUnbillableMENoPOAmericas = 0;
  OffshoreUnbillableOtherInvestment = 0;
  OffshoreUnbillablePipelineProject = 0;
  OffshoreUnbillableManagementProject = 0;
  OffshoreUnbillableBuffer = 0;

  OnsiteBillable = 0;
  OnsiteBillableDeliveryTotal = 0;
  OnsiteBillableDeliveryProjectswithPO = 0;
  OnsiteBillableDeliverywithoutPO = 0;
  OnsiteBillableNonDeliverySubTotal = 0;
  OnsiteBillableDeliveryWD = 0;
  OnsiteBillableMENoPOAmericas = 0;
  OnsiteBillableOtherInvestment = 0;
  OnsiteBillablePipelineProject = 0;
  OnsiteBillableManagementProject = 0;
  OnsiteBillableBuffer = 0;

  OnsiteUnbillable = 0;
  OnsiteUnbillableDeliveryTotal = 0;
  OnsiteUnbillableDeliveryProjectswithPO = 0;
  OnsiteUnbillableDeliverywithoutPO = 0;
  OnsiteUnbillableNonDeliverySubTotal = 0;
  OnsiteUnbillableDeliveryWD = 0;
  OnsiteUnbillableMENoPOAmericas = 0;
  OnsiteUnbillableOtherInvestment = 0;
  OnsiteUnbillablePipelineProject = 0;
  OnsiteUnbillableManagementProject = 0;
  OnsiteUnbillableBuffer=0;

  resetValues(): void {

    this.OffshoreBillable = 0;
    this.OffshoreBillableDeliveryTotal = 0;
    this.OffshoreBillableDeliveryProjectswithPO = 0;
    this.OffshoreBillableDeliverywithoutPO = 0;
    this.OffshoreBillableNonDeliverySubTotal = 0;
    this.OffshoreBillableDeliveryWD = 0;
    this.OffshoreBillableMENoPOAmericas = 0;
    this.OffshoreBillableOtherInvestment = 0;
    this.OffshoreBillablePipelineProject = 0;
    this.OffshoreBillableManagementProject = 0;
    this.OffshoreBillableBuffer = 0;

    this.OffshoreUnbillable = 0;
    this.OffshoreUnbillableDeliveryTotal = 0;
    this.OffshoreUnbillableDeliveryProjectswithPO = 0;
    this.OffshoreUnbillableDeliverywithoutPO = 0;
    this.OffshoreUnbillableNonDeliverySubTotal = 0;
    this.OffshoreUnbillableDeliveryWD = 0;
    this.OffshoreUnbillableMENoPOAmericas = 0;
    this.OffshoreUnbillableOtherInvestment = 0;
    this.OffshoreUnbillablePipelineProject = 0;
    this.OffshoreUnbillableManagementProject = 0;
    this.OffshoreUnbillableBuffer = 0;

    this.OnsiteBillable = 0;
    this.OnsiteBillableDeliveryTotal = 0;
    this.OnsiteBillableDeliveryProjectswithPO = 0;
    this.OnsiteBillableDeliverywithoutPO = 0;
    this.OnsiteBillableNonDeliverySubTotal = 0;
    this.OnsiteBillableDeliveryWD = 0;
    this.OnsiteBillableMENoPOAmericas = 0;
    this.OnsiteBillableOtherInvestment = 0;
    this.OnsiteBillablePipelineProject = 0;
    this.OnsiteBillableManagementProject = 0;
    this.OnsiteBillableBuffer = 0;

    this.OnsiteUnbillable = 0;
    this.OnsiteUnbillableDeliveryTotal = 0;
    this.OnsiteUnbillableDeliveryProjectswithPO = 0;
    this.OnsiteUnbillableDeliverywithoutPO = 0;
    this.OnsiteUnbillableNonDeliverySubTotal = 0;
    this.OnsiteUnbillableDeliveryWD = 0;
    this.OnsiteUnbillableMENoPOAmericas = 0;
    this.OnsiteUnbillableOtherInvestment = 0;
    this.OnsiteUnbillablePipelineProject = 0;
    this.OnsiteUnbillableManagementProject = 0;
    this.OnsiteUnbillableBuffer = 0;
  }
  constructor( private summaryService : SummaryService) { 
    
    this.readValues();
    
  }

  readValues(){
    this.summaryService.getSummary()
    .subscribe(summaryData => {
      this.setValues(summaryData.summaryTable);
      
     }
    );
  }

  setValues(summaryRow : SummaryRow[]): void {
    //console.log(summaryRow);
    if(summaryRow !== undefined){
    this.resetValues();
    summaryRow.forEach(sr => {
      if (sr.columnRowName === 'Delivery Projects with PO') {
        this.OffshoreBillableDeliveryProjectswithPO = this.OffshoreBillableDeliveryProjectswithPO + sr.billedOffshore;
        this.OnsiteBillableDeliveryProjectswithPO = this.OnsiteBillableDeliveryProjectswithPO + sr.billedOnsite;
        this.OffshoreUnbillableDeliveryProjectswithPO = this.OffshoreUnbillableDeliveryProjectswithPO + sr.unbilledOffshore;
        this.OnsiteUnbillableDeliveryProjectswithPO = this.OnsiteUnbillableDeliveryProjectswithPO + sr.unbilledOnsite;
      }
      if (sr.columnRowName === 'Delivery without PO') {
        this.OffshoreBillableDeliverywithoutPO = this.OffshoreBillableDeliverywithoutPO + sr.billedOffshore;
        this.OnsiteBillableDeliverywithoutPO = this.OnsiteBillableDeliverywithoutPO + sr.billedOnsite;
        this.OffshoreUnbillableDeliverywithoutPO = this.OffshoreUnbillableDeliverywithoutPO + sr.unbilledOffshore;
        this.OnsiteUnbillableDeliverywithoutPO = this.OnsiteUnbillableDeliverywithoutPO + sr.unbilledOnsite;
      }

      //Delivery WD
      if (sr.columnRowName === 'Delivery WD') {
        this.OffshoreBillableDeliveryWD = this.OffshoreBillableDeliveryWD + sr.billedOffshore;
        this.OnsiteBillableDeliveryWD = this.OnsiteBillableDeliveryWD + sr.billedOnsite;
        this.OffshoreUnbillableDeliveryWD = this.OffshoreUnbillableDeliveryWD + sr.unbilledOffshore;
        this.OnsiteUnbillableDeliveryWD = this.OnsiteUnbillableDeliveryWD + sr.unbilledOnsite;
      }
      if (sr.columnRowName === 'ME No PO Americas') {
        this.OffshoreBillableMENoPOAmericas = this.OffshoreBillableMENoPOAmericas + sr.billedOffshore;
        this.OnsiteBillableMENoPOAmericas = this.OnsiteBillableMENoPOAmericas + sr.billedOnsite;
        this.OffshoreUnbillableMENoPOAmericas = this.OffshoreUnbillableMENoPOAmericas + sr.unbilledOffshore;
        this.OnsiteUnbillableMENoPOAmericas = this.OnsiteUnbillableMENoPOAmericas + sr.unbilledOnsite;
      }
      if (sr.columnRowName === 'Other Investment') {
        this.OffshoreBillableOtherInvestment = this.OffshoreBillableOtherInvestment + sr.billedOffshore;
        this.OnsiteBillableOtherInvestment = this.OnsiteBillableOtherInvestment + sr.billedOnsite;
        this.OffshoreUnbillableOtherInvestment = this.OffshoreUnbillableOtherInvestment + sr.unbilledOffshore;
        this.OnsiteUnbillableOtherInvestment = this.OnsiteUnbillableOtherInvestment + sr.unbilledOnsite;
      }
      if (sr.columnRowName === 'Pipeline Project') {
        this.OffshoreBillablePipelineProject = this.OffshoreBillablePipelineProject + sr.billedOffshore;
        this.OnsiteBillablePipelineProject = this.OnsiteBillablePipelineProject + sr.billedOnsite;
        this.OffshoreUnbillablePipelineProject = this.OffshoreUnbillablePipelineProject + sr.unbilledOffshore;
        this.OnsiteUnbillablePipelineProject = this.OnsiteUnbillablePipelineProject + sr.unbilledOnsite;
      }
      if (sr.columnRowName === 'Management Project') {
        this.OffshoreBillableManagementProject = this.OffshoreBillableManagementProject + sr.billedOffshore;
        this.OnsiteBillableManagementProject = this.OnsiteBillableManagementProject + sr.billedOnsite;
        this.OffshoreUnbillableManagementProject = this.OffshoreUnbillableManagementProject + sr.unbilledOffshore;
        this.OnsiteUnbillableManagementProject = this.OnsiteUnbillableManagementProject + sr.unbilledOnsite;
      }
      if (sr.columnRowName === 'Non Delivery Sub Total') {

      }
      if (sr.columnRowName === 'Buffer') {
        this.OffshoreBillableBuffer = this.OffshoreBillableBuffer + sr.billedOffshore;
        this.OnsiteBillableBuffer = this.OnsiteBillableBuffer + sr.billedOnsite;
        this.OffshoreUnbillableBuffer = this.OffshoreUnbillableBuffer + sr.unbilledOffshore;
        this.OnsiteUnbillableBuffer = this.OnsiteUnbillableBuffer + sr.unbilledOnsite;
      }
      if (sr.columnRowName === 'Grand Total') {


      }
    });

    this.OffshoreBillableDeliveryTotal = this.OffshoreBillableDeliveryProjectswithPO + this.OffshoreBillableDeliverywithoutPO;
    this.OnsiteBillableDeliveryTotal = this.OnsiteBillableDeliveryProjectswithPO + this.OnsiteBillableDeliverywithoutPO;
    this.OffshoreUnbillableDeliveryTotal = this.OffshoreUnbillableDeliveryProjectswithPO + this.OffshoreUnbillableDeliverywithoutPO;
    this.OnsiteUnbillableDeliveryTotal = this.OnsiteUnbillableDeliveryProjectswithPO + this.OnsiteUnbillableDeliverywithoutPO;

    this.OffshoreBillableNonDeliverySubTotal = this.OffshoreBillableDeliveryWD
      + this.OffshoreBillableMENoPOAmericas
      + this.OffshoreBillableOtherInvestment
      + this.OffshoreBillablePipelineProject
      + this.OffshoreBillableManagementProject;

    this.OffshoreUnbillableNonDeliverySubTotal = this.OffshoreUnbillableDeliveryWD
      + this.OffshoreUnbillableMENoPOAmericas
      + this.OffshoreUnbillableOtherInvestment
      + this.OffshoreUnbillablePipelineProject
      + this.OffshoreUnbillableManagementProject

    this.OnsiteBillableNonDeliverySubTotal =
      this.OnsiteBillableDeliveryWD
      + this.OnsiteBillableMENoPOAmericas
      + this.OnsiteBillableOtherInvestment
      + this.OnsiteBillablePipelineProject
      + this.OnsiteBillableManagementProject;

    this.OnsiteUnbillableNonDeliverySubTotal =
      this.OnsiteUnbillableDeliveryWD
      + this.OnsiteUnbillableMENoPOAmericas
      + this.OnsiteUnbillableOtherInvestment
      + this.OnsiteUnbillablePipelineProject
      + this.OnsiteUnbillableManagementProject;

    this.OffshoreBillable = this.OffshoreBillableDeliveryTotal + this.OffshoreBillableNonDeliverySubTotal + this.OffshoreBillableBuffer;
    this.OffshoreUnbillable = this.OffshoreUnbillableDeliveryTotal + this.OffshoreUnbillableNonDeliverySubTotal + this.OffshoreUnbillableBuffer;
    this.OnsiteBillable = this.OnsiteBillableDeliveryTotal + this.OnsiteBillableNonDeliverySubTotal + this.OnsiteBillableBuffer;
    this.OnsiteUnbillable = this.OnsiteUnbillableDeliveryTotal + this.OnsiteUnbillableNonDeliverySubTotal + this.OnsiteUnbillableBuffer;

    //console.log(this.OffshoreBillable  + " " + this.OffshoreUnbillable + " " + this.OnsiteBillable + " " +  this.OnsiteUnbillable );
  }
  }
}
