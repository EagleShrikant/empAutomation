import { Component, OnInit } from '@angular/core';
import * as  Highcharts from 'highcharts';
import More from 'highcharts/highcharts-more';
More(Highcharts);
import Drilldown from 'highcharts/modules/drilldown';
Drilldown(Highcharts);
// Load the exporting module.
import Exporting from 'highcharts/modules/exporting';
// Initialize exporting module.
Exporting(Highcharts);
import { ViewChild, ElementRef } from '@angular/core';
import { SummaryChartsService } from './summary-charts.service';



@Component({
  selector: 'app-summary-charts',
  templateUrl: './summary-charts.component.html',
  styleUrls: ['./summary-charts.component.css']
})


export class SummaryChartsComponent implements OnInit {

  @ViewChild("container", { read: ElementRef }) container: ElementRef;
  

  constructor(private summaryChartsService: SummaryChartsService) {
    //summaryChartsService.readValues();
    //this.setChartValue() ;
    
  }


  ngOnInit() {

    
   
  setTimeout( () => {   
    //console.log(this.summaryChartsService);
  Highcharts.chart(this.container.nativeElement, {
    // Created pie chart using Highchart
    chart: {
      type: 'pie',
      options3d: {
        enabled: true,
        alpha: 45
      }
    },
    title: {
      text: 'Summary using Pie chart'
    },
    subtitle: {
      text: 'TME 6 Reports'
    },
    plotOptions: {
      pie: {
        innerSize: 10,
        depth: 45
      }
    },
    tooltip: {
      headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
      pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
    },
    series: [{
      name: 'Summary',
      data: [
        {
          name: 'Offshore Billable',
          y: (
            (this.summaryChartsService.OffshoreBillable === 0)? 0 :
            ((this.summaryChartsService.OffshoreBillable) * 100 /
              (this.summaryChartsService.OffshoreBillable
                + this.summaryChartsService.OffshoreUnbillable
                + this.summaryChartsService.OnsiteBillable
                + this.summaryChartsService.OnsiteUnbillable)
            )
          ),
          drilldown: 'Offshore-Billable-Project-Type'
        },
        {
          name: 'Offshore Unbillable',
          y: (this.summaryChartsService.OffshoreUnbillable === 0)? 0 : 
          ((this.summaryChartsService.OffshoreUnbillable) * 100 /
            (this.summaryChartsService.OffshoreBillable
              + this.summaryChartsService.OffshoreUnbillable
              + this.summaryChartsService.OnsiteBillable
              + this.summaryChartsService.OnsiteUnbillable)
          ),
          drilldown: 'Offshore-Unbillable-Project-Type'
        },
        {
          name: 'Onsite-Billable',
          y: (this.summaryChartsService.OnsiteBillable === 0)? 0 : 
          ((this.summaryChartsService.OnsiteBillable) * 100 /
            (this.summaryChartsService.OffshoreBillable
              + this.summaryChartsService.OffshoreUnbillable
              + this.summaryChartsService.OnsiteBillable
              + this.summaryChartsService.OnsiteUnbillable)
          ),
          drilldown: 'Onsite-Billable-Project-Type'
        },
        {
          name: 'Onsite-Unbillable',
          y: (this.summaryChartsService.OnsiteUnbillable === 0)? 0 : 
          ((this.summaryChartsService.OnsiteUnbillable) * 100 /
            (this.summaryChartsService.OffshoreBillable
              + this.summaryChartsService.OffshoreUnbillable
              + this.summaryChartsService.OnsiteBillable
              + this.summaryChartsService.OnsiteUnbillable)
          ),
          drilldown: 'Onsite-Unbillable-Project-Type'
        }
      ]
    }],
    
    drilldown : {

        series: [

          //Offshore Billable
          {
            name: 'Offshore Billable',
            id: 'Offshore-Billable-Project-Type',
            data: [
              {
                name: 'Offshore-Billable-Delivery Total',
                y: 
                  (this.summaryChartsService.OffshoreBillableDeliveryTotal ===0)? 0 :
                (this.summaryChartsService.OffshoreBillableDeliveryTotal / 
                  this.summaryChartsService.OffshoreBillable)*100,
                drilldown: 'Offshore-Billable-Project-Type-PO'
              },
              {
                name: 'Offshore-Billable-Non Delivery Sub Total',
                y: (this.summaryChartsService.OffshoreBillableNonDeliverySubTotal ===0)? 0 :
                (this.summaryChartsService.OffshoreBillableNonDeliverySubTotal / this.summaryChartsService.OffshoreBillable)*100,
                drilldown: 'Offshore-Billable-Non Delivery Sub Total'
              },
              ['Offshore-Billable-Buffer', (this.summaryChartsService.OffshoreBillableBuffer ===0)? 0 :
              (this.summaryChartsService.OffshoreBillableBuffer / this.summaryChartsService.OffshoreBillable)*100],
            ]
          },
          {
            name: 'Offshore-Billable-Project-Type-PO',
            id: 'Offshore-Billable-Project-Type-PO',
            data: [
              ['Offshore-Billable-Delivery Projects with PO',
              (this.summaryChartsService.OffshoreBillableDeliveryProjectswithPO ===0)? 0 :
              (this.summaryChartsService.OffshoreBillableDeliveryProjectswithPO / 
                this.summaryChartsService.OffshoreBillableDeliveryTotal)*100
              ],
              ['Offshore-Billable-Delivery without PO', 
              (this.summaryChartsService.OffshoreBillableDeliverywithoutPO ===0)? 0 :
              (this.summaryChartsService.OffshoreBillableDeliverywithoutPO / 
                this.summaryChartsService.OffshoreBillableDeliveryTotal)*100
              ]
            ]
          },
          {
            name: 'Offshore-Billable-Non Delivery Sub Total',
            id: 'Offshore-Billable-Non Delivery Sub Total',
            data: [
              ['Delivery WD', 
              (this.summaryChartsService.OffshoreBillableDeliveryWD ===0)? 0 :
              (this.summaryChartsService.OffshoreBillableDeliveryWD / 
                this.summaryChartsService.OffshoreBillableNonDeliverySubTotal)*100
            ],
              ['ME No PO Americas', 
              (this.summaryChartsService.OffshoreBillableMENoPOAmericas ===0)? 0 :
              (this.summaryChartsService.OffshoreBillableMENoPOAmericas / 
                this.summaryChartsService.OffshoreBillableNonDeliverySubTotal)*100
              ],
              ['Other Investment', 
              (this.summaryChartsService.OffshoreBillableOtherInvestment ===0)? 0 :
              (this.summaryChartsService.OffshoreBillableOtherInvestment / 
                this.summaryChartsService.OffshoreBillableNonDeliverySubTotal)*100
            ],
              ['Pipeline Project', 
              (this.summaryChartsService.OffshoreBillablePipelineProject ===0)? 0 :
              (this.summaryChartsService.OffshoreBillablePipelineProject / 
                this.summaryChartsService.OffshoreBillableNonDeliverySubTotal)*100],
              ['Management Project', 
              (this.summaryChartsService.OffshoreBillableManagementProject ===0)? 0 :
              (this.summaryChartsService.OffshoreBillableManagementProject / 
                this.summaryChartsService.OffshoreBillableNonDeliverySubTotal)*100]
            ]
          },

          //Offshore Unbillable
          {
            name: 'Offshore-Unbillable',
            id: 'Offshore-Unbillable-Project-Type',
            data: [
              {
                name: 'Offshore-Unbillable-Delivery Total',
                y: 
                (this.summaryChartsService.OffshoreUnbillableDeliveryTotal ===0)? 0 :
                (this.summaryChartsService.OffshoreUnbillableDeliveryTotal / 
                  this.summaryChartsService.OffshoreUnbillable)*100,
                drilldown: 'Offshore-Unbillable-Project-Type-PO'
              },
              {
                name: 'Offshore-Unbillable-Non Delivery Sub Total',
                y: 
                (this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal ===0)? 0 :
                (this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal / 
                  this.summaryChartsService.OffshoreUnbillable)*100,
                drilldown: 'Offshore-Unbillable-Non Delivery Sub Total'
              },
              ['Offshore-Unbillable-Buffer', 
              (this.summaryChartsService.OffshoreUnbillableBuffer ===0)? 0 :
              (this.summaryChartsService.OffshoreUnbillableBuffer / 
                this.summaryChartsService.OffshoreUnbillable)*100,
            ],
            ]
          },
          {
            name: 'Offshore-Unbillable-Project-Type-PO',
            id: 'Offshore-Unbillable-Project-Type-PO',
            data: [
              ['Offshore-Unbillable-Delivery Projects with PO', 
              (this.summaryChartsService.OffshoreUnbillableDeliveryProjectswithPO ===0)? 0 :
              (this.summaryChartsService.OffshoreUnbillableDeliveryProjectswithPO / 
                this.summaryChartsService.OffshoreUnbillableDeliveryTotal)*100,
            ],
              ['Offshore-Unbillable-Delivery without PO', 
              (this.summaryChartsService.OffshoreUnbillableDeliverywithoutPO ===0)? 0 :
              (this.summaryChartsService.OffshoreUnbillableDeliverywithoutPO / 
                this.summaryChartsService.OffshoreUnbillableDeliveryTotal)*100,
            ]
            ]
          },
          {
            name: 'Offshore-Unbillable-Non Delivery Sub Total',
            id: 'Offshore-Unbillable-Non Delivery Sub Total',
            data: [
              ['Delivery WD', 
              (this.summaryChartsService.OffshoreUnbillableDeliveryWD ===0)? 0 :
              (this.summaryChartsService.OffshoreUnbillableDeliveryWD / 
                this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal)*100
            
            ],
              ['ME No PO Americas', 
              (this.summaryChartsService.OffshoreUnbillableMENoPOAmericas ===0)? 0 :
              (this.summaryChartsService.OffshoreUnbillableMENoPOAmericas / 
                this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal)*100
            
            ],
              ['Other Investment', 
              (this.summaryChartsService.OffshoreUnbillableOtherInvestment ===0)? 0 :
              (this.summaryChartsService.OffshoreUnbillableOtherInvestment / 
                this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal)*100
            ],
              ['Pipeline Project', 
              (this.summaryChartsService.OffshoreUnbillablePipelineProject ===0)? 0 :
              (this.summaryChartsService.OffshoreUnbillablePipelineProject / 
                this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal)*100
            ],
              ['Management Project', 
              (this.summaryChartsService.OffshoreUnbillableManagementProject ===0)? 0 :
              (this.summaryChartsService.OffshoreUnbillableManagementProject / 
                this.summaryChartsService.OffshoreUnbillableNonDeliverySubTotal)*100
            ]
            ]
          },
          //Onsite Billable

          {
            name: 'Onsite Billable',
            id: 'Onsite-Billable-Project-Type',
            data: [
              {
                name: 'Onsite-Billable-Delivery Total',
                y: 
                  (this.summaryChartsService.OnsiteBillableDeliveryTotal ===0)? 0 :
                (this.summaryChartsService.OnsiteBillableDeliveryTotal / 
                  this.summaryChartsService.OnsiteBillable)*100,
                drilldown: 'Onsite-Billable-Project-Type-PO'
              },
              {
                name: 'Onsite-Billable-Non Delivery Sub Total',
                y: (this.summaryChartsService.OnsiteBillableNonDeliverySubTotal ===0)? 0 :
                (this.summaryChartsService.OnsiteBillableNonDeliverySubTotal / this.summaryChartsService.OnsiteBillable)*100,
                drilldown: 'Onsite-Billable-Non Delivery Sub Total'
              },
              ['Onsite-Billable-Buffer', (this.summaryChartsService.OnsiteBillableBuffer ===0)? 0 :
              (this.summaryChartsService.OnsiteBillableBuffer / this.summaryChartsService.OnsiteBillable)*100],
            ]
          },
          {
            name: 'Onsite-Billable-Project-Type-PO',
            id: 'Onsite-Billable-Project-Type-PO',
            data: [
              ['Onsite-Billable-Delivery Projects with PO',
              (this.summaryChartsService.OnsiteBillableDeliveryProjectswithPO ===0)? 0 :
              (this.summaryChartsService.OnsiteBillableDeliveryProjectswithPO / 
                this.summaryChartsService.OnsiteBillableDeliveryTotal)*100
              ],
              ['Onsite-Billable-Delivery without PO', 
              (this.summaryChartsService.OnsiteBillableDeliverywithoutPO ===0)? 0 :
              (this.summaryChartsService.OnsiteBillableDeliverywithoutPO / 
                this.summaryChartsService.OnsiteBillableDeliveryTotal)*100
              ]
            ]
          },
          {
            name: 'Onsite-Billable-Non Delivery Sub Total',
            id: 'Onsite-Billable-Non Delivery Sub Total',
            data: [
              ['Delivery WD', 
              (this.summaryChartsService.OnsiteBillableDeliveryWD ===0)? 0 :
              (this.summaryChartsService.OnsiteBillableDeliveryWD / 
                this.summaryChartsService.OnsiteBillableNonDeliverySubTotal)*100
            ],
              ['ME No PO Americas', 
              (this.summaryChartsService.OnsiteBillableMENoPOAmericas ===0)? 0 :
              (this.summaryChartsService.OnsiteBillableMENoPOAmericas / 
                this.summaryChartsService.OnsiteBillableNonDeliverySubTotal)*100
              ],
              ['Other Investment', 
              (this.summaryChartsService.OnsiteBillableOtherInvestment ===0)? 0 :
              (this.summaryChartsService.OnsiteBillableOtherInvestment / 
                this.summaryChartsService.OnsiteBillableNonDeliverySubTotal)*100
            ],
              ['Pipeline Project', 
              (this.summaryChartsService.OnsiteBillablePipelineProject ===0)? 0 :
              (this.summaryChartsService.OnsiteBillablePipelineProject / 
                this.summaryChartsService.OnsiteBillableNonDeliverySubTotal)*100],
              ['Management Project', 
              (this.summaryChartsService.OnsiteBillableManagementProject ===0)? 0 :
              (this.summaryChartsService.OnsiteBillableManagementProject / 
                this.summaryChartsService.OnsiteBillableNonDeliverySubTotal)*100]
            ]
          },


          //Onsite Unbillable

          {
            name: 'Onsite-Unbillable',
            id: 'Onsite-Unbillable-Project-Type',
            data: [
              {
                name: 'Onsite-Unbillable-Delivery Total',
                y: 
                (this.summaryChartsService.OnsiteUnbillableDeliveryTotal ===0)? 0 :
                (this.summaryChartsService.OnsiteUnbillableDeliveryTotal / 
                  this.summaryChartsService.OnsiteUnbillable)*100,
                drilldown: 'Onsite-Unbillable-Project-Type-PO'
              },
              {
                name: 'Onsite-Unbillable-Non Delivery Sub Total',
                y: 
                (this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal ===0)? 0 :
                (this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal / 
                  this.summaryChartsService.OnsiteUnbillable)*100,
                drilldown: 'Onsite-Unbillable-Non Delivery Sub Total'
              },
              ['Onsite-Unbillable-Buffer', 
              (this.summaryChartsService.OnsiteUnbillableBuffer ===0)? 0 :
              (this.summaryChartsService.OnsiteUnbillableBuffer / 
                this.summaryChartsService.OnsiteUnbillable)*100,
            ],
            ]
          },
          {
            name: 'Onsite-Unbillable-Project-Type-PO',
            id: 'Onsite-Unbillable-Project-Type-PO',
            data: [
              ['Onsite-Unbillable-Delivery Projects with PO', 
              (this.summaryChartsService.OnsiteUnbillableDeliveryProjectswithPO ===0)? 0 :
              (this.summaryChartsService.OnsiteUnbillableDeliveryProjectswithPO / 
                this.summaryChartsService.OnsiteUnbillableDeliveryTotal)*100,
            ],
              ['Onsite-Unbillable-Delivery without PO', 
              (this.summaryChartsService.OnsiteUnbillableDeliverywithoutPO ===0)? 0 :
              (this.summaryChartsService.OnsiteUnbillableDeliverywithoutPO / 
                this.summaryChartsService.OnsiteUnbillableDeliveryTotal)*100,
            ]
            ]
          },
          {
            name: 'Onsite-Unbillable-Non Delivery Sub Total',
            id: 'Onsite-Unbillable-Non Delivery Sub Total',
            data: [
              ['Delivery WD', 
              (this.summaryChartsService.OnsiteUnbillableDeliveryWD ===0)? 0 :
              (this.summaryChartsService.OnsiteUnbillableDeliveryWD / 
                this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal)*100
            
            ],
              ['ME No PO Americas', 
              (this.summaryChartsService.OnsiteUnbillableMENoPOAmericas ===0)? 0 :
              (this.summaryChartsService.OnsiteUnbillableMENoPOAmericas / 
                this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal)*100
            
            ],
              ['Other Investment', 
              (this.summaryChartsService.OnsiteUnbillableOtherInvestment ===0)? 0 :
              (this.summaryChartsService.OnsiteUnbillableOtherInvestment / 
                this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal)*100
            ],
              ['Pipeline Project', 
              (this.summaryChartsService.OnsiteUnbillablePipelineProject ===0)? 0 :
              (this.summaryChartsService.OnsiteUnbillablePipelineProject / 
                this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal)*100
            ],
              ['Management Project', 
              (this.summaryChartsService.OnsiteUnbillableManagementProject ===0)? 0 :
              (this.summaryChartsService.OnsiteUnbillableManagementProject / 
                this.summaryChartsService.OnsiteUnbillableNonDeliverySubTotal)*100
            ]
            ]
          }
        ]
      }

  });

}, 500 );

  }


}
