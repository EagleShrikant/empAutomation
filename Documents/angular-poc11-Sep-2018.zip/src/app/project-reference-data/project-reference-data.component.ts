import { Component, OnInit, ViewChild } from '@angular/core';
import {DataService} from '../data.sharing.service';
import {MatPaginator, MatTableDataSource,MatSort} from '@angular/material';
import {ProjectDataServiceService} from './project-data-service.service';
import {SelectionModel} from '@angular/cdk/collections';
import {Project} from '../project-reference-data-update/project-details';

@Component({
  selector: 'app-project-reference-data',
  templateUrl: './project-reference-data.component.html',
  styleUrls: ['./project-reference-data.component.css']
})
export class ProjectReferenceDataComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  projectList : any[];
  selection;
  displayedColumns: string[] = ['project_ID' , 'customer_NAME' , 'project_DESCRIPTION' , 'project_TYPE' , 'dm', 'is_PROJECT_ACTIVE'  ,'onEdit'];
  dataSource;

  constructor(private projectDataServiceService: ProjectDataServiceService, private dataService:DataService) {
    this.getProjectData();
   }

   applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  ngOnInit() {
  }

  getProjectData(): void {
    this.projectDataServiceService.getProjectData()
    .subscribe(projectData => {
      this.projectList = projectData
      this.projectList.forEach(employee => {

            if (null !== employee.billing_START_DATE){
              let date = new Date(employee.billing_START_DATE);
              
             //console.log(date);
             employee.billing_START_DATE = date;
             this.dataSource= new MatTableDataSource<any>(this.projectList);
             this.selection = new SelectionModel<any>(true, []);
             this.dataSource.paginator = this.paginator;
             this.dataSource.sort = this.sort;
             this.applyFilter('');
            }
      });
    }
    );      
  }

  addNewProject(){
    
    this.dataService.currentProjectDataForEdit = new Project();
    console.log('addNewProject ' + this.dataService.currentProjectDataForEdit);
  }

  edit(i): void{
    this.dataService.currentProjectDataForEdit = this.projectList[i];
    console.log(this.dataService.currentProjectDataForEdit);
  }

}
