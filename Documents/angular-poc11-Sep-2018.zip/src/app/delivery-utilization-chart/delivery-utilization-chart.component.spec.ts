import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryUtilizationChartComponent } from './delivery-utilization-chart.component';

describe('DeliveryUtilizationChartComponent', () => {
  let component: DeliveryUtilizationChartComponent;
  let fixture: ComponentFixture<DeliveryUtilizationChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryUtilizationChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryUtilizationChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
