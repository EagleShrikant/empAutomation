
export class DeliveryUtilizationRow{

    UT_DATE: Date;
    utilization_DELIVERY_PROJ_WITH_PO: number;
    utilization_DELIVERY_WITHOUT_PO: number;
    delivery_FTE_WITHOUT_PO: number;
    utilization_IBU: number;
    
}