import { SummaryRow} from './summary-row';
export class SummaryTable {
  summaryTable : SummaryRow[];
}