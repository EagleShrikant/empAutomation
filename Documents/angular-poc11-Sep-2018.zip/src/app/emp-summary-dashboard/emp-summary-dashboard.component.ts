import { Component, OnInit } from '@angular/core';

import { SummaryRow} from './summary-row';
import {CdkTableModule} from '@angular/cdk/table';
import {CdkTreeModule} from '@angular/cdk/tree';
import { NgModule } from '@angular/core';
import { SummaryService } from './summary.service';
import { SummaryTable} from './summary-table';
import {DataService} from '../data.sharing.service';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
@Component({
  selector: 'app-emp-summary-dashboard',
  templateUrl: './emp-summary-dashboard.component.html',
  styleUrls: ['./emp-summary-dashboard.component.css']
})



export class EmpSummaryDashboardComponent implements OnInit {
displayedColumns: string[] = ['columnRowName','totalOffshore','totalOnsite','totalAllocated','unbilledOffshore','unbilledOnsite','doNOTBILL','totalUnbilled','billedOffshore','billedOnsite', 'totalBilled' , 'perBilled' ];

  summaryData: SummaryTable;
  summaryList: SummaryRow[];


    getSummary(): void {
    this.summaryService.getSummary()
    .subscribe(summaryData => this.summaryList = summaryData.summaryTable);
  
    
/**
    this.summaryTable = [{"columnRowName":"Delivery Projects with PO","totalOffshore":145,"totalOnsite":65,"totalAllocated":210,"unbilledOffshore":9,"unbilledOnsite":5,"doNOTBILL":0,"totalUnbilled":14,"billedOffshore":136,"billedOnsite":60,"totalBilled":196},{"columnRowName":"Delivery without PO","totalOffshore":0,"totalOnsite":0,"totalAllocated":0,"unbilledOffshore":0,"unbilledOnsite":0,"doNOTBILL":0,"totalUnbilled":0,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":0,"totalOnsite":0,"totalAllocated":0,"unbilledOffshore":0,"unbilledOnsite":0,"doNOTBILL":0,"totalUnbilled":0,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":6,"totalOnsite":1,"totalAllocated":7,"unbilledOffshore":6,"unbilledOnsite":1,"doNOTBILL":0,"totalUnbilled":7,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":4,"totalOnsite":1,"totalAllocated":5,"unbilledOffshore":4,"unbilledOnsite":1,"doNOTBILL":0,"totalUnbilled":5,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":22,"totalOnsite":0,"totalAllocated":22,"unbilledOffshore":22,"unbilledOnsite":0,"doNOTBILL":0,"totalUnbilled":22,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":0,"totalOnsite":0,"totalAllocated":0,"unbilledOffshore":0,"unbilledOnsite":0,"doNOTBILL":0,"totalUnbilled":0,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":10,"totalOnsite":10,"totalAllocated":20,"unbilledOffshore":10,"unbilledOnsite":10,"doNOTBILL":0,"totalUnbilled":20,"billedOffshore":0,"billedOnsite":0,"totalBilled":0},{"columnRowName":"Delivery Projects with PO","totalOffshore":6,"totalOnsite":4,"totalAllocated":10,"unbilledOffshore":6,"unbilledOnsite":4,"doNOTBILL":0,"totalUnbilled":10,"billedOffshore":0,"billedOnsite":0,"totalBilled":0}];
 */
  }
  
  constructor(private summaryService: SummaryService, private dataService : DataService) {

    this.getSummary();
    //dataService.currentEmployeeData = this.summaryList;
   }

  ngOnInit() {
    //this.getSummary();

  }


print = () => {
  let doc = new jsPDF(); 
  console.log(this.summaryList);
  doc.autoTable({
    //head: [['Log','', 'Amount']],
    head: [['columnRowName','totalOffshore','totalOnsite','totalAllocated','unbilledOffshore','unbilledOnsite','doNOTBILL','totalUnbilled','billedOffshore','billedOnsite', 'totalBilled' , 'perBilled' ]],
    body: this.summaryList //returning [["log1", "$100"], ["log2", "$200"]]
    //body:  [["log1", "$100"], ["log2", "$200"]]
    
    
  });
  
  doc.save('table.pdf');
}

getLiveData(){

}

}