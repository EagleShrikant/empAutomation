import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnbillableDataComponent } from './unbillable-data.component';

describe('UnbillableDataComponent', () => {
  let component: UnbillableDataComponent;
  let fixture: ComponentFixture<UnbillableDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnbillableDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnbillableDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
