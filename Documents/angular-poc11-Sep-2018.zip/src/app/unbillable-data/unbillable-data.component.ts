import { Component, OnInit, ViewChild } from '@angular/core';
import { UnbilledDataServiceService} from './unbilled.data.service.service';
import {DataService} from '../data.sharing.service';
import {MatPaginator, MatTableDataSource,MatSort} from '@angular/material';

@Component({
  selector: 'app-unbillable-data',
  templateUrl: './unbillable-data.component.html',
  styleUrls: ['./unbillable-data.component.css']
})
export class UnbillableDataComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  unbilledEmployeeList : any[];

  displayedColumns: string[] = ['empid' , 'emp_NAME' , 'comments' , 'program_MANAGER_NAME' , 'customer_NAME', 'category'  ,'onEdit'];
  dataSource;
  constructor(private unbilledDataServiceService: UnbilledDataServiceService, private dataService:DataService) {
    this.getUnbilledData();
   }

  ngOnInit() {
    //console.log(this.dataSource);
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  getUnbilledData(): void {
    this.unbilledDataServiceService.getUnbilledData()
    .subscribe(unbilledData => {
      this.unbilledEmployeeList = unbilledData
      this.unbilledEmployeeList.forEach(employee => {

            if (null !== employee.billing_START_DATE){
              let date = new Date(employee.billing_START_DATE);
              
             //console.log(date);
             employee.billing_START_DATE = date;
             this.dataSource= new MatTableDataSource<any>(this.unbilledEmployeeList);
             this.dataSource.paginator = this.paginator;
             this.dataSource.sort = this.sort;
             this.applyFilter('');
            }
      });
    }
    );


    
    
  }

  

  edit(i): void{
     this.dataService.currentEmployeeDataForEdit = this.unbilledEmployeeList[i];
     //console.log(this.dataService.currentEmployeeDataForEdit);
  }


}
