export const environment = {
  production: true,
  summaryDataURL: 'http://demo8976463.mockable.io/mvc/getSummaryData',
  entryExitDataURL: 'http://demo0220709.mockable.io/getEntryExitData',
  unbilledDataURL:'http://demo8976463.mockable.io/mvc/getUnbillableData',
  saveEmployeeURL:'http://10.10.195.63:9089/mvc/updateEmployee',
  trendsURL:'http://demo8976463.mockable.io/mvc/getTrendsData'
};
