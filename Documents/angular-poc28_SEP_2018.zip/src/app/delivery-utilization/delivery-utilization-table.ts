import { DeliveryUtilizationRow} from './delivery-utilization-row';
export class DeliveryUtilizationTable {
    deliveryUtilizationTable : DeliveryUtilizationRow[];
}