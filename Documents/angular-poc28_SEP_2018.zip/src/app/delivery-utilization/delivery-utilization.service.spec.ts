import { TestBed, inject } from '@angular/core/testing';

import { DeliveryUtilizationService } from './delivery-utilization.service';

describe('DeliveryUtilizationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DeliveryUtilizationService]
    });
  });

  it('should be created', inject([DeliveryUtilizationService], (service: DeliveryUtilizationService) => {
    expect(service).toBeTruthy();
  }));
});
