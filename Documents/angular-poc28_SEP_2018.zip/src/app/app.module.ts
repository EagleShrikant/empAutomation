import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';

import {HttpClientModule} from '@angular/common/http';
import {CdkTableModule} from '@angular/cdk/table';
import {CdkTreeModule} from '@angular/cdk/tree';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { EmpSummaryDashboardComponent } from '../app/emp-summary-dashboard/emp-summary-dashboard.component';
import { SummaryService } from '../app/emp-summary-dashboard/summary.service';
import { HttpModule, JsonpModule } from '@angular/http';
import { routing } from "./app.routing";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import {
  MatAutocompleteModule,
  MatBadgeModule,
  MatBottomSheetModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatTreeModule,
} from '@angular/material';
import { EntryExitComponentComponent } from '../app/entry-exit-component/entry-exit-component.component';
import { EntryExitService } from '../app/entry-exit-component/entry-exit.service';
import { SummaryChartsComponent } from './summary-charts/summary-charts.component';
import { DataService} from './data.sharing.service';
import { UnbillableDataComponent } from './unbillable-data/unbillable-data.component';
import {UnbilledDataServiceService} from './unbillable-data/unbilled.data.service.service';
import { EditUnbillableDataComponent } from './edit-unbillable-data/edit-unbillable-data.component';
import { HomeComponent } from './home/home.component';
import { TrendsComponent } from './trends/trends.component';
import { TrendsChartComponent } from './trends-chart/trends-chart.component';
import { DeliveryUtilizationComponent } from './delivery-utilization/delivery-utilization.component';
import { DeliveryUtilizationChartComponent } from './delivery-utilization-chart/delivery-utilization-chart.component';
import { ProjectReferenceDataComponent } from './project-reference-data/project-reference-data.component';
import { ProjectReferenceDataUpdateComponent } from './project-reference-data-update/project-reference-data-update.component';
import { ProjectDataServiceService } from './project-reference-data/project-data-service.service';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { MatFileUploadModule } from 'angular-material-fileupload';

@NgModule({
  exports: [
    CdkTableModule,
    CdkTreeModule,
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatStepperModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
  ],
  declarations: []
})
export class DemoMaterialModule {}


@NgModule({
  declarations: [
    AppComponent,
    EmpSummaryDashboardComponent,
    EntryExitComponentComponent,
    SummaryChartsComponent,
    UnbillableDataComponent,
    EditUnbillableDataComponent,
    HomeComponent,
    TrendsComponent, TrendsChartComponent,
    DeliveryUtilizationComponent, DeliveryUtilizationChartComponent,
    ProjectReferenceDataComponent, 
    ProjectReferenceDataUpdateComponent,
    FileUploadComponent
  ],
  imports: [
    BrowserModule,
    FormsModule, 
    HttpClientModule,
    DemoMaterialModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    HttpModule,
    JsonpModule,
    routing,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    MatFileUploadModule,
    MatIconModule
  ],
  providers: [
    SummaryService,
    EntryExitService,
    DataService,
    UnbilledDataServiceService,
    ProjectDataServiceService
  ,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
