import { Component, OnInit } from '@angular/core';
import { TrendsTable } from './trends-table';
import { TrendsRow } from './trends-row';
import { TrendsService } from './trends.service';

@Component({
  selector: 'app-trends',
  templateUrl: './trends.component.html',
  styleUrls: ['./trends.component.css']
})
export class TrendsComponent implements OnInit {

  displayedColumns: string[] = [
  'IT_DATE' , 
  'delivery_TOTAL',
  'non_DELIVERY_SUB_TOTAL',
  'ibu_BUFFER',
  'total_UNBILLED',
  'total_BILLED',
  'unbilled_DELIVERY',
  'ibu_TOTAL' ];
  
  trendsData: TrendsTable;
  trendsList: TrendsRow[];

  getTrends(): void {
    this.trendsService.getTrends()
    .subscribe(trendsData => {
      this.trendsList = trendsData;
    });
    
  }

  constructor(private trendsService: TrendsService) { this.getTrends(); }

  ngOnInit() {
  }

}
