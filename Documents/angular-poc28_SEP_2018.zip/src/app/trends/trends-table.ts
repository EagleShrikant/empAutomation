import { TrendsRow} from './trends-row';
export class TrendsTable {
  trendsTable : TrendsRow[];
}