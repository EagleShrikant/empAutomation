import { TestBed, inject } from '@angular/core/testing';

import { UnbilledDataServiceService } from './unbilled.data.service.service';

describe('Unbilled.Data.ServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UnbilledDataServiceService]
    });
  });

  it('should be created', inject([UnbilledDataServiceService], (service: UnbilledDataServiceService) => {
    expect(service).toBeTruthy();
  }));
});
