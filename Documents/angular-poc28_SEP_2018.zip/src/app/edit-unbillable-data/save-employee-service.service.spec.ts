import { TestBed, inject } from '@angular/core/testing';

import { SaveEmployeeServiceService } from './save-employee-service.service';

describe('SaveEmployeeServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SaveEmployeeServiceService]
    });
  });

  it('should be created', inject([SaveEmployeeServiceService], (service: SaveEmployeeServiceService) => {
    expect(service).toBeTruthy();
  }));
});
