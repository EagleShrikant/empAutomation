import { Injectable } from '@angular/core';
import {environment} from '../../environments/environment'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class SaveEmployeeServiceService {
  private saveEmployeeDataURL = environment.saveEmployeeURL; 
  constructor(private http: HttpClient,) { }

  /** GET heroes from the server */
  getUnbilledData(): Observable<any[]> {
    return this.http.get<any[]>(this.saveEmployeeDataURL)
      .pipe(
        /**tap(heroes => this.log('fetched heroes')),*/
        //catchError(this.handleError('getSummary', []))
      );
  }

  updateEmployee (employee : any): Observable<any> {
    return this.http.post<any>(this.saveEmployeeDataURL, employee, httpOptions)
      .pipe(
        //catchError(this.handleError('addHero', hero))
      );
  }

}
