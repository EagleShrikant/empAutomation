import { Component, OnInit } from '@angular/core';
import {environment} from '../../environments/environment';
import { FileUploadService } from './file-upload.service';


@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {

  fileUploadURL:String;
  response : any;
  constructor(private fileUploadService: FileUploadService) { 
    this.fileUploadURL = environment.fileUploadURL;
  }

  ngOnInit() {
  }

  runPythonScript(): void {
    this.fileUploadService.runPythonFile()
    .subscribe(response => this.response = response);
  }

}
