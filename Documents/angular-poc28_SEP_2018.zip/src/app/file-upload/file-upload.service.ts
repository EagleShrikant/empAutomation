import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import {environment} from '../../environments/environment'

@Injectable({
  providedIn: 'root'
})
export class FileUploadService {

  private runPythonScript = environment.runPythonScript;

  constructor(private http: HttpClient) {
   }

   runPythonFile(): Observable<any> {
    return this.http.get<any>(this.runPythonScript)
      .pipe(
        /**tap(heroes => this.log('fetched heroes')),*/
        //catchError(this.handleError('getSummary', []))
      );
  }
}
