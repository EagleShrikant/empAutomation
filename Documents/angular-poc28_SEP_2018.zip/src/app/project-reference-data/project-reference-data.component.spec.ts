import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectReferenceDataComponent } from './project-reference-data.component';

describe('ProjectReferenceDataComponent', () => {
  let component: ProjectReferenceDataComponent;
  let fixture: ComponentFixture<ProjectReferenceDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectReferenceDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectReferenceDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
