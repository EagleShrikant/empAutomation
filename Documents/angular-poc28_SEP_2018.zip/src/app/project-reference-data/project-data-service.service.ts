import { Injectable } from '@angular/core';
import {environment} from '../../environments/environment'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ProjectDataServiceService {
  private projectDataURL = environment.projectDataURL; 
  projectData: any[];
  constructor(private http: HttpClient,) { }

  /** GET heroes from the server */
  getProjectData(): Observable<any[]> {
    return this.http.get<any[]>(this.projectDataURL)
      .pipe(
        /**tap(heroes => this.log('fetched heroes')),*/
        //catchError(this.handleError('getSummary', []))
      );
  }

}
