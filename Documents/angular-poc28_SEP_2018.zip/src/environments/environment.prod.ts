export const environment = {
  production: true,
  //summaryDataURL: 'http://demo8976463.mockable.io/mvc/getSummaryData',
  //entryExitDataURL: 'http://demo0220709.mockable.io/getEntryExitData',
  //unbilledDataURL:'http://demo8976463.mockable.io/mvc/getUnbillableData',
  //saveEmployeeURL:'http://10.10.195.63:9089/mvc/updateEmployee',
  //trendsURL:'http://demo8976463.mockable.io/mvc/getTrendsData'


  
  summaryDataURL: 'http://10.10.195.63:9089/mvc/getSummaryData',
  entryExitDataURL: 'http://10.10.195.63:9089/mvc/getEntryExitData',
  unbilledDataURL:'http://10.10.195.63:9089/mvc/getUnbillableData',
  saveEmployeeURL:'http://10.10.195.63:9089/mvc/updateEmployee',
  trendsURL:'http://10.10.195.63:9089/mvc/getTrendsData',
  deliveryUtilizationURL: 'http://10.10.195.63:9089/mvc/getDeliveryUtilizationData',
  projectDataURL: 'http://10.10.195.63:9089/mvc/getProjectData',
  updateProductURL: 'http://10.10.195.63:9089/mvc/updateProjectData',
  addProductURL:'http://10.10.195.63:9089/mvc/createProjectData',
  fileUploadURL:'http://10.10.195.63:9089/mvc/fileUpload',
  runPythonScript:'http://10.10.195.63:9089/mvc/runPythonScript'

};
