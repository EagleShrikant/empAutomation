import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entry-exit-component',
  templateUrl: './entry-exit-component.component.html',
  styleUrls: ['./entry-exit-component.component.css']
})
export class EntryExitComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
