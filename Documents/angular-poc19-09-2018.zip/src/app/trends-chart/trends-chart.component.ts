import { Component, OnInit } from '@angular/core';
import * as  Highcharts from 'highcharts';
import More from 'highcharts/highcharts-more';
More(Highcharts);
import Drilldown from 'highcharts/modules/drilldown';
Drilldown(Highcharts);
// Load the exporting module.
import Exporting from 'highcharts/modules/exporting';
// Initialize exporting module.
Exporting(Highcharts);
import { ViewChild, ElementRef } from '@angular/core';
import { TrendsTable } from '../trends/trends-table';
import { TrendsRow } from '../trends/trends-row';
import { TrendsService } from '../trends/trends.service';
import { TrendsSeries } from './trends-series';


@Component({
  selector: 'app-trends-chart',
  templateUrl: './trends-chart.component.html',
  styleUrls: ['./trends-chart.component.css']
})
export class TrendsChartComponent implements OnInit {
  //@ViewChild("container", { read: ElementRef }) container: ElementRef;
  chart;
  trendSeries : TrendsSeries = new TrendsSeries;
  tempDate : Date;
  constructor( private trendsService: TrendsService ) { }

  seriesList: string[] = [
  'DELIVERY_TOTAL',
  'NON_DELIVERY_SUB_TOTAL',
  'IBU_BUFFER',
  'TOTAL_UNBILLED',
  'TOTAL_BILLED',
  'UNBILLED_DELIVERY',
  'IBU_TOTAL'
  ]

  trendsData: TrendsTable ;
  trendsList: TrendsRow[];
  
  getTrends(): void {
    this.trendsService.getTrends()
    .subscribe(trendsData => {
      this.trendsList = trendsData;
      //console.log(this.trendsList);
      this.refreshSeriesData(this.trendsList);
      
    });
    
  }

  ngOnInit() {
    this.getTrends();
    this.chart = Highcharts.chart('container', {

      title: {
          text: 'Trends for IBU'
      },
  
      subtitle: {
          text: 'Tech Mahindra'
      },
  
      yAxis: {
          title: {
              text: 'Number of Employees'
          }
      },
      xAxis: {
        type: 'datetime',
        dateTimeLabelFormats: { // don't display the dummy year
            month: '%e. %b',
            year: '%b'
        },
        title: {
            text: 'Date'
        }
    },
      legend: {
          layout: 'vertical',
          align: 'right',
          verticalAlign: 'middle'
      },
  
     
  
  plotOptions: {
    series: {
        label: {
            connectorAllowed: false
        }
       // pointStart: Date.UTC(2014, 11, 2),
    }
},
      series: [],
  
      responsive: {
          rules: [{
              condition: {
                  maxWidth: 500
              },
              chartOptions: {
                  legend: {
                      layout: 'horizontal',
                      align: 'center',
                      verticalAlign: 'bottom'
                  }
              }
          }]
      }
  
  });
  }


  refreshSeriesData(trendsListP : TrendsRow[]){
    for (var i = 0; this.chart.series.length > 0 ; i++){
      this.chart.series[0].remove(true);
    }
    
    this.getTrendSeries(trendsListP);
    //console.log(this.trendSeries);


    this.chart.addSeries({
      name: 'DELIVERY_TOTAL',
      data: this.trendSeries.DELIVERY_TOTAL      
    });

    this.chart.addSeries({
      name: 'NON_DELIVERY_SUB_TOTAL',
      data:this.trendSeries.NON_DELIVERY_SUB_TOTAL
    });
    
    this.chart.addSeries({
      name: 'IBU_BUFFER',
      data: this.trendSeries.IBU_BUFFER
    });
    this.chart.addSeries({
      name: 'TOTAL_UNBILLED',
      data: this.trendSeries.TOTAL_UNBILLED
    });
    this.chart.addSeries({
      name: 'TOTAL_BILLED',
      data: this.trendSeries.TOTAL_BILLED
    });
    this.chart.addSeries({
      name: 'UNBILLED_DELIVERY',
      data: this.trendSeries.UNBILLED_DELIVERY
    });
    this.chart.addSeries({
      name: 'IBU_TOTAL',
      data: this.trendSeries.IBU_TOTAL
    });
    
    
    
    
    
    

  }

  getTrendSeries(trendsListPS : TrendsRow[]){
    
    this.trendSeries = new TrendsSeries;
    for(var i=0;i< trendsListPS.length; i++){
      
      this.tempDate = new Date(trendsListPS[i].IT_DATE);
      //console.log(this.tempDate.getUTCDate());

      this.trendSeries.DELIVERY_TOTAL.push(
        [Date.UTC(this.tempDate.getUTCFullYear(),
        this.tempDate.getUTCMonth(),
          this.tempDate.getUTCDate()),trendsListPS[i].delivery_TOTAL]);

      this.trendSeries.NON_DELIVERY_SUB_TOTAL.push([
        Date.UTC(this.tempDate.getUTCFullYear(),
        this.tempDate.getUTCMonth(),
          this.tempDate.getUTCDate()),
      trendsListPS[i].non_DELIVERY_SUB_TOTAL]);

      this.trendSeries.IBU_BUFFER.push(
        [Date.UTC(this.tempDate.getUTCFullYear(),
        this.tempDate.getUTCMonth(),
          this.tempDate.getUTCDate()),
      trendsListPS[i].ibu_BUFFER]);

      this.trendSeries.TOTAL_UNBILLED.push(
        [Date.UTC(this.tempDate.getUTCFullYear(),
        this.tempDate.getUTCMonth(),
          this.tempDate.getUTCDate()),
      trendsListPS[i].total_UNBILLED]);

      this.trendSeries.TOTAL_BILLED.push(
        [Date.UTC(this.tempDate.getUTCFullYear(),
        this.tempDate.getUTCMonth(),
          this.tempDate.getUTCDate()),
      trendsListPS[i].total_BILLED]);

      this.trendSeries.UNBILLED_DELIVERY.push(
        [Date.UTC(this.tempDate.getUTCFullYear(),
        this.tempDate.getUTCMonth(),
          this.tempDate.getUTCDate()),
      trendsListPS[i].unbilled_DELIVERY]);

      this.trendSeries.IBU_TOTAL.push(
        [Date.UTC(this.tempDate.getUTCFullYear(),
        this.tempDate.getUTCMonth(),
          this.tempDate.getUTCDate()),
      trendsListPS[i].ibu_TOTAL]);
    }

    

      
      //push(trendRow.IT_DATE);
      //this.trendSeries.EDATE.push( Date.UTC(new Date(trendRow.IT_DATE).getFullYear(), new Date(trendRow.IT_DATE).getDate() , new Date(trendRow.IT_DATE).getMonth()) );
    //});

    
    
      
  }

}
