export class TrendsSeries{

    constructor(){}
    name : string[];
    //yaxis : number[] = [];
    data : number[][] = []; 
    DELIVERY_TOTAL : number[][] = [];
    NON_DELIVERY_SUB_TOTAL: number[][] = [];
    IBU_BUFFER: number[][] = [];
    TOTAL_UNBILLED: number[][] = [];
    TOTAL_BILLED: number[][] = [];
    UNBILLED_DELIVERY: number[][] = [];
    IBU_TOTAL: number[][] = [];
    
}