import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SaveProjectService } from './save-project.service';
import { DataService } from '../data.sharing.service';
import { Project } from './project-details';

@Component({
  selector: 'app-project-reference-data-update',
  templateUrl: './project-reference-data-update.component.html',
  styleUrls: ['./project-reference-data-update.component.css']
})
export class ProjectReferenceDataUpdateComponent implements OnInit {

  editProjectData;
  isNewEntry = false;
  response: any;

  constructor(private dataService: DataService, private router: Router, private saveProjectService: SaveProjectService) {
    this.editProjectData = this.dataService.currentProjectDataForEdit;
    //console.log(this.editProjectData + ' ' + this.dataService.currentEmployeeDataForEdit );

    if (this.editProjectData === undefined) {

      this.router.navigateByUrl('');
    }

    if (this.editProjectData === null) {

      this.editProjectData = new Project();

      //this.editProjectData.last_MODIFIED_TS = new Date();
    }
    if (
      (this.editProjectData !== undefined) && (
        this.editProjectData.project_ID === undefined)) {
      this.isNewEntry = true;
    } else {
      this.isNewEntry = false;
    }
    if (
      (this.editProjectData !== undefined) &&
      (this.editProjectData.project_ID === undefined ||
        (this.editProjectData.is_PROJECT_ACTIVE !== undefined &&
          (this.editProjectData.is_PROJECT_ACTIVE === 'Y' ||
            this.editProjectData.is_PROJECT_ACTIVE === 'y')))) {
      this.editProjectData.is_PROJECT_ACTIVE = true;
    } else {
      if (this.editProjectData !== undefined)
        this.editProjectData.is_PROJECT_ACTIVE = false;
    }
    //console.log("TCONST");
    //let date = new Date(this.editProjectData.billing_START_DATE);
    //console.log(this.editEmployeeData);
  }

  ngOnInit() {
  }

  isProjectActiveUpdate() {

    //console.log(this.editProjectData.is_PROJECT_ACTIVE);

    if ((this.editProjectData.is_PROJECT_ACTIVE !== undefined &&
      this.editProjectData.is_PROJECT_ACTIVE === true)
    ) {
      // console.log("TRUE");
      this.editProjectData.is_PROJECT_ACTIVE = false;
    } else {
      // console.log("FALSE");
      this.editProjectData.is_PROJECT_ACTIVE = true;
    }
    //console.log(this.editProjectData.is_PROJECT_ACTIVE);
  }

  saveProject(editProjectData) {
    //console.log('savingProject' + editProjectData);
    if (editProjectData.is_PROJECT_ACTIVE === true){
      editProjectData.is_PROJECT_ACTIVE = 'Y';
    }else{
      editProjectData.is_PROJECT_ACTIVE = 'N';
    }
      if (this.isNewEntry) {
        this.saveProjectService.addProduct(editProjectData).
          subscribe(response => this.response = response);
      } else {
        this.saveProjectService.updateProduct(editProjectData).
          subscribe(response => {
            this.response = response;
            
            this.router.navigateByUrl('projects');
          }
          );
      }
  }

}
