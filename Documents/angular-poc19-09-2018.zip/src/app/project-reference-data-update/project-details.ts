export class Project{
    billing_START_DATE : Date;
    customer_NAME : String;
    dm : String;
    is_PROJECT_ACTIVE : String;
    last_MODIFIED_TS : Date;
    po_FLAG : String;
    project_DESCRIPTION : String;
    project_ID : String;
    project_TYPE : String;
    sales_MANAGER : String;
}