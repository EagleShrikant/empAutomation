import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryUtilizationComponent } from './delivery-utilization.component';

describe('DeliveryUtilizationComponent', () => {
  let component: DeliveryUtilizationComponent;
  let fixture: ComponentFixture<DeliveryUtilizationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryUtilizationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryUtilizationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
