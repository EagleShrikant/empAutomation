// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.


export const environment = {
  production: false,  
  summaryDataURL: 'http://10.10.195.63:9089/mvc/getSummaryData',
  entryExitDataURL: 'http://10.10.195.63:9089/mvc/getEntryExitData',
  unbilledDataURL:'http://10.10.195.63:9089/mvc/getUnbillableData',
  saveEmployeeURL:'http://10.10.195.63:9089/mvc/updateEmployee',
  trendsURL:'http://10.10.195.63:9089/mvc/getTrendsData',
  deliveryUtilizationURL: 'http://10.10.195.63:9089/mvc/getDeliveryUtilizationData',
  projectDataURL: 'http://10.10.195.63:9089/mvc/getProjectData',
  updateProductURL: 'http://10.10.195.63:9089/mvc/updateProjectData',
  addProductURL:'http://10.10.195.63:9089/mvc/createProjectData',
  fileUploadURL:'http://10.10.195.63:9089/mvc/fileUpload',
  runPythonScript:'http://10.10.195.63:9089/mvc/runPythonScript'
  //summaryDataURL: 'http://demo5267655.mockable.io/getSummaryData',
  //entryExitDataURL: 'http://demo0220709.mockable.io/getEntryExitData',
  //unbilledDataURL:'http://10.10.195.63:9089/mvc/getUnbillableData',
  //saveEmployeeURL:'http://10.10.195.63:9089/mvc/updateEmployee'
};

/*
 * In development mode, for easier debugging, you can ignore zone related error
 * stack frames such as `zone.run`/`zoneDelegate.invokeTask` by importing the
 * below file. Don't forget to comment it out in production mode
 * because it will have a performance impact when errors are thrown
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
