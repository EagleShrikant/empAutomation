package com.techmahindra.dao;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "delivery_utilization")
public class DeliveryUtilization {
	@Id
    //@GeneratedValue(strategy=GenerationType.IDENTITY)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Column(name = "UT_DATE") private Timestamp UT_DATE;
	
	@Column(name = "UTILIZATION_DELIVERY_PROJ_WITH_PO") private float UTILIZATION_DELIVERY_PROJ_WITH_PO;
	@Column(name = "UTILIZATION_DELIVERY_WITHOUT_PO") private float UTILIZATION_DELIVERY_WITHOUT_PO;
	@Column(name = "DELIVERY_FTE_WITHOUT_PO") private float DELIVERY_FTE_WITHOUT_PO;
	@Column(name = "UTILIZATION_IBU") private float UTILIZATION_IBU;
	
	
	
	public Timestamp getUT_DATE() {
		return UT_DATE;
	}

	public void setUT_DATE(Timestamp uT_DATE) {
		UT_DATE = uT_DATE;
	}

	public float getUTILIZATION_DELIVERY_PROJ_WITH_PO() {
		return UTILIZATION_DELIVERY_PROJ_WITH_PO;
	}

	public void setUTILIZATION_DELIVERY_PROJ_WITH_PO(float uTILIZATION_DELIVERY_PROJ_WITH_PO) {
		UTILIZATION_DELIVERY_PROJ_WITH_PO = uTILIZATION_DELIVERY_PROJ_WITH_PO;
	}

	public float getUTILIZATION_DELIVERY_WITHOUT_PO() {
		return UTILIZATION_DELIVERY_WITHOUT_PO;
	}

	public void setUTILIZATION_DELIVERY_WITHOUT_PO(float uTILIZATION_DELIVERY_WITHOUT_PO) {
		UTILIZATION_DELIVERY_WITHOUT_PO = uTILIZATION_DELIVERY_WITHOUT_PO;
	}

	public float getDELIVERY_FTE_WITHOUT_PO() {
		return DELIVERY_FTE_WITHOUT_PO;
	}

	public void setDELIVERY_FTE_WITHOUT_PO(float dELIVERY_FTE_WITHOUT_PO) {
		DELIVERY_FTE_WITHOUT_PO = dELIVERY_FTE_WITHOUT_PO;
	}

	public float getUTILIZATION_IBU() {
		return UTILIZATION_IBU;
	}

	public void setUTILIZATION_IBU(float uTILIZATION_IBU) {
		UTILIZATION_IBU = uTILIZATION_IBU;
	}

	@Override
	public String toString() {
		return "DeliveryUtilization [UT_DATE=" + UT_DATE + ", UTILIZATION_DELIVERY_PROJ_WITH_PO="
				+ UTILIZATION_DELIVERY_PROJ_WITH_PO + ", UTILIZATION_DELIVERY_WITHOUT_PO="
				+ UTILIZATION_DELIVERY_WITHOUT_PO + ", DELIVERY_FTE_WITHOUT_PO=" + DELIVERY_FTE_WITHOUT_PO
				+ ", UTILIZATION_IBU=" + UTILIZATION_IBU + "]";
	}
	
	
}
