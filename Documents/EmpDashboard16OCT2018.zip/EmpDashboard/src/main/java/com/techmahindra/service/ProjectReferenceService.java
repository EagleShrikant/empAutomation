package com.techmahindra.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.techmahindra.dao.ProjectReference;
import com.techmahindra.dto.APIResponse;
import com.techmahindra.model.ProjectReferenceModel;

@RestController
public class ProjectReferenceService {

	@Autowired
	ProjectReferenceModel projectReferenceModel;
	
	@Autowired
	APIResponse response;
	
	@CrossOrigin
	@GetMapping("/getProjectData")
	public List<ProjectReference> getProjectModel() {
		System.out.println("getProjectData");
		
		return projectReferenceModel.projectModelDataFetch();
	}
	
	@CrossOrigin
	@PostMapping("/updateProjectData")
	public APIResponse updateProjectData(@RequestBody ProjectReference pr) {
		System.out.println("updateProjectData" + pr);
		
		projectReferenceModel.updateProjectData(pr);
		return response;
	}
	
	@CrossOrigin
	@PostMapping("/createProjectData")
	public APIResponse createProjectData(@RequestBody ProjectReference pr) {
		System.out.println("getProjectData" + pr);
		
		projectReferenceModel.createProjectData(pr);
		
		return response;
	}
}
