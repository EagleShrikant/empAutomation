package com.techmahindra.model;

import java.util.Comparator;

import com.techmahindra.dao.Category;

public class SubCategoryComparator implements Comparator<Category> {

	public int compare(Category first, Category second) {
		return first.getSUB_CATEGORY().compareTo(second.getSUB_CATEGORY());
	}
	
}
