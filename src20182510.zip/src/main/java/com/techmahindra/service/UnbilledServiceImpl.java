package com.techmahindra.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.techmahindra.dao.Category;
import com.techmahindra.dao.CurrentEmployee;
import com.techmahindra.dao.UnbilledData;
import com.techmahindra.dto.APIResponse;
import com.techmahindra.model.EntryExitModel;
import com.techmahindra.model.UnbillableDataModel;

@RestController
public class UnbilledServiceImpl {

	
	
	@Autowired
	UnbillableDataModel unbillableModel;
	
	@Autowired
	APIResponse response;
	
	@CrossOrigin
	@GetMapping("/getUnbillableData")
	public List<UnbilledData> getUnbillableModel() {
		System.out.println("getUnbillableData");
		
		return unbillableModel.UnbillableModelDataFetch();
	}
	
	@CrossOrigin
	@PostMapping("/updateEmployee")
	public APIResponse updateEmployee(@RequestBody UnbilledData ce) {
		System.out.println("-----------" + ce);
		unbillableModel.saveEmployee(ce);
		return response;
	}
	
	@CrossOrigin
	@GetMapping("/getCategories")
	public Set<Category> getCategories() {
		
		return unbillableModel.getCategories();
		
	}
	
	@CrossOrigin
	@PostMapping("/getSubCategories")
	public Set<Category> getSubCategories(@RequestBody String category) {
		
		return unbillableModel.getSubCategories(category);
		
	}
	
	@CrossOrigin
	@PostMapping("/getSubCategory")
	public Category getSubCategory(@RequestBody Category subcategory) {
		
		return unbillableModel.getSubCategory(subcategory);
		
	}
	

}
