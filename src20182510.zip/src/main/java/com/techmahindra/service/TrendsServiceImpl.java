package com.techmahindra.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.techmahindra.dao.CurrentEmployee;
import com.techmahindra.dao.DeliveryUtilization;
import com.techmahindra.dao.IBUTrends;
import com.techmahindra.model.TrendModel;

@RestController
public class TrendsServiceImpl {

	@Autowired
	TrendModel trendModel;
	
	@CrossOrigin
	@GetMapping("/getTrendsData")
	public List<IBUTrends> getUnbillableModel() {
		System.out.println("getUnbillableData");
		
		return trendModel.trendModelDataFetch();
	}
	
	@CrossOrigin
	@GetMapping("/getDeliveryUtilizationData")
	public List<DeliveryUtilization> getDeliveryUtilizationModel() {
		System.out.println("getUnbillableData");
		
		return trendModel.deliveryUtilizationModelDataFetch();
	}
	
}
