package com.techmahindra.model;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.techmahindra.boot.MySQLAppConfig;
import com.techmahindra.dao.ProjectReference;
import com.techmahindra.dto.APIResponse;

@Component
public class ProjectReferenceModel {

	@Autowired
	MySQLAppConfig mySQLAppConfig;
	
	
	
	List<ProjectReference> projectDataList;
	
	public List<ProjectReference> projectModelDataFetch() {
		System.out.println("ProjectReferenceModelDataFetch");
		Session session = mySQLAppConfig.getSessionFactory(mySQLAppConfig.getDataSource()).openSession();
	      Transaction tx = null;
	      
	      try {
	         tx = session.beginTransaction();

	         projectDataList = session.createQuery("from ProjectReference").list();
	         
	         tx.commit();
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } catch (Exception e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      }
	      
	      finally {
	         session.close(); 
	      }
	      
	      return projectDataList;

	}

	public void updateProjectData(ProjectReference pr) {
		Session session = mySQLAppConfig.getSessionFactory(mySQLAppConfig.getDataSource()).openSession();
	    Transaction tx = null;
	    
	    try {
	       tx = session.beginTransaction();
	       ProjectReference project = (ProjectReference)session.get(ProjectReference.class, pr.getPROJECT_ID());
	       //System.out.println("Save"+ce);
	       project.updateProject(pr);
		   session.update(project); 
	       tx.commit();
	    } catch (HibernateException e) {
	       if (tx!=null) tx.rollback();
	       e.printStackTrace(); 
	    } finally {
	       session.close(); 
	    }
	}

	public void createProjectData(ProjectReference pr) {
		Session session = mySQLAppConfig.getSessionFactory(mySQLAppConfig.getDataSource()).openSession();
	    Transaction tx = null;
	    
	    try {
	       tx = session.beginTransaction();
	       pr.updateProject(pr);
		   session.save(pr); 
	       tx.commit();
	    } catch (HibernateException e) {
	       if (tx!=null) tx.rollback();
	       e.printStackTrace(); 
	    } finally {
	       session.close(); 
	    }
	}

}
