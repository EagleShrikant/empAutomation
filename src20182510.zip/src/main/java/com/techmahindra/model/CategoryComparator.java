package com.techmahindra.model;

import java.util.Comparator;

import com.techmahindra.dao.Category;

public class CategoryComparator implements Comparator<Category> {

	public int compare(Category first, Category second) {
		return first.getCATEGORY().compareTo(second.getCATEGORY());
	}
}
