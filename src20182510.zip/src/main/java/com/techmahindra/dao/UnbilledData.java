package com.techmahindra.dao;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "unbilled")
public class UnbilledData {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UNBILLED_REC_ID", length=11 )
    private int UNBILLED_REC_ID;
	
	
	
	 @javax.persistence.OneToOne( fetch = javax.persistence.FetchType.EAGER, optional = true )
	 @javax.persistence.JoinColumn( name = "EMPLID", referencedColumnName="EMPLID", nullable = true, unique = false, insertable = true, updatable = true )
	  private CurrentEmployee objCurrentEmployee;
	 

	
	
	@Column(name = "ACCOUNT") private String ACCOUNT;
	@Column(name = "BILLING_START_DATE") private Timestamp BILLING_START_DATE;
	
	@javax.persistence.ManyToOne( fetch = javax.persistence.FetchType.EAGER, optional = true )
	@javax.persistence.JoinColumn( name = "SUB_CAT_ID", referencedColumnName="SUB_CAT_ID", nullable = true, unique = false, insertable = true, updatable = true )
	 private Category category;
	
	
	
	@Column(name = "ACTION") private String ACTION;
	@Column(name = "UNBILLED_FROM",length=15) private Timestamp UNBILLED_FROM;
	@Column(name = "COMMENTS") private String COMMENTS;
	
	
	public int getUNBILLED_REC_ID() {
		return UNBILLED_REC_ID;
	}
	public void setUNBILLED_REC_ID(int uNBILLED_REC_ID) {
		UNBILLED_REC_ID = uNBILLED_REC_ID;
	}
	public CurrentEmployee getObjCurrentEmployee() {
		return objCurrentEmployee;
	}
	public void setObjCurrentEmployee(CurrentEmployee objCurrentEmployee) {
		this.objCurrentEmployee = objCurrentEmployee;
	}
	public String getACCOUNT() {
		return ACCOUNT;
	}
	public void setACCOUNT(String aCCOUNT) {
		ACCOUNT = aCCOUNT;
	}
	public Timestamp getBILLING_START_DATE() {
		return BILLING_START_DATE;
	}
	public void setBILLING_START_DATE(Timestamp bILLING_START_DATE) {
		BILLING_START_DATE = bILLING_START_DATE;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public String getACTION() {
		return ACTION;
	}
	public void setACTION(String aCTION) {
		ACTION = aCTION;
	}
	public Timestamp getUNBILLED_FROM() {
		return UNBILLED_FROM;
	}
	public void setUNBILLED_FROM(Timestamp uNBILLED_FROM) {
		UNBILLED_FROM = uNBILLED_FROM;
	}
	public String getCOMMENTS() {
		return COMMENTS;
	}
	public void setCOMMENTS(String cOMMENTS) {
		COMMENTS = cOMMENTS;
	}
	public void updateUnbilled(UnbilledData ud) {
		
		//this.setObjCurrentEmployee(ud.getObjCurrentEmployee());
		this.setCategory(ud.getCategory());
		this.setACCOUNT(ud.getACCOUNT());
		this.setCOMMENTS(ud.getCOMMENTS());
		System.out.println(ud.getCategory());
		this.setCategory(ud.getCategory());
		this.setBILLING_START_DATE(ud.getBILLING_START_DATE());
		this.setACTION(ud.getACTION());
	}
	
	
	
}
