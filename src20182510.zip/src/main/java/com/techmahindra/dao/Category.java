package com.techmahindra.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "category_data")
public class Category {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SUB_CAT_ID", updatable = false, nullable = false)
	private int SUB_CAT_ID;
	
	@Column(name = "SUB_CATEGORY") private String SUB_CATEGORY;
	@Column(name = "CATEGORY") private String CATEGORY;
	
	public int getSUB_CAT_ID() {
		return SUB_CAT_ID;
	}
	public void setSUB_CAT_ID(int sUB_CAT_ID) {
		SUB_CAT_ID = sUB_CAT_ID;
	}
	public String getSUB_CATEGORY() {
		return SUB_CATEGORY;
	}
	public void setSUB_CATEGORY(String sUB_CATEGORY) {
		SUB_CATEGORY = sUB_CATEGORY;
	}
	public String getCATEGORY() {
		return CATEGORY;
	}
	public void setCATEGORY(String cATEGORY) {
		CATEGORY = cATEGORY;
	}
	
	@Override
	public String toString() {
		return "Category [SUB_CAT_ID=" + SUB_CAT_ID + ", SUB_CATEGORY=" + SUB_CATEGORY + ", CATEGORY=" + CATEGORY + "]";
	}
	
	
	
}
